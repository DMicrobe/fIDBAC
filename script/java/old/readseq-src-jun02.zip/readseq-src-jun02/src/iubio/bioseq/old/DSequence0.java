// DSequence.java
// by d.g.gilbert, 1990 -- 1997


package iubio.bioseq;
// was dbioseq

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import iubio.readseq.BioseqDoc;
import iubio.readseq.BioseqDocImpl;
import iubio.readseq.GenbankDoc;
import iubio.readseq.FeatureItem;

public class SearchRec {
	public int			lim,indx,step;
	public String 	targ;
	}


	// merge or replace this class with readseq.BioseqRecord
	
public class DSequence 
	extends Bioseq
	implements Cloneable, DSeqChanges
	//!? extends Bioseq with these 
	// -- mask handling (should this be in bioseq?)
	// -- name/date/kind/origin
	// -- selection range
	// -- searching (string, ORF, ?pattern, ???)
	// -- [todo] documentation and features
	
{
	//public final static short kOtherSeq= 0, kDNA= 1, kRNA= 2, kNucleic= 3, kAmino= 4;
 	public final static int kSearchNotFound = -1;
 	public final static char kMaskOK = 'K';
 	public final static int kMaskEmpty = -1;
	public final static int 
		kNameWidth	= 31,
		kMaxSeqShow = 10,
		kMaxSname	= 20
		;

	//protected Biobase[]		fSeq; 		//the bases // or String

  //protected Object 			fInfo;			//sequence documentation // likely a String?
	protected BioseqDocImpl fInfo; // seqdoc
  protected String 			fName;
  protected short 			fKind;			//dna/rna/amino/...
  protected int 				fLength;		//base count
  protected long 				fChecksum;	//checksum for the bases
  protected long 				fModTime;		//date/time last modified
  protected int 				fOrigin;		//offset of start from 0
  protected int 				fSelStart;	//selection start -- tmp
  protected int 				fSelBases;	//selection size
  protected short 			fIndex;			//index into SeqList (temp?)
  protected SearchRec 	fSearchRec = new SearchRec();
	protected boolean 		fDeleted;		//? Whether the seq has been deleted 
	protected boolean 		fOpen;			//? seq is open in a view
	protected boolean 		fChanged;		//modified since updt
	protected boolean			fMasksOk;		//if fMasks is in a good state
	protected boolean 		fIsMega;		//object == DMegaSequence
	protected boolean			fShowORF;		//show ORF mask - only for DAsmView?
	protected boolean 		fShowRE;		//show RE cuts - "
	protected boolean			fShowTrace;	//show basecall trace - "
	
  public static String 	kConsensus = "Consensus";
	public static String gDefSeqName = "Noname";

	public DSequence() { super(); init(); }
	public DSequence(Biobase[] bb) { super(bb); init(); }
	public DSequence(byte[] b) { super(b); init(); }
	public DSequence(char[] c) { super(c); init(); }
	public DSequence(String s) { super(s); init(); }
	public DSequence(int maxlen) { super(maxlen); init(); } 

  protected void init() {
    fName = "Untitled"; //!? need unique name, eg. Noname-1,noname- 2...
  	//fInfo = new String("");  
    fKind = kOtherSeq;  //? user default
    fModTime= System.currentTimeMillis();
    if (fSeq!=null) fLength= fSeq.length;
  	// rest are java init defaults (keep in for c++ translation?)
  	//fMasksOk	= false;
    //fLength   = 0;
    //fChecksum = 0;
    //fIndex    = 0; //dummy
    //fChanged  = false; //true;
    //fIsMega   = false;
    //fShowORF  = false;
    //fShowRE   = false;
    //fShowTrace= false;
    //fDeleted  = false; 
    //fOpen     = false;
    //fSearchRec.targ= null;
    //fOrigin 	= 0;
    //fSelStart	= 0;
    //fSelBases	= 0;
    }


	//public final Biobase base(int i) { return fSeq[i]; }
	//public final Biobase[] bases() { return fSeq; } // this is REFERENCE to actual array
	public void stuffbase(int i, Biobase b) { fSeq[i]= b; }
	public void stuffbases(Biobase[] theBases) { fSeq= theBases; } 
	
	public int length() { return fLength; } // ? or fSeq.length; 
  public final int LengthF() 	{ return length(); }
  //public byte[] Masks() { return fMasks; }
  public String Name() 	{ return fName; }
  public BioseqDocImpl Info() 	{ return fInfo; }
  public short Kind() 	{ return fKind; }
  public short Index() 	{ return fIndex; }
  public boolean Changed() 		{ return fChanged; }
  public long ModTime() 			{ return fModTime; }
  public long Checksum() 			{ return fChecksum; }
  public int Origin() 				{ return fOrigin; }
  public boolean IsAmino() 		{ return (fKind == kAmino); }
  public boolean IsDeleted() 	{ return fDeleted; }
  public boolean ShowORF() 		{ return fShowORF; }
  public boolean ShowRE() 		{ return fShowRE; }
  public boolean ShowTrace() 	{ return fShowTrace; }
  public boolean MasksOk() 		{ return fMasksOk; }

  public void setName(String theName)			{	fName= (fName!=null) ? new String(theName) : ""; }
	public void SetLength(int theLength) 		{ fLength= theLength;  }
  public void SetKind(int theKind) 	  		{ fKind= (short)theKind; }
	public void SetIndex(int theIndex) 			{ fIndex= (short)theIndex;  }
	public void SetTime(long theTime) 			{ fModTime= theTime; }
  public void SetOrigin(int theOrigin) 		{ fOrigin= theOrigin; }
  public void SetDeleted(boolean turnon)	{ fDeleted= turnon; }
  public void SetChanged(boolean turnon) 	{ fChanged= turnon; }



  public void SetInfo(Object theInfo) { 
  	SetInfo( theInfo, true);
  	}

 /* 
 	public void SetInfo( Object theInfo, boolean doclone) { 
    if (theInfo==null)
    	fInfo= ""; //?
    else if (doclone) {
    	if (theInfo instanceof String) {
    		fInfo= new String( (String)theInfo);
    		}
    	else if (theInfo instanceof BioseqDocImpl) 
    		fInfo= ((BioseqDocImpl) theInfo).clone();
    	else if (theInfo instanceof Cloneable) fInfo= ((Cloneable) theInfo).clone();
   	 	else fInfo= theInfo;
			}
		else {
    	fInfo= theInfo;
    	}
	}*/
	
  public void SetInfo( Object theInfo, boolean doclone) { 
 		if (theInfo instanceof BioseqDocImpl) {
     	if (doclone) fInfo= (BioseqDocImpl) ((BioseqDocImpl)theInfo).clone();
			else fInfo=	(BioseqDocImpl) theInfo;
 			} 	
 		else if (theInfo instanceof BioseqDoc) {
    	fInfo= new GenbankDoc( (BioseqDoc) theInfo);
 			} 	
  	else if (theInfo instanceof String) {
  		fInfo= new GenbankDoc();
  		fInfo.addBasicName((String)theInfo);
  		}
		else {
    	//? 
    	}
	}

	public final Biobase[] toBiobase() { return Bioseq.dup(fSeq); }

	public boolean equals(String bases) {
		if (bases.length() != length()) return false;
		for (int i=0; i<length(); i++) {
			if (fSeq[i].c() != bases.charAt(i)) return false;
			}
		return true;
		}
		
	public boolean quickEquals(DSequence aSeq) {
	  return (aSeq != null
	  			 && aSeq.Checksum() == this.Checksum() 
	         && aSeq.length() == this.length()
	         && aSeq.ModTime() == this.ModTime() );
		}
		
	// == Bioseq.toString()
	public String basesToString() { return new String(toChars()); }

	public String basesToString(int spaceStep, byte spacer) { 
			// this is a dup of biosequence.toChars() + spacer stuff
			// mainly for java.awt.TextArea displays
		int offset= 0;
		int len= fSeq.length - offset;
		int spacemore = len / spaceStep;
		byte[] c= new byte[len+spacemore];
		int spaceStep1= spaceStep-1;
		int i, j= 0;
		switch (gBaseType) {
			default:
			case baseOnly  : 
				for (i=0; i<len; i++) {
					c[j++]= fSeq[i+offset].base(); 
					if (i % spaceStep == spaceStep1) c[j++]= spacer;
					}
				break;
			case maskOnly  : 
				for (i=0; i<len; i++) {
					c[j++]= fSeq[i+offset].mask(); 
					if (i % spaceStep == spaceStep1) c[j++]= spacer;
					}
				break;
				/*
			case nucAndMask: 
				for (i=0; i<len; i++) {
					c[j++]= fSeq[i+offset].basemask(); 
					if (i % spaceStep == spaceStep1) c[j++]= spacer;
					}
				break; */
			case maskOnlyAsText: 
				for (i=0; i<len; i++) {
					c[j++]= fSeq[i+offset].maskAsText(); 
					if (i % spaceStep == spaceStep1) c[j++]= spacer;
					}
				break;
			}
			
		return new String(c);
		}
		
	public String toString() { 
		return  getClass().getName() 
				+ "[name=" + Name()
				+ ",length=" + length()
				+ ",checksum=" + Checksum()
				+ ",bases=" + toChars(baseOnly)
				//? more fields...
				+ "]";
		}


	public Object clone() {
		//try {
			DSequence aSeq= (DSequence) super.clone();
			aSeq.setbases( fSeq, true);  
	    //if (fInfo instanceof String) 
	    //	aSeq.fInfo= new String( (String)fInfo);
	    //else if (fInfo instanceof BioseqDocImpl) 
	    //	aSeq.fInfo= ((BioseqDocImpl) fInfo).clone();
			if (fInfo!=null)
				aSeq.fInfo= (BioseqDocImpl) fInfo.clone();
	    //aSeq.fName= new String( fName);
	    //if (fSearchRec.targ!=null)
	    //	aSeq.fSearchRec.targ= new String( fSearchRec.targ);
	    return aSeq;
		//	}
		//catch(CloneNotSupportedException ex) { throw new InternalError(ex.toString()); }
		}

  public void CopyContents( DSequence fromSeq) { 
  	setContents(fromSeq, true); 
  	}
  	
  public void setContents( DSequence fromSeq, boolean copy) { 
    setbases( fromSeq.fSeq, copy); 
    SetInfo( fromSeq.fInfo); 
    setName( fromSeq.fName); 
    fKind     = fromSeq.fKind;     
    fLength   = fromSeq.fLength;
    fChecksum = fromSeq.fChecksum;
    fModTime  = fromSeq.fModTime;
    fChanged  = fromSeq.fChanged;
    fDeleted  = fromSeq.fDeleted; 
    fOpen     = fromSeq.fOpen;
    fIndex    = fromSeq.fIndex;
    fSearchRec= fromSeq.fSearchRec;
    //fSearchRec.targ= fromSeq.fSearchRec.targ;
    }

  public void enfold(Bioseq bioseq, Object info, String name) 
  { 
  	if (bioseq instanceof DSequence)
  		setContents( (DSequence)bioseq, false);
  	else {
			useByteArray= false; //bioseq.useByteArray;
			bSeq= bioseq.bSeq;
			fSeq= bioseq.bases(); // creates fSeq if needed
	    fLength = bioseq.length();
	  	SetInfo( info, false); 
	    setName( name); 
	    fModTime= System.currentTimeMillis();
	   	FixMasks();
	   	UpdateFlds(); // sets fKind!
	    }  
    }

  public String KindStr() { return KindStr(fKind); }
  	
  public static String KindStr(int kind) { 
  	// see Bioseq.getKindLabel() with slightly diff. labels !
    switch (kind) {
      case kDNA     : return "DNA";
      case kRNA     : return "RNA";
      case kNucleic : return "Nucleic";
      case kAmino   : return "Protein";
      default       :
      case kOtherSeq: return "Unknown";
      }
    }


  public void setbases(Biobase[] theBases, boolean duplicate, int newlen) { 
    if (fSeq!=null) { 
      if (fLength>0 && 
        (fLength != newlen || Bioseq.cmp( theBases, fSeq, newlen)!= 0))
          fChanged= true;
      fSeq= null; 
      fLength= 0; 
      }
    if (theBases!=null) {
      if (duplicate) fSeq= Bioseq.dup(theBases); 
      else fSeq= theBases;  
      fLength= newlen;  
      }
    fModTime= System.currentTimeMillis();
   	FixMasks();
    }

  public final void setbases(Biobase[] theBases, boolean duplicate) { 
  	setbases( theBases, duplicate, (theBases==null) ? 0 : theBases.length);
		}
		
  public final void setbases(byte[] theBases, boolean duplicate) { 
  	Bioseq bs= new Bioseq(theBases);
  	setbases( bs.bases(), false, (theBases==null)?0:theBases.length);
  	}
  	
  public final void setbases(Biobase[] theBases, int theLength) { 
  	setbases( theBases, false, theLength);
    }

  public final void setbases(Biobase[] theBases) {
  	setbases( theBases, false, (theBases==null)?0:theBases.length); 
    }
			
  public static void nucleicComplement(boolean isrna, 
				  			Biobase[] fromSeq, int fromOffset, 
				  			Biobase[] toSeq, int toOffset, int len) 
  { 
    // note: fromSeq may == toSeq 
    int	i= fromOffset, j= toOffset;
    while (len-- > 0) {
      byte b= fromSeq[i++].base();
      toSeq[j++].c= BaseKind.nucleicComplement(b, isrna);
      }
    }

	/*
  public static String Nucleic23Protein(String nucs, int nbases) 
  { 
  	if (DCodons.notAvailable()) return null; 
    char aminos[] = new char[(nbases + 3) / 3];
    int k = 0;
    for (int i= 0; i<nbases; i++) {
      for (int j=0; j<64; j++)
      	if (nucs.regionMatches( true, i, DCodons.codon(j), 0, 3)) {
          aminos[k++]= DCodons.amino(j); 
          i += 2;
          break;
       		} 
      }
    return new String( aminos, 0, k);
    }
	*/
		
  public void SetSelection(int start, int nbases) { 
    fSelStart= start;
    fSelBases= nbases;
    }

  public SeqRange getSelection() { 
  	int start, nbases;
    if (fSelBases==0) {
      start= 0;
      nbases= fLength;
      } 
    else if (fLength>0) {
      start= fSelStart;
      nbases= Math.min( fSelBases, fLength - fSelStart);
      } 
    else {
      start= 0;
      nbases= 0;
      }
    return new SeqRange(start, nbases);  
    }

  public void ClearSelection() { 
    fSelStart= 0;
    fSelBases= 0;
    }

 
  public void SetShowRE(short turnon) { fShowRE= turnon > 0;  }
  public void SetShowTrace(short turnon) { fShowTrace= turnon > 0;  }

	public void SetShowORF(int turnon) { 
    fShowORF= turnon > 0; 
    if (turnon > 1) {
      if ((turnon & 2) > 0) SetORFmask(5, 0);
      //if (turnon & 4 > 0) SetORFmask(6, 1);
      //if (turnon & 8 > 0) SetORFmask(7, 2);
      }
    }

  public void SetORFmask(int masklevel, int frame) { 
    if (!fMasksOk) {
      FixMasks();
      if (!fMasksOk) return;
      }
      
    // revise this to do multiple frames in one go,
    //  offseting each anchor +1 beyond START of last orf, not after STOP
    // since separate frame calls return the same orfs !
    
    frame %= 3; // drop reverse frames
    int savesel= fSelStart;
    int savelen= fSelBases;
    fSelStart= frame;
    fSelBases= fLength - frame;
    int start = 0, fini= 0;
    int anchor= fSelStart;
    do {
      SeqRange sr= this.SearchORF(); 
      start= sr.start(); fini= sr.stop();
      if (start != kSearchNotFound) {
        int i;
        for (i= anchor; i<start; i++) SetMaskAt( i, masklevel, 0);
        for (i= start; i<=fini ; i++) SetMaskAt( i, masklevel, 1);
        if (fini == kSearchNotFound) {
          start= kSearchNotFound;
          }
        else {
          anchor= fini+1;
          fSelStart= anchor; // start+1 // !? want overlapped orfs !?
          }
        }
    	} while (start != kSearchNotFound);
    
    fSelStart= savesel;
    fSelBases= savelen;
    }
	 




	// FEATURES =================================
	// replacement for MASKS
	
	public final FeatureItem[] findFeatures( Hashtable wantfeatures) {
		return findFeatures(wantfeatures , null);
		}
	public final FeatureItem[] findFeatures(SeqRange wantrange) {
		return findFeatures(null, wantrange);
		}

	public FeatureItem[] findFeatures( Hashtable wantfeatures, SeqRange wantrange)
	{
		if ((wantfeatures!=null || wantrange != null) && fInfo!=null) {
			if (wantfeatures==null) 	return fInfo.findFeatures( wantrange);
			Vector v= new Vector();
			Enumeration names= wantfeatures.keys();
			while (names.hasMoreElements()) {
				String name= (String) names.nextElement();
				v= fInfo.findFeatures( name, wantrange, v);
				}
			if (v.isEmpty()) return null;
			FeatureItem[] fs= new FeatureItem[v.size()];
			v.copyInto(fs);
			return fs;
			}
		else return null;
	}

	public final DSequence extractFeatureBases( Hashtable wantfeatures)  
		throws SeqRangeException
		{ return extractRemoveFeatureBases( true, wantfeatures, null); }
		
	public final DSequence extractFeatureBases( Hashtable wantfeatures, SeqRange wantrange)  
		throws SeqRangeException
		{ return extractRemoveFeatureBases(true, wantfeatures, wantrange); }
		
	public final DSequence removeFeatureBases( Hashtable wantfeatures)  
		throws SeqRangeException
		{ return extractRemoveFeatureBases(false, wantfeatures, null); }
		
	public final DSequence removeFeatureBases( Hashtable wantfeatures, SeqRange wantrange) 
		throws SeqRangeException
		{ return extractRemoveFeatureBases(false, wantfeatures, wantrange); }
		
	public DSequence extractRemoveFeatureBases( boolean extract, 
				Hashtable wantfeatures, SeqRange wantrange) throws SeqRangeException
	{
		if (wantfeatures!=null && fInfo!=null) {
			fInfo.setWantedFeatures( extract, wantfeatures, wantrange);
			SeqRange featsr= fInfo.getFeatureRanges(this.length());
			DSequence bseq= extractBases( featsr);
			fInfo.setWantedFeatures( extract, null, null);
			return bseq;
			}
		else return null;
	}
	
	public DSequence extractBases( SeqRange range) throws SeqRangeException
	{
		if (range==null) 
			throw new SeqRangeException("Null SeqRange");  
		int totlen= 0;
		for (SeqRange sr= range; sr!=null; sr= sr.next())  {
			if (sr.isRemote()) continue;
			totlen += sr.nbases();
			}
		int seqlen= this.length();	
		if (totlen > 0) {
			int bat= 0;
			byte[] ba= new byte[totlen];
			byte[] bases= this.toBytes(); // always? or check bioseq.isBytes() ?
			for (SeqRange sr= range; sr!=null; sr= sr.next())  {
				if (sr.isRemote()) continue;
				int start= sr.start();
				int len= sr.nbases();
				
				String err;
				if (start < 0) err= String.valueOf(start) + " start<0";
				else if (start+len > seqlen ) err= String.valueOf(start+len ) + " end>" + String.valueOf(seqlen);
				else if (bat+len > totlen) err= String.valueOf(bat+len) + "  size>" + String.valueOf(totlen);
				else err= null;
				if (err!=null) {
					err= "Bad range: "+ err + " for "+ sr;
					// System.err.println(err); 
					throw new SeqRangeException(err);
					}
				else {
					System.arraycopy( bases, start, ba, bat, len);
					bat += len;
					}
				}
			DSequence newseq= new DSequence();
			newseq.setContents(this, false);
			newseq.setbases(ba,false);
	    newseq.fModTime= System.currentTimeMillis();
	   	newseq.UpdateFlds(); // sets fKind!

			return newseq;
			}
		else
			throw new SeqRangeException("Empty SeqRange");  
	}
	


	// SEARCHES =================================


  public int Search(String target, boolean backwards) 
  { 
    int    limit, aStart;
    SearchRec  aSearchRec = new SearchRec();
    aStart= fSelStart;
    if (target == null || target.length()==0) {  //search again
      if (fSearchRec.targ!=null && (fSearchRec.step == -1 || fSearchRec.step == 1)) {  
        aSearchRec= fSearchRec;
        target= aSearchRec.targ;
        }   
      else {
        return kSearchNotFound;
        }
      }   
    else {
      limit= fLength;  
      if (aStart < 0) aStart= 0;
      if (backwards) {
        if (aStart!=0) aStart= limit-1;
        else limit= aStart+1;  //? off-by-one ??
        }   
      else {
        if (aStart > limit) aStart= 0; 
        else limit -= aStart;
        }
      if (fSelBases > 0 && fSelBases < limit) limit= fSelBases;
      if (backwards) aSearchRec.step= -1;
      else aSearchRec.step= 1;
      aSearchRec.indx= aStart - aSearchRec.step;
      aSearchRec.lim = limit + aSearchRec.step; 
      aSearchRec.targ= new String(target);
      }
      
    switch (fKind) {  
      case kRNA:
      case kDNA:
      case kNucleic: 
        NucleicSearch(fSeq,target,aSearchRec); 
        break;
      default:
        ProteinSearch(fSeq,target,aSearchRec);
        break;
      }
    
    fSearchRec= aSearchRec;
    if (aSearchRec.lim == 0) return kSearchNotFound;
    else return aSearchRec.indx;
    }


  public int SearchAgain() { return Search( null, false); }

	public final SeqRange SearchORF()  {   	
  	return SearchORF(DSeqList.gMinORFsize);
  	}
  
  public SeqRange SearchORF(int minORFsize) 
  {   	
    int start= kSearchNotFound;
    int stop = kSearchNotFound;
    int  i, j, k, ns, aaMinORFsize;
   	SeqRange nullrange= new SeqRange(start, stop-start);
 		char[] startc= new char[1];
   	CodonStat[]  stops= new CodonStat[10];
    
    if (DCodons.notAvailable()) return nullrange;
    for (ns= 0, i= 0; i<DCodons.maxCodon; i++) {
      if (ns<10 && DCodons.amino(i) == '*') 
        stops[ns++] = DCodons.fCodons[i];
      }
    if (ns == 0) return nullrange;
      
    switch (fKind) {  
      case kRNA:
      case kDNA:
      case kNucleic: 
        start= Search( DCodons.startcodon(), false);
        if (start == kSearchNotFound) 
        	return nullrange;
        for (j= start+3; j+3<fLength; j += 3) {
          if ( j+3 - start >= minORFsize) 
        nextcodon:
           for (k=0; k<ns; k++) {
            int jc, jt;
            for (jc= 0, jt=0; jc<3; ) {
              int tbit= BaseKind.nucleicBits( fSeq[j+jt].c());
              int sbit= BaseKind.nucleicBits( stops[k].getCodon().charAt(jc)); 
              if (tbit == BaseKind.kMaskIndel) jt++;
              else if ((BaseKind.kMaskNucs & tbit & sbit)==0) continue nextcodon;
              else { jt++; jc++; }
              }
            stop= j+3; 
            return new SeqRange(start, stop-start);
            //continue;
            }
          }
        break;
        
      case kAmino:
        startc[0]= DCodons.startamino();
        aaMinORFsize= (minORFsize+2) / 3;
        start= Search( new String(startc), false);
        if (start == kSearchNotFound) 
        	return nullrange;
        for (j= start+1; j<fLength; j++) {
          if ( j - start >= aaMinORFsize) 
           for (k=0; k<ns; k++) {
            if (Character.toUpperCase(fSeq[j].c()) == Character.toUpperCase(stops[k].getAmino())) {
              stop= j+1; // +1 to include this codon
              return new SeqRange(start, stop-start);
              }
            }
          }
        break;
        
      default:
        break;
      }
   
  	return new SeqRange(start, stop-start);
	}
 


  public void NucleicSearch(Biobase[] source, String target, SearchRec aSearchRec) 
  { 
    int k, j, tBits, lens, ti;
    boolean done;
            //find target[ti] where tBits == kMaskA,C,G,T for fastest search
            //This part is wasted time for SearchAgain... store tBits/ti in saverec...
    lens= target.length();
    for (j= 0, ti= 0, tBits= 0; j<lens && tBits==0; j++) {
      ti= j;
      tBits= BaseKind.nucleicBits( target.charAt(ti));
      tBits &= BaseKind.kMaskNucs;  //drop RNA bit
      }
      
    do {
      aSearchRec.indx += aSearchRec.step; 
      aSearchRec.lim  -= aSearchRec.step; 
  
  	testbits:
  		{    
      if (aSearchRec.step>0) {
        for (j= 0; j<aSearchRec.lim; j++)
         if ( (tBits & BaseKind.nucleicBits( source[j+aSearchRec.indx].c())) != 0) 
         {
          k= j; 
          break testbits;
         }
        k= aSearchRec.lim;
        }     
      else {  //step<0 IS BAD .. see UTextDoc version...
        for (j= 0; j > -aSearchRec.lim; j--) 
          if ( (tBits & BaseKind.nucleicBits( source[j+aSearchRec.indx].c())) != 0) 
          {
          k= j; 
          break testbits;
          }
        k= -aSearchRec.lim;
        }
      }
         
      aSearchRec.indx += k; 
      aSearchRec.lim  -= k;
        //? not enough source left to match full target 
      if (aSearchRec.step>0) {
        if (aSearchRec.lim < lens-ti) aSearchRec.lim= 0;
        }     
      else {
        if (aSearchRec.lim < ti) aSearchRec.lim= 0; //? or lim < ti-1 
        }
      done= (aSearchRec.lim==0);
 
 		testbits2:     
      if (!done) {
        int srcstart= aSearchRec.indx - ti;
        int js, jt;
        for (js= 0, jt= 0; jt<lens; ) {
          int tbit= BaseKind.nucleicBits( target.charAt(jt));
          int sbit= BaseKind.nucleicBits( source[js+srcstart].c()); 
          if (tbit == BaseKind.kMaskIndel) jt++;
          else if (sbit == BaseKind.kMaskIndel) js++;
          else if ((BaseKind.kMaskNucs & tbit & sbit)==0) break testbits2;
          else { jt++; js++; }
          }
        done= true;
        }
        
 			} while (!done);
  }


  public void ProteinSearch(Biobase[] source, String target, SearchRec aSearchRec) 
  { 
    boolean  done;
    int  k, j;
    int  lens= target.length();
    char tChar= Character.toUpperCase( target.charAt(0));
    
    do {
      aSearchRec.indx += aSearchRec.step; 
      aSearchRec.lim  -= aSearchRec.step; 
      
  	testbits:  
  		{   
      if (aSearchRec.step>0) {
        for (j= 0; j<aSearchRec.lim; j++) 
         if (tChar == Character.toUpperCase( source[j+aSearchRec.indx].c())) {
          k= j;
          break testbits;
          }
        k= aSearchRec.lim;
        }     
      else {
        for (j= 0; j > -aSearchRec.lim; j--)
         if (tChar == Character.toUpperCase(source[j+aSearchRec.indx].c())) {
          k= j; 
          break testbits;
          }
        k= -aSearchRec.lim;
        }
     	}
     	     
      aSearchRec.indx += k; 
      aSearchRec.lim  -= k;
        //? not enough source left to match full target 
      if (aSearchRec.step>0) {
        if (aSearchRec.lim < lens-1) aSearchRec.lim= 0;
        }     
      else {
        if (aSearchRec.lim < 1) aSearchRec.lim= 0;  
        }
      done= (aSearchRec.lim==0);
      
  	testbits2:     
     	if (!done) {
        for (j= 1; j<lens; j++) {
          if (Character.toUpperCase( target.charAt(j)) != 
          		Character.toUpperCase( source[j+aSearchRec.indx].c())) 
            break testbits2;
          }
        done= true;
        }
    	} while (!done);
	}

 
	public boolean IsConsensus() { 
    return (fName!=null && fName.equals(kConsensus));
    }

  public boolean GoodChar(char ch) 
  { 
  	if (ch=='\n' || ch=='\r') return false;
    else if (ch<' ' || ch>'~') return true; //?? allow return,tab,delete, ? option chars
    else if (BaseKind.isIndel(ch)) return true;
  	else switch (fKind) {
      case kDNA     : return BaseKind.isDnanuc(ch); 
      case kRNA     : return BaseKind.isRnanuc(ch); 
      case kNucleic : return BaseKind.isIUBsym(ch); 
      case kAmino   : return BaseKind.isAmino(ch); 
      default:
      case kOtherSeq: return true;
      }
  }


  public void Reformat(short format) { 
    // later...? 
    }


	public void Modified() { 
    fModTime  = System.currentTimeMillis(); //gUtil.time();
    fChanged  = true;
    }
    
  public void updateRange(int changeflags, int start, int length, byte[] changes) {     
		//if (fInfo instanceof BioseqDocImpl)  
			((BioseqDocImpl)fInfo).updateRange( changeflags, start, length, changes);
		}
		
  public void UpdateFlds() {     
    //fLength= fSeq.length; //?! NO, don't have this in sync w/ array size yet

    SeqInfo si= getSeqStats(0,fLength);
    fKind     = (short)si.getKind();
    fChecksum = si.getChecksum();

    }




	// MASKS =================================


  public final void SetMasks(byte[] theMasks) {
  	SetMasks( theMasks, true);
  	}
  	 
  public void SetMasks(byte[] theMasks, boolean duplicate) { 
    if (theMasks!=null) {
    	int minlen= Math.min( theMasks.length, fSeq.length);
    	for (int i=0; i<minlen; i++) fSeq[i].mask= theMasks[i];
      }
    else {
      fMasksOk= false;
      }
   	FixMasks();
    }

  public final void SetMasks(Bioseq theMasks, boolean fromtext) {
  	SetMasks( theMasks, fromtext, true);
  	}
  	
  public void SetMasks(Bioseq theMasks, boolean fromtext, boolean duplicate) { 
    if (theMasks!=null) {
    	int minlen= Math.min( theMasks.length(), fSeq.length);
    	Biobase[] masks= theMasks.bases();
    	for (int i=0; i<minlen; i++) {
    		byte m= masks[i].c;
    		if (fromtext) m= (byte) ((m - '?') | 0x80);
    		fSeq[i].mask= m;
    		}
      }
    else {
      fMasksOk= false;
      }
   	FixMasks();
    }

  public void FixMasks() { 
    for (int i=0; i<fSeq.length; i++) { fSeq[i].mask |= 0x80; }
    fMasksOk= true;
    }

  public boolean hasMask() { 
    for (int i=0; i<fSeq.length; i++) 
    	if ((fSeq[i].mask & 0x7F) != 0) return true; 
		return false;
    }

	public static boolean MaskToText(byte[] mask) {
    boolean hasdata= false;
    for (int i=0; i<mask.length; i++) { 
			mask[i] &= 0x7F; // drop hi bit
		 	if (mask[i] != 0) hasdata= true;
			mask[i] += '?';  // set 0 == '?', mask range is mostly 'A-Za-z'
			}
		return hasdata;
		}
		
	public static boolean MaskFromText(byte[] mask) {
    boolean hasdata= false;
    for (int i=0; i<mask.length; i++) { 
   		mask[i] -= '?';	// to zero relative
		 	if (mask[i] != 0) hasdata= true;
   		mask[i] |= 0x80;	// add high bit
			}
		return hasdata;
		}
		
  public int MaskAt(int baseindex, int masklevel) { 
    int b = kMaskEmpty;
    if (fSeq!=null && fMasksOk && baseindex>=0 && baseindex<fLength) {
    	b= fSeq[baseindex].maskBit(masklevel);
      }
    return b;
    }

  public final void SetMaskAt(int baseindex, int masklevel) { 
  	SetMaskAt( baseindex, masklevel, 1); }
  	
  public void SetMaskAt(int baseindex, int masklevel, int maskval) { 
    if (fSeq!=null && fMasksOk && baseindex>=0 && baseindex<fLength)  
     	fSeq[baseindex].setMask(masklevel, maskval);
      //fSeq[baseindex].mask= SetMaskByte(fSeq[baseindex].mask,masklevel, maskval);
  }

  public void FlipMaskAt(int baseindex, int masklevel) { 
		if (fSeq!=null && fMasksOk && baseindex>=0 && baseindex<fLength)  
   		fSeq[baseindex].flipMask(masklevel);
     	//fSeq[baseindex].mask= FlipMaskByte(fSeq[baseindex].mask,masklevel);
    }

  public void ClearMaskAt(int baseindex, int masklevel) { 
 		SetMaskAt(baseindex, masklevel, 0); 
 		}

  public final void SetMask(int masklevel) { SetMask( masklevel, 1); }
  public void SetMask(int masklevel, int maskval) { 
    int  baseindex;
    if (fSeq!=null && fMasksOk) 
  		for (baseindex=0; baseindex<fLength; baseindex++) 
      	fSeq[baseindex].setMask(masklevel, maskval);
  			//fSeq[baseindex].mask= SetMaskByte(fSeq[baseindex].mask, masklevel, maskval);
    }

  public void FlipMask(int masklevel) { 
    int  baseindex;
    if (fSeq!=null && fMasksOk) 
   		for (baseindex=0; baseindex<fLength; baseindex++)  
    		fSeq[baseindex].flipMask(masklevel);
     		//fSeq[baseindex].mask= FlipMaskByte(fSeq[baseindex].mask, masklevel);
    }

  public void ClearMask(int masklevel) { SetMask(masklevel, 0); }

}



public class DConsensusSequence extends DSequence
{
	public DConsensusSequence() { super(); }
	public DConsensusSequence(int maxlen) { super(maxlen); } 
  protected void init() {
  	super.init();
    setName(kConsensus);
    }
}




