// iubio.readseq.help.java -- was in readseqrun.java

/*
main calls
	done: iubio.readseq.run => classic readseq commandline options
	done: iubio.readseq.app => window/gui interface (swing-based)
	done: iubio.readseq.cgi => HTTP server cgi interface 
	
	use IBM trick - put real main in package and wrapper main w/o package ?
	other uses:  rs= new iubio.readseq.run(); rs.getargs(args); rs.run(); -- support Runnable iface?
*/


package iubio.readseq;


import java.io.*;
import java.net.URL;
import java.util.Hashtable;
import java.util.Enumeration;

import iubio.bioseq.SeqRange;
import iubio.bioseq.SeqRangeException;
import iubio.readseq.*;

import flybase.Args;
import flybase.Debug;
import flybase.Utils;
import flybase.AppResources;
import flybase.FastVector;
import flybase.Environ;


public class help
{
	static public void main(String[] args)  { new help(); }
	public help() { this(System.out); }
	public help( PrintStream out) {
		out.println("Programs available in this package");
		rule(out);
		out.println("  For the current help document");
		out.println("    jre -cp readseq.jar help ");
		String homeurl= Environ.gEnv.get("APP_SOURCE_URL");
		if (homeurl.length()>0) {
		out.println("  Home of this package");
		out.println("    " + homeurl);
		}
		rule(out);
		app.appusage(out);
		rule(out);
		cgi.cgiusage(out);
		rule(out);
		run.usage(out);
		rule(out);
	}
	void rule(PrintStream out) {	for (int i= 0; i<20; i++) out.print('-'); out.println(); }
}