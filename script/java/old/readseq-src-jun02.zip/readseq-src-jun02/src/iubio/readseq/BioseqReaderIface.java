// BioseqReaderIface.java
// d.g.gilbert


package iubio.readseq;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.io.IOException;
import java.util.Hashtable;

import flybase.OpenString;



public interface BioseqIoIface
{
	public int formatID(); //? formatID() ? hashCode of name or content-type 
	public void setFormatID(int id); //? Readseq sets id?
}

public interface MessageApp {
	public void errmessage(String s);
	public void infomessage(String s);
}

public interface BioseqReaderIface
	extends BioseqIoIface
{
		/** flag for setChoice() to return only list of sequence IDs */
	public final static int kListSequences =  -1; 

		/** set input stream */
	public void setInput( Reader ins);
	//public void setInput( InputStream ins); // not using byte-input streams now

		/** end of sequence input stream was reached */
	public boolean endOfFile();
	
		/** reset input stream for re-read (interleaved formats) */
	public void reset();			
	
		/** reset sequence storage for new sequence */
	public void resetSeq();  

		/** select which sequence to read 
			* @param seqchoice - index from 1 of sequence in stream
			*/
	public void setChoice(int seqchoice);
			
		/** get total number of sequences read <p>
			* may not be valid till all data read, 
			* or return number of current sequence after doRead() 
			*/
	public int  getNseq();  
	
		/** read next sequence to internal data
			* @see setChoice()
			*/
	public void doRead() throws IOException;
	
		/** copy last read sequence to storage record */
	public void copyto( SeqFileInfo si); 
	
		/** skip past non-sequence info at top of stream <p>
			* @param skiplines - presumed number of lines to skip past
			*/
	public void skipPastHeader(int skiplines);
	
		/** reads all of sequence entries in stream, writing to writer <p>
			* for piping from one format to another 
			*/
	public void readTo( BioseqWriterIface writer, int skipHeaderLines)  throws IOException;

		/** read one sequence to SeqFileInfo structure */
	public SeqFileInfo readOne( int whichEntry) throws IOException;
	
};


	/** base translator for writer */
public interface OutBiobaseIntf
{
	public int outSeqChar(int c);
}


public interface BioseqWriterIface
	extends BioseqIoIface
{
	public void setOutput( Writer outs);
	public void setOutput( OutputStream outs); // mainly for System.out
	public void close() throws IOException;
	public int getError();

		// add some opts - dochecksum, ??
		/** true if reader should collect documentation/features for this writer.
				false can mean speedier processing. */
	public boolean wantsDocument();
		
			/** per output stream */
	public void setNseq( int nsequences);
	public void writeHeader() throws IOException;  
	public void writeTrailer();  
	

			/** per sequence */
	public boolean setSeq( SeqFileInfo si);  
	public boolean setMask( SeqFileInfo si, String masktag);
	public boolean setSeq( Object seqob, int offset, int length, String seqname,
						 Object seqdoc, int atseq, int basepart);  

	public void setSeqName( String name); //? don't need in iface? 
	
		/** set list of features to extract sequence of (good only if hasdoc) */
	public void setFeatureExtraction(Hashtable featurelist);  

		/** get output translation/conversion of sequence chars */
	public OutBiobaseIntf getOutputTranslation();
	
		/** set output translation/conversion of sequence chars */
	public void setOutputTranslation( OutBiobaseIntf tester);

		/** write a full seq record, given setSeq() <p>
			* implementation does writeRecordStart(), writeDoc(), writeSeq(), writeRecordEnd()
			*/
	public void writeSeqRecord() throws IOException;  
			
		/** start of sequence record, initialize per seq, subclasses customize as needed */
	public void writeRecordStart();  

		/**  write documentation for record, form where all doc is known from setSeq() */
	public void writeDoc();   
	
		/**  write sequence data, when all seq is known from setSeq()  */
	public void writeSeq();  

		/**  end of seq before newline or end of record - called at end of writeSeq() generally */
	public void writeSeqEnd();  

		/**  end of seq record  */
	public void writeRecordEnd();  

};

