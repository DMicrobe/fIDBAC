// BioseqDoc.java
// sequence format information (document,features) handlers
// d.g.gilbert, 1997++


package iubio.readseq;


import java.io.*;
import java.util.*;

import iubio.bioseq.*;
import flybase.*;
import Acme.Fmt;


public interface BioseqDocVals
{
		// some common fields among formats
		// !! update getBioseqdocProperties() below if changes are made here
		// see also BioseqDoc.properties
		
	public final static int 
		kUnknown = 0,  // for extras ...
		kBioseqSet=1, 
		kBioseq=2,  
		kBioseqDoc=3,
		kName = 10, // == ID in general
		kDivision= 11, // databank division: INV, UNA, etc... db specific
		kDataclass= 12, // data class: standard, preliminary, unannotated, backbone
		kDescription = 20,
		kAccession = 30,
		kNid = 31,
		kVersion = 32,
		kKeywords = 40,
		kSource = 50,
		kTaxonomy = 51,
		kReference = 60,
		kAuthor = 61,
		kTitle = 62,
		kJournal = 63,
		kRefCrossref = 64,
		kRefSeqindex = 65,
			
			// various feature flds
		kFeatureTable = 70,
		kFeatureItem = 71,
		kFeatureNote = 72,
		kFeatureKey= 73,
		kFeatureValue=74,
		kFeatureLocation=75,  

		kDate = 80,
		kCrossRef = 90,
		kComment = 100,
		
			// sequence fields
		kSeqstats = 110, // base counts, length, ...
		kSeqdata = 111,
		kSeqlen = 112,
		kSeqkind= 113, //DNA, RNA, tRNA, rRNA, mRNA, uRNA
		kChecksum= 114,
		kSeqcircle= 115, // circular (linear default)
		kStrand= 116, 	// ds, ss, ms
		kNumA= 117, kNumC= 118, kNumG= 119, kNumT = 120, kNumN= 121, // kSeqStats breakdown
		kBlank = 200
			;

			// flags for parsing location in doc
	public final static int 
		kBeforeFeatures = 0,  kAtFeatureHeader= 1, kInFeatures = 2, kAfterFeatures= 3;

			// flags for general doc field kind
	public final static int 
		kField = 1, kSubfield = 2, kContinue = 3, 
		kFeatField= 4, kFeatCont = 5, kFeatWrap= 6;
}

		
public interface BioseqDoc
	extends BioseqDocVals
{
	public String getID();
	public String getTitle();
	public String getFieldName(int kind); //? change to keys - or enumerate keys?
	public String getDocField(int kind);  
	public String getBiodockey(String field); 

	public void addBasicName(String line);
	public void addDocLine(String line); 	
	public void addDocLine(OpenString line); 	
	public void addDocField(String field, String value, int level, boolean append);
				// ^^ drop leve, append from interface ?
				
	public FastVector documents(); 	//? change to enumeration?
	public FastVector features(); 	//?  ""
	
			//?? add these methdods to iface from Impl
	// setWantedFeatures(exfeatures);
	// SeqRange featsr= bdi.getFeatureRanges(seqlen);
	// replaceDocItem( BioseqDocVals.kSeqlen, ...);

}


