// dclap/util/sortvector.java


package flybase; //.util ?

import java.util.Vector;
import java.util.Enumeration;


public interface CompareTo {
	public int compareTo( Object b);
}

public interface Comparator {
	public int compare(int a, int b);
}

public interface ObjectComparator {
	public int compareObjects(Object a, Object b);
}

public class StringComparator implements ObjectComparator 
{
	public int compareObjects( Object a, Object b) {
		return a.toString().compareTo( b.toString()); //? or cast (String) - safer or faster?
		//return ((String)a).compareTo((String)b); 
		}
}

public interface ComparableVector {
	public int compareAt(int a, int b);
}

public class CompareStrings implements ComparableVector 
{
	// a basic implementation
  FastVector fv;
  public CompareStrings(FastVector stringVector) { this.fv= stringVector; }
	public int compareAt(int a, int b) {
		String sa= (String) fv.elementAt(a);
		String sb= (String) fv.elementAt(b);
		return sa.compareTo(sb);
		}
};

 
public class SortedEnumeration {
  FastVector vec;
  ObjectComparator cmp;

	public SortedEnumeration( Enumeration en) {
		this( en, new StringComparator());
		}
		
	public SortedEnumeration( Enumeration en, ObjectComparator cmp) {
		this.vec= new FastVector();
		while (en.hasMoreElements()) vec.addElement( en.nextElement());
		resort( cmp);
    }

	public FastVector vector() { return vec; }
	public Enumeration elements() { return vec.elements(); }
	
	public void resort( ObjectComparator cmp )	{
		this.cmp= cmp;
		quickr( 0, vec.size()-1);
		}
				
	protected final int compare(int a, int b) {
		//if (a < 0 || a >= vec.size()) return -1;
		//if (b < 0 || b >= vec.size()) return 1;
		return cmp.compareObjects( vec.elementAt(a), vec.elementAt(b));
		}

	protected final void swap(int a, int b) {
		//if (a < 0 || a >= vec.size() || b < 0 || b >= vec.size()) return;
		Object aob= vec.elementAt(a);
		vec.setElementAt(vec.elementAt(b), a);
		vec.setElementAt(aob, b);
		}

	protected void quickr( int min, int max) 
 	{
		if (min < max) {
	     int lo = min; 
	     int hi = max;  
	     do {
	       while (lo < hi && compare( lo, max) <= 0) lo++;
	       while (hi > lo && compare( hi, max) >= 0) hi--;  
	       if (lo < hi) swap( lo, hi);
	     } while (lo < hi);
	     swap( lo, max);
	     if (lo - min < max - lo) {
	       quickr( min, lo-1);
	       quickr( lo+1, max);
	       }
	     else {
	       quickr( lo+1, max);
	       quickr( min, lo-1);
	    	}
			}
	}

}


public class QSortVector extends SortVector 
{
	protected Comparator cmp;
	public QSortVector(Vector v, ComparableVector cv) { super(v,cv); }
	public QSortVector(FastVector v, ComparableVector cv) { super(v,cv); }
	public QSortVector(FastVector v, ComparableVector cv, Comparator cmp) { 
		super(v,cv); 
		this.cmp= cmp;
		}
	
	public void sort() { 
		if (cmp!=null) quickrc(0, size()-1);
		else quickr( 0, size()-1); 
		}

	protected void quickrc( int min, int max) 
 	{
		if (min < max) {
	     int lo = min; 
	     int hi = max;  
	     do {
	       while (lo < hi && cmp.compare( lo, max) <= 0) lo++;
	       while (hi > lo && cmp.compare( hi, max) >= 0) hi--;  
	       if (lo < hi) swap( lo, hi);
	     } while (lo < hi);
	     swap( lo, max);
	     if (lo - min < max - lo) {
	       quickrc( min, lo-1);
	       quickrc( lo+1, max);
	       }
	     else {
	       quickrc( lo+1, max);
	       quickrc( min, lo-1);
	    	}
			}
	}
	
	protected void quickr( int min, int max) 
 	{
		if (min < max) {
	     int lo = min; 
	     int hi = max;  
	     do {
	       while (lo < hi && compare( lo, max) <= 0) lo++;
	       while (hi > lo && compare( hi, max) >= 0) hi--;  
	       if (lo < hi) swap( lo, hi);
	     } while (lo < hi);
	     swap( lo, max);
	     if (lo - min < max - lo) {
	       quickr( min, lo-1);
	       quickr( lo+1, max);
	       }
	     else {
	       quickr( lo+1, max);
	       quickr( min, lo-1);
	    	}
			}
	}
    
}


public abstract class SortVector  {
	protected Vector v;
	protected FastVector fv;
	protected ComparableVector cv;
	
	public SortVector(Vector v, ComparableVector cv) { 
		this.v= v; this.cv= cv;
		}
	public SortVector(FastVector v, ComparableVector cv) { 
		this.fv= v; this.cv= cv;
		}

  abstract public void sort();

	public void setVector(Vector v, ComparableVector cv) { 
		this.v= v; this.cv= cv;
		}
	public void setVector(FastVector v, ComparableVector cv) { 
		this.fv= v; this.cv= cv;
		}
		
	protected final int size() { return (fv!=null)?fv.size():v.size(); }

/**
	public int compare( CompareTo a, CompareTo b) {
		return a.compareTo(b);
			// subclass this
		if (a.hashCode() < b.hashCode()) return -1;
		if (a.hashCode() > b.hashCode()) return 1;
		return 0;	
		}
**/
		
	protected final int compare(int a, int b) {
		if (a < 0 || a >= size()) return -1;
		if (b < 0 || b >= size()) return 1;
		return cv.compareAt( a, b);
		//return compare( (CompareTo)v.elementAt(a), (CompareTo)v.elementAt(b));
		}
		
	protected void swap(int a, int b) {
		if (a < 0 || a >= size()
		 || b < 0 || b >= size()) 
		   return;
		if (fv!=null) {
			Object aob= fv.elementAt(a);
			Object bob= fv.elementAt(b);
			fv.setElementAt( bob, a);
			fv.setElementAt( aob, b);
			}
		else {
			Object aob= v.elementAt(a);
			Object bob= v.elementAt(b);
			v.setElementAt( bob, a);
			v.setElementAt( aob, b);
			}
		}
		
}




