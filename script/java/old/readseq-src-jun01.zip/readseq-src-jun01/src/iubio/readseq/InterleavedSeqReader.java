// InterleavedSeqReader.java -- was seqread2.java
// low level readers & writers : interleaved formats
// d.g.gilbert, 1990-1999


package iubio.readseq;


import java.io.*;
import java.util.Date;
import java.text.SimpleDateFormat;

import Acme.Fmt;
import flybase.Debug;
import flybase.OpenString;
import flybase.Native;

import iubio.bioseq.BaseKind;
import iubio.bioseq.SeqInfo;
import iubio.bioseq.Bioseq;

// PaupSeqFormat reader needs work/test
// PrettySeqFormat not readable
// OlsenSeqFormat not readable yet

 

public class InterleavedSeqReader  extends BioseqReader
{
	protected int skipHeaderLines;
	protected boolean firstpass= true;
	
	public void readTo( BioseqWriterIface writer, int skipHeaderLines)  throws IOException 
	{
		this.skipHeaderLines= skipHeaderLines;
		super.readTo( writer, skipHeaderLines);
		firstpass= false;
	}
	
	public SeqFileInfo readOne( int whichEntry) throws IOException
	{
		this.reset();  
		this.skipPastHeader( skipHeaderLines);  
		SeqFileInfo si= super.readOne( whichEntry);
		firstpass= false;
		return si;
	} 

	public void setInput(Reader ins) {  
		super.setInput(ins);
		firstpass= true; // cant do in reset()
		}

	public boolean endOfFile() { //??????????? 
	  return super.endOfFile();
	  //return ((atseq==0 || firstpass) ? super.endOfFile() : (atseq >= nseq)); //return fEof;
		}
}

		 
public abstract class InterleavedSeqWriter  extends BioseqWriter
{
	protected File tempFile;
	protected FileIndex fileIndex;
	protected String saveLineEnd;
	protected boolean interleaved= true;
	
	public InterleavedSeqWriter() {}
	
	
	public void finalize() throws Throwable  
	{ 
		//if (!(Debug.isOn)) 
		if (tempFile!=null) { tempFile.delete(); tempFile= null; }
		super.finalize();
	}
		
	public boolean interleaved() { return interleaved; }
	public void setinterleaved(boolean turnon) { interleaved= turnon; }

	public void writeRecordStart() 			// per seqq
	{
		if (interleaved()) fileIndex.indexit();  
		super.writeRecordStart();
	}

	public void writeHeader() throws IOException 			// per file
	{ 
		super.writeHeader();
			// redirect output per seqq to temp file after main header
		if (interleaved()) {
			try {
				//if (Debug.isOn)	
				//	tempFile= new File( dclap.DApp.application().getCodePath(), "interleave.tmp");
				//else 
					tempFile= Native.tempFile();
				Writer tos= new BufferedWriter( new FileWriter(tempFile));
				//douts= new DataOutputStream(tos);
				fileIndex= new FileIndex(tos);
				douts= fileIndex;
				saveLineEnd= lineSeparator;
				lineSeparator= "\n"; // Aaaarrgggggggghhhhhhhh!!!!!! for readLine by RandomAccessFile
				}
			catch (IOException ex) { ex.printStackTrace(); }
			}
	}
	
	public void writeTrailer()  // per file 
	{ 
		if (interleaved()) {
			lineSeparator= saveLineEnd; // Aaaarrgggggggghhhhhhhh!!!!!!
			fileIndex.indexEOF(); 
			try { douts.close(); } catch (IOException ex) {}
					// reset output from temp to final stream
			setOutput(outs);
			/*
			if (outs instanceof BufferedWriter) douts=(BufferedWriter)outs ;//DataOutputStream
			else douts= new BufferedWriter(outs);//DataOutputStream
			*/
			interleaveHeader(); //??
			interleaveOutput();
			}
		super.writeTrailer();
	}
	
	protected void interleaveHeader() {}
	protected void interleaf(int leaf) {}
	
	protected void interleaveOutput()
	{
		int sn= fileIndex.indexCount();
		long[] sindex= fileIndex.indices();
		int nlines = linesout; // # lines written for last seqq (set 0 each writeInit)
		try {
			RandomAccessFile tempis= new RandomAccessFile(tempFile, "r");
			for (int leaf=0; leaf<nlines; leaf++) {
				for (int iseq=0; iseq<sn; iseq++) {
					String line= "";
					tempis.seek( sindex[iseq]);
					for (int iline=0; iline <= leaf; iline++)
				  	if ((line= tempis.readLine())==null) line= "";
				 	if (tempis.getFilePointer() <= sindex[iseq+1]) {
				  	writeString( line);  //readLine DOESN'T retain newline??????
	      		writeln();
				  	}
				 }
			 interleaf(leaf); 
			 }
			tempis.close();
			}
		catch (Exception ex) { ex.printStackTrace(); }
		//if (!(Debug.isOn)) 
		{ tempFile.delete(); tempFile= null; }
	}
	
}




class FileIndex extends BufferedWriter
{
	long[]	fIndices;
	int	fMax, fNum;
	long 	written;
	
	FileIndex(Writer wr) 
	{
		super(wr);
		fNum= 0;
		fMax= 20;
		fIndices= new long[fMax];
		//fIndices[fNum++]= 0; //????
		written= 0;
	}

 	long[] indices() { return fIndices; }
 	int  	indexCount() { return fNum; }
	
	void indexit( long index)
	{
		if (fNum >= fMax) {
			fMax *= 2; 
			long[] itmp= new long[fMax];
			for (int i= 0; i<fNum; i++) itmp[i]= fIndices[i];
			fIndices= itmp;
			}
		fIndices[fNum++]= index;
	}

	public void write(char cbuf[], int off, int len) throws IOException {
		super.write(cbuf, off, len);
		written += len;
		}
	public void write(int c) throws IOException {
		super.write(c);
		written += 1;
		}
	public void write(String s, int off, int len) throws IOException {
		super.write(s,off,len);
		written += len;
		}

	public long size() { return written; }
	
	//final void indexit(DataOutputStream daos) { indexit( daos.size()); }
	final void indexit() { indexit( this.size()); }

	final void indexEOF() {
		indexit( this.size());
		fNum--;
		}

};





	// here only for classic Readseq compatibility, see PhylipSeqFormat
public class Phylip2SeqFormat extends PhylipSeqFormat 
{
	public Phylip2SeqFormat() { super(); }
	public String formatName() { return "Phylip3.2"; }  
	public String formatSuffix() { return ".phylip2"; } 
	public String contentType() { return "biosequence/phylip2"; } 
	public BioseqWriterIface newWriter() { 
		PhylipSeqWriter c= new PhylipSeqWriter(); 
		c.setinterleaved(false); // always for this format?
		return c; 
		}
}

public class PhylipSeqFormat extends BioseqFormat
{
	protected SeqInfo seqkind;
	protected boolean formatDetermined;
	protected boolean interleaved= true; // assume yes?
	protected int isleaf, isseq;

	protected NumSppBases nsppb;	
	//protected boolean gotSppLen;
	//protected int nospp, baselen;
	
	public PhylipSeqFormat() {
		//seqkind= new SeqKind( 99999, false, false);
		seqkind= SeqInfo.getSeqInfo( 99999, false, false);
		nsppb= new NumSppBases();
		}

		//fileSuffix= ".phylip3";
		//mimeType= "biosequence/phylip3";
		
	public String formatName() { 
		getsubformat();
		if (interleaved) return "Phylip|Phylip4"; 
		else return "Phylip3.2|Phylip2"; 
		}  
	public String formatSuffix() { return ".phylip"; } 
	public String contentType() { return "biosequence/phylip"; } 
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean interleaved() { getsubformat(); return interleaved; }
	public boolean needsamelength() { return true; }

	public BioseqWriterIface newWriter() { 
		getsubformat();
		PhylipSeqWriter c= new PhylipSeqWriter(); 
		c.setinterleaved(interleaved);
		return c; 
		}
		
	public BioseqReaderIface newReader() {
		getsubformat();
		PhylipSeqReader c;
		if (interleaved) c= new PhylipSeqReader(); 
		else c= new Phylip2SeqReader();
		//? set some flags in c ?
		return c; 
	}
	
	protected void getsubformat() {
		if (!formatDetermined) {
			if (isleaf > isseq) interleaved= true;  
			else if (isleaf < isseq) interleaved= false;  
			else interleaved= true; 
			formatDetermined= true;
			}
		}	

		// format testing =============================	

	public void formatTestInit() { 
		super.formatTestInit(); 
		isleaf= isseq= 0;
		interleaved= true;
		formatDetermined= false;
		//nospp= 0; baselen= 0; gotSppLen= false; 
		nsppb.init();
		}

	public boolean formatTestLine( OpenString sp, int atline, int skiplines) 
	{
		atline -= skiplines;
		if (atline == 1)  
  		nsppb= readSpeciesLength(sp);
  		
		else if (atline == 2 && nsppb.good && sp.length()>10) {
      //int tseq= Bioseq.getSeqtype(sp, 10, sp.length()-10);
			seqkind.add( sp.getValue(), sp.getOffset()+10, sp.length()-10);	
			int tseq= seqkind.getKind();
      if (Character.isLetter(sp.charAt(0))   // 1st letter in 2nd sp must be of a name 
       && (tseq != Bioseq.kOtherSeq)) {			 // sequence section must be okay 
	     	formatLikelihood = 85; // 90 causes checker to stop
	     	//return true; //? or not to keep reading && test subformat
	     	//formatId= Readseq.kPhylipUndetermined;
	     	formatDetermined= false;
	     	}
      }
      
    else if (atline > 2 && nsppb.good) {
			int j, tseq, tname;
      //tname= Bioseq.getSeqtype(sp, 0, 10);
      //tseq=  Bioseq.getSeqtype(sp, 10, sp.length()-10);
      	// can we assume leading whitespace is preserved and format indicator?
      for (j=0; Character.isWhitespace(sp.charAt(j)) && j<10; j++)  ;
      if (atline - 1 <= speciesCount()) {
      	if (j<9) isleaf++; else isseq++;
      	}
      else {
      	if (j>=9) isleaf++; else isseq++;
      	}
    	}
		return false;
	}

			// these are used also by PhylipSeqReader !?!
	public final int speciesCount() { return nsppb.nospp; }
	public final int sequenceLength() { return nsppb.baselen; }
	
	public static NumSppBases readSpeciesLength( OpenString sp) 
	{
    //sscanf( sp, "%d%d", &nospp, &baselen);
    // this is kind of messy w/o a sscanf !
		int nospp= 0; 
		int baselen= 0;
    int i, j, n= sp.length();
    for (i=0; i<n && Character.isWhitespace(sp.charAt(i)); i++) ;
    for (j=i; j<n && Character.isDigit(sp.charAt(j)); j++) ;
    try { if (i<n) nospp= Integer.parseInt(sp.substring(i,j).toString()); }
    catch (NumberFormatException ex) {}
    if (nospp>0) {
      for (i=j+1; i<n && Character.isWhitespace(sp.charAt(i)); i++) ;
      for (j=i; j<n && Character.isDigit(sp.charAt(j)); j++) ;
      try { if (i<n) baselen= Integer.parseInt(sp.substring(i,j).toString()); }
      catch (NumberFormatException ex) {}
    	}
		if (nospp > 0 && baselen > 0)
			Debug.println("phylip nspp="+nospp+", nbase="+baselen);
    //return (nospp > 0 && baselen > 0);
    return new NumSppBases(nospp,baselen);
	}

	
}

class NumSppBases {
	boolean good;
	int nospp, baselen;
	NumSppBases() { this(0,0); }
	NumSppBases(int nospp, int baselen) { 
		this.nospp= nospp; this.baselen= baselen;
		good= (nospp>0 && baselen>0);
		}
	void init() { nospp= baselen= 0; good= false; }
}


//public
class Phylip2SeqReader  extends PhylipSeqReader
{
	public Phylip2SeqReader() {
		super();
		interleaved= false;
		}
		
	public boolean endOfSequence() {
		return endSequential();
		}
	protected void read() throws IOException {
		readSequential(); 
		}

	/*public Object clone() {
		Phylip2SeqReader c= (Phylip2SeqReader) super.clone();
		//? doesn't clone() copy vals of method data ?
    return c;
 		}*/

	protected boolean endSequential()
	{
		ungetend= false;
		countseq(getreadchars(), getreadcharofs()+margin, nWaiting); //countseq(sWaiting);
		boolean done= ( seqlencount >= sequenceLength());
	 	addend= !done;
		return done;
	}

	protected void readSequential() throws IOException
	{
		if (sequenceLength()==0 || speciesCount() == 0) {
	    NumSppBases nsppb= PhylipSeqFormat.readSpeciesLength(sWaiting); //!? must have already read these?
	    nospp= nsppb.nospp;
	    baselen= nsppb.baselen;
			Debug.println("format: phylip-sequential, nspp="+speciesCount()+", nbase="+sequenceLength());
			getline();
			}
		setNseq(speciesCount());
	  while (!allDone) {
	    seqlencount= 0;
	    seqid= sWaiting.substring(0,10).toString();
	    sWaiting= sWaiting.substring(10);
	    nWaiting= sWaiting.length();

	    margin= 0;
	    addfirst= true;
	    readLoop();
	    if (endOfFile()) allDone = true;
	  	}
	}

}


//public
class PhylipSeqReader  extends InterleavedSeqReader //InterleavedSeqreader
{
	final static int kNameWidth= 10; 
	protected int nospp= 0, baselen= 0;
	//protected boolean formatDetermined;
	protected boolean interleaved;
	
	public PhylipSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 12;
		interleaved= true;
		//formatDetermined= false;
		}
 	
	/*public Object clone() {
		PhylipSeqReader c= (PhylipSeqReader) super.clone();
		//? doesn't clone() copy vals of method data ?
		c.nospp= nospp;
		c.baselen= baselen;
    return c;
 		}*/

	public boolean endOfSequence() {
		return true;
	}

	protected void read() throws IOException
	{
		readInterleaved();
	}

	public final int speciesCount() { return nospp; }
	public final int sequenceLength() { return baselen; }

	protected void readInterleaved() throws IOException
	{
	  boolean done, first = true;
	  int     iline= 0;

		addit = (choice > 0);
	  if (addit) seqlen = seqlencount= 0;
		//? already have read?
		if (sequenceLength()==0 || speciesCount() == 0) {
	    NumSppBases nsppb= PhylipSeqFormat.readSpeciesLength(sWaiting); //!? must have already read these?
	    nospp= nsppb.nospp;
	    baselen= nsppb.baselen;
			Debug.println("format: phylip-interleaved, nspp="+speciesCount()+", nbase="+sequenceLength());
			}
			
		setNseq(speciesCount());
	  do {
			getline();
	 		done = endOfFile();
	    if (done && nWaiting==0) break;
	    OpenString si= sWaiting.trim();
	    if (si.length()>0) {

	      if (first) {  
	      	// collect seqq names + seqq, as fprintf(outf,"%-10s  ",seqname); 
	        //! nseq++; //setNset() did this !
	        atseq++; //??
	        if (atseq >= speciesCount()) first= false; //?
	        if (choice == kListSequences) 
	          addinfo( sWaiting.substring(0,kNameWidth).trim().toString());
	          
	        else if ( atseq == choice) {
	          addseq( getreadchars(), getreadcharofs()+kNameWidth, nWaiting-kNameWidth); // sWaiting.substring(10);
	          seqid=  sWaiting.substring(0,kNameWidth).trim().toString();
	          }
	        }
	      else if ( iline % atseq == choice - 1 ) 
	        addseq( getreadchars(), getreadcharofs()+kNameWidth, nWaiting-kNameWidth);
	        
	  		iline++;
	    	}
	  } while (!done);
		allDone = true;
	}

};


//public
class PhylipSeqWriter extends InterleavedSeqWriter
{
	BufferedWriter tempOs;
	int lastlen;
	String lenerr;
	
	public void writeHeader() throws IOException { 
		super.writeHeader();
		if (!interleaved()) {
			// interleaveHeader(); //! need to count nseq, seqlen first !
			tempFile= Native.tempFile();
			tempOs= new BufferedWriter( new FileWriter(tempFile));
			douts= tempOs;
			}
		}
	
	public void writeRecordStart() {
		super.writeRecordStart();
   	opts.spacer = 10;
    opts.tab = 12; 
    l1  = -1; //??
		}

	public void writeDoc() {
		super.writeDoc();
			//!! must we TRuncate idword? -- probably, but causes hassles! e.g. #Mask cut
		writeString( Fmt.fmt( idword, 10, Fmt.TR + Fmt.LJ) + "  ");
    //linesout += 0; // no newline !
 		}

	protected void interleaf(int leaf) {
		writeln(); // is newline legal for phylip here?
		}
		
	protected void interleaveHeader() {
   	writeString(" " + nseq);  // these are 0 if not interleaved !?
    writeString(" " + seqlen);
  	if (interleaved()) 
     	writeln(); //sprintf( line, " %d %d\n", nseqs, nbases);  // " %d %d F\n"
   	else 
     	writeln(" I "); //sprintf( line, " %d %d I \n", nseqs, nbases);  // " %d %d FI \n"
	}

	public boolean setSeq( Object seqob, int offset, int length, String seqname,
						 Object seqdoc, int atseq, int basepart) 
	{
		if (lastlen > 0 && length != lastlen) {
			if (lenerr==null) lenerr= String.valueOf(lastlen) + " != ";
			lenerr += String.valueOf(length) + ", ";
			length= lastlen; // can we pad/trunc to first length?
			}
		else lastlen= length;
		return super.setSeq(seqob,offset,length,seqname,seqdoc,atseq, basepart);
	}
	
	public void writeTrailer()  // per file 
	{ 
		if (lenerr!=null) {
			BioseqReader.message("Warning: this format requires equal sequence lengths.");
			BioseqReader.message("       : lengths are padded/truncated to "+lastlen);
			BioseqReader.message("       : " + lenerr);
			}
			
		if (!interleaved()) {
			try { douts.close(); } catch (IOException ex) {} // == tempOs
					// reset output from temp to final stream
			setOutput(outs);

			interleaveHeader();  
			sequentialOutput();
			}
		super.writeTrailer();
	}
	
	
	protected void sequentialOutput()
	{
		try {
			Reader tempis= new FileReader(tempFile);
			char[] buf = new char[2048];
			int nread;
			while ( (nread= tempis.read(buf)) >= 0)  
				douts.write(buf, 0, nread);
			tempis.close();
			}
		catch (Exception ex) { ex.printStackTrace(); }
		//if (!(Debug.isOn)) 
		{ tempFile.delete(); tempFile= null; }
	}

	
};



public class ClustalSeqFormat extends BioseqFormat
{		
	public String formatName() { return "Clustal";  }  
	public String formatSuffix() { return ".aln"; }  
	public String contentType() { return "biosequence/clustal"; }  
	public boolean canread() { return true; }   
	public boolean canwrite() { return true; }  
	public boolean interleaved() { return true; }  

	public BioseqWriterIface newWriter() { return new ClustalSeqWriter(); }		
	public BioseqReaderIface newReader() { return new ClustalSeqReader(); }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		////CLUSTAL W (1.8) multiple sequence alignment
		if ( line.startsWith("CLUSTAL ") ) {
	      formatLikelihood  = 95;
        if (recordStartline==0) recordStartline= atline;
	      //if (line.indexOf("multiple sequence alignment")>0) return true; else 
	      return true; // ??
	      }
    else
    	return false;
	}
}

/*
CLUSTAL W (1.8) multiple sequence alignment


HBB_HUMAN       --------VHLTPEEKSAVTALWGKVN--VDEVGGEALGRLLVVYPWTQRFFESFGDLST
HBB_HORSE       --------VQLSGEEKAAVLALWDKVN--EEEVGGEALGRLLVVYPWTQRFFDSFGDLSN
                          *:  :   :   *  .           :  .:   * :   *  :   .

HBB_HUMAN       PDAVMGNPKVKAHGKKVLGAFSDGLAHLDN-----LKGTFATLSELHCDKLHVDPENFRL
HBB_HORSE       PGAVMGNPKVKAHGKKVLHSFGEGVHHLDN-----LKGTFAALSELHCDKLHVDPENFRL
*/

//public
class ClustalSeqReader  extends InterleavedSeqReader  
{
	final static int kNameWidth= 15;  
	
	public ClustalSeqReader() {
		margin	=  0; //? or kNameWidth
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		}

	public boolean endOfSequence() {
		return false;
	}

	protected void read() throws IOException
	{
  	int  iline= 0;
	 	addit = (choice > 0);
	  if (addit) seqlen = seqlencount= 0;
	  boolean  done, first= true;
	  do {
	    getline();
	    done = endOfFile();
	    if (done && nWaiting==0) break;

			OpenString sid= null;
			if (nWaiting>kNameWidth)
	   		sid= sWaiting.substring(0,kNameWidth).trim();
	   		
	    if (sid==null || sid.length()==0) { // includes blanks and conserved line after seqs
	    	if (atseq>0) first= false;
	    	}
	    else {
   	 		if (first) {  
	        if (firstpass) nseq++; /// this is bad - need to stop incrementing 1st time thru
	        atseq++;  
	        if (choice == kListSequences)  addinfo(sid.toString());
	        else if ( atseq == choice ) {
	          addseq( getreadchars(), getreadcharofs()+kNameWidth, nWaiting-kNameWidth); 
	       		seqid= sid.toString();
						} 
    			}
	      else if ( iline % atseq == choice - 1 ) 
	        addseq( getreadchars(), getreadcharofs()+kNameWidth, nWaiting-kNameWidth);
	        
	  		iline++;
	    	}
	  } while (!done);
	  
		allDone = true;
	}

};


//public
class ClustalSeqWriter extends InterleavedSeqWriter //PhylipSeqWriter //?
{
	int lastlen;
	String lenerr;

	public void writeRecordStart() {
		super.writeRecordStart();
   	opts.spacer = 0;
   	opts.seqwidth= 60;
  	opts.nameleft = true;
  	opts.nameflags= Fmt.LJ;
  	opts.namewidth= ClustalSeqReader.kNameWidth;  
   	opts.tab = 1; 
  	//opts.tab = ClustalSeqReader.kNameWidth+1; 
		}
 
	public void writeDoc() {
		super.writeDoc();
		//? writeString( Fmt.fmt( idword, ClustalSeqReader.kNameWidth, Fmt.TR + Fmt.LJ) + "  ");
 		}

	protected void interleaf(int leaf) {
		writeln( Fmt.fmt( " ", ClustalSeqReader.kNameWidth+1, Fmt.TR + Fmt.LJ));  // conserved line:           *:  :   :   *  .           :  .:   * :   *  :   . 
		writeln();  
		}

	protected void interleaveHeader() {
 		writeln("CLUSTAL W (1.8) multiple sequence alignment"); 
 		writeln(); 
 		writeln(); 
	}

	public boolean setSeq( Object seqob, int offset, int length, String seqname,
						 Object seqdoc, int atseq, int basepart) 
	{
		if (lastlen > 0 && length != lastlen) {
			if (lenerr==null) lenerr= String.valueOf(lastlen) + " != ";
			lenerr += String.valueOf(length) + ", ";
			length= lastlen; // can we pad/trunc to first length?
			}
		else lastlen= length;
		return super.setSeq(seqob,offset,length,seqname,seqdoc,atseq, basepart);
	}

	public void writeTrailer()  { 
		if (lenerr!=null) {
			BioseqReader.message("Warning: this format requires equal sequence lengths.");
			BioseqReader.message("       : lengths are padded/truncated to "+lastlen);
			BioseqReader.message("       : " + lenerr);
			}
		super.writeTrailer();
	}
	
};






public class OlsenSeqFormat extends BioseqFormat
{		
	public String formatName() { return "Olsen";  }  
	public String formatSuffix() { return ".olsen"; } // .gb ?
	public String contentType() { return "biosequence/olsen"; } // genbank ?
	
	public boolean canread() { return false; } //! need some work!
	public boolean canwrite() { return false; } // do as genbank
	public boolean interleaved() { return true; }

	public BioseqWriterIface newWriter() { 
		// Olsen editor can read GenBank
		return BioseqFormats.newWriter( 
			BioseqFormats.formatFromContentType("biosequence/genbank"),-1);
		}
		
	public BioseqReaderIface newReader() { return new OlsenSeqReader(); }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.indexOf("identity:   Data:") >=0) {
      formatLikelihood += 95;
      return true;
      }
    else
    	return false;
	}
}

//public
class OlsenSeqReader  extends InterleavedSeqReader //InterleavedSeqreader
{
	public OlsenSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatLabel= "Olsen";
		//formatId= 10;
		}

	public boolean endOfSequence() {
		return false;
		}

	protected void read() throws IOException
	{
			// needs some work...
	}
	
};






public class MsfSeqFormat extends BioseqFormat
{		
	public String formatName() { return "MSF";  }  
	public String formatSuffix() { return ".msf"; }  
	public String contentType() { return "biosequence/msf"; }  
	public boolean canread() { return true; }   
	public boolean canwrite() { return true; }  
	public boolean interleaved() { return true; }  

	public BioseqWriterIface newWriter() { return new MsfSeqWriter(); }		
	public BioseqReaderIface newReader() { return new MsfSeqReader(); }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		int m, t;
		if ( (m= line.indexOf("MSF:")) >= 0 
		  && (t= line.indexOf("Type:", m)) > m 
		  && line.indexOf("Check:", t) > t ) {
	      formatLikelihood += 95;
        if (recordStartline==0) recordStartline= atline;
	      return true;
	      }
    else
    	return false;
	}
}

	// 28sep99 -failing ?
//public
class MsfSeqReader  extends InterleavedSeqReader //InterleavedSeqreader
{
	public MsfSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		testbase= new TestGcgBase();
		testbaseKind= kUseTester;
		//formatId= 15;
		}

	public boolean endOfSequence() {
		return false;
		}	

	//protected OpenString sid;

	protected void read() throws IOException
	{
  	int  at, iline= 0;
		OpenString  sid= new OpenString("");
	  boolean  done, indata= false;
	 	addit = (choice > 0);
	  if (addit) seqlen = 0;
	  seqlencount= 0;
	  do {
	    getline();
	    done = endOfFile();
	    if (sWaiting.startsWith("!!")) continue; // GCG version 9+ comment line
   		OpenString si= sWaiting;
   		int offset= 0;
   		
	    if (done && nWaiting==0) break;
	    
	   	else if (indata) {
	   		//?
	   		offset= 0;
    		while (offset<nWaiting && si.charAt(offset) <= ' ') offset++;
	      if ( offset<nWaiting ) {
        	int seqat;
        	for (seqat= offset; si.charAt(seqat) > ' '; seqat++) ;
	      	OpenString id= si.substring(offset,seqat).trim();
	        Debug.println("msf at id=<"+id+"> match="+id.equals(sid));
	        if (id.equals(sid)) //sid.equals(id)) 
	        	addseq( getreadchars(), getreadcharofs()+seqat, nWaiting-seqat);   
	        iline++;
	        }	   	
	   		}
	   	
	    else if ( (at= si.indexOf("Name: ")) >= 0) {  
	    	// seqq header line 
	      // Name: somename      Len:   100  Check: 7009  Weight:  1.00 
	      //nseq++; 
	      atseq++; 
	      at += 6;
	      if (choice == kListSequences) 
	      	addinfo( si.substring(at).trim().toString());
	      else if (atseq == choice) {
	        seqid= si.substring(at).trim().toString(); 
	        int e;
	        for (e= 0; seqid.charAt(e)> ' '; e++) ;
	        sid= new OpenString( seqid.substring(0,e).trim());
	        Debug.println("msf sid=["+sid+"]");
	        }
	      }

	    else if ( si.indexOf("//")>=0 ) {  
	      indata = true;
	      iline= 0;
				//if (nseq==0) {  }
				setNseq(atseq);
	      if (choice == kListSequences) done = true;
	      }
	      
	  } while (!done);
		allDone = true;
	}

};


//public
class MsfSeqWriter extends InterleavedSeqWriter
{
	protected String datestr;

	protected long calculateChecksum()
	{
		return GCGchecksum( bioseq, offset, seqlen);
	}

	protected void interleaf(int leaf) {
			// do after writing seqq names ??!? == writeDoc, but need to interleave names
		if (leaf==0) { writeln( "//"); } 
		writeln(); 
		}

	protected void interleaveHeader()
	{
		int checktotal = 0;
    if (datestr==null) {
  		SimpleDateFormat sdf= new SimpleDateFormat("MMM dd, yyyy  HH:mm"); //August 28, 1991  02:07
  		datestr= sdf.format(new Date());
  		}
		//foreach seq do
		//  int checksum= calculateChecksum(); // need checksum for all sequences -!?
		//checktotal= checksumTotal; // will have this after all are written!

    String stype;
    if (bioseq.getSeqtype() == Bioseq.kAmino)  { stype= "P"; writeString("!!AA"); }
    else { stype= "N"; writeString("!!NA"); }
		writeln("_MULTIPLE_ALIGNMENT"); // gcg9+ - leave out? - use AA_ for aminos ?
		writeln();
		writeString( " " + seqid + "  MSF: " + seqlen);
	  writeString( "  Type: "+stype+"  " + datestr );
	  writeln( "  Check: " +  checktotal + " ..");
	  writeln();
	}
	
	
	public void writeRecordStart()
	{
		super.writeRecordStart();
		setChecksum(true);
   	opts.spacer = 10;
    opts.nameleft = true;
    opts.namewidth= 15;  
   	opts.seqwidth= 50;
    opts.tab = 1; 
	}

	public void writeDoc()
	{
		super.writeDoc();
  	writeString(" Name: " + Fmt.fmt(idword, 16, Fmt.LJ));
		writeString(" Len:" + Fmt.fmt(seqlen, 6));
		writeString("  Check:" + Fmt.fmt(checksum, 5));
		writeln("  Weight:  1.00");
	}

};







public class PaupSeqFormat extends BioseqFormat
{		
	public String formatName() { return "PAUP|NEXUS";  }  
	public String formatSuffix() { return ".nexus"; }  
	public String contentType() { return "biosequence/nexus"; }  

	public boolean canread() { return true; }   //? ((Debug.isOn)?true:false);
	public boolean canwrite() { return true; }  
	public boolean interleaved() { return true; }  
	public boolean needsamelength() { return true; }  

	public BioseqWriterIface newWriter() { return new PaupSeqWriter(); }		
	public BioseqReaderIface newReader() { return new PaupSeqReader(); }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
	 	if ( line.indexOf("#NEXUS") == 0 ) {
      formatLikelihood += 90;
      if (recordStartline==0) recordStartline= atline;
      return true;
      }
    else
    	return false;
	}
}


//public
class PaupSeqReader  extends  InterleavedSeqReader //InterleavedSeqreader
{
	char matchchar= 0; 
	int topseqlen, topnseq;
	
	public PaupSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//testbaseKind= kUseTester;
		//formatId= 17;
		}

	public boolean endOfSequence() {
		return false;
		}

	protected void read() throws IOException
	{
    boolean done= false;
    boolean interleaved= false;
    int i, j, n;
    while (!done && !endOfFile()) {
      getline();
      OpenString os= new OpenString(sWaiting);
      os.lowerCase(); //? why os here when UC on write???
      n= nWaiting;
      if (os.indexOf("matrix")>=0) done= true;
      if (os.indexOf("interleav")>=0) interleaved= true;
      if ((i= os.indexOf("ntax="))>=0)  {
      	i += 5;
      	for (j=i+1; j<n && !Character.isDigit(os.charAt(j)); j++) ;
      	topnseq= Integer.parseInt(os.substring(i,j).toString());
      	}
      if ((i= os.indexOf("nchar="))>=0) {
      	i += 6;
      	for (j=i+1; j<n && !Character.isDigit(os.charAt(j)); j++) ;
      	topseqlen= Integer.parseInt(os.substring(i,j).toString());
      	}
      if ((i= os.indexOf("matchchar="))>=0)  {
      	i += 10;
      	if (os.charAt(i) == '\'' || os.charAt(i) == '"') i++;
				matchchar= os.charAt(i);
      	}
      }
		setNseq(topnseq);
   	readLoop(interleaved);
	}


	protected boolean first, atname, domatch, done, indata; 
	protected OpenString saveseq;
	protected String sid, sid1;
	protected int iline;
	
	protected void fixmatchchar(int offset)
	{
	  for (int i=0; i < saveseq.length(); i++)  
	    if (getreadbuf(offset+i) == matchchar) 
	    	setreadbuf(offset+i, saveseq.charAt(i));  
	}
	
	protected void readIndata()
	{
    // [         1                    1                    1         ] 
    // human     aagcttcaccggcgcagtca ttctcataatcgcccacggR cttacatcct 
    // chimp     ................a.t. .c.................a .......... 
    // !! need to correct for matchchar 

  	int seqat, offset= 0;
    OpenString si= sWaiting;
    while (offset<nWaiting && si.charAt(offset) <= ' ') offset++;
		if (si.indexOf(';')>0) indata= false;
		
    if (offset<nWaiting && Character.isLetterOrDigit(si.charAt(offset)) )  {
    
      	// valid data line starts w/ a left-justified seqq name 
      if (first) {
	    	if (firstpass) nseq++; /// this is bad - need to stop incrementing 1st time thru
        atseq++; //??
        if (atseq >= topnseq) first= false;
      	for (seqat= offset; 
      		seqat < nWaiting && !Character.isLetterOrDigit(si.charAt(seqat)); 
      			seqat++) ;

        if (choice == kListSequences)  
          addinfo( si.substring(0,seqat).trim().toString());
          
        else if (atseq == choice) {
          if (domatch) {
            if (atseq == 1) saveseq= si.substring(seqat);
            else fixmatchchar( seqat);
            }
	        addseq( getreadchars(), getreadcharofs()+seqat, nWaiting - seqat);
	        seqid= si.substring( 0, seqat).trim().toString();
          sid= seqid;
          if (atseq == 1) sid1= seqid;
          }
        }

      else if ( si.indexOf(sid) == offset ) {
      	for (seqat= offset; 
      		seqat < nWaiting && !Character.isLetterOrDigit(si.charAt(seqat)); 
      			seqat++) ;
        if (domatch) {
        	if (atseq == 1)  saveseq= si.substring(seqat);
          else fixmatchchar( seqat);
          }
	    	addseq(getreadchars(), getreadcharofs()+seqat, nWaiting - seqat);
        }

      else if (domatch && (si.indexOf(sid1) == offset) ) {
      	for (seqat= offset; 
      		seqat < nWaiting && !Character.isLetterOrDigit(si.charAt(seqat)); 
      			seqat++) ;
      	saveseq= si.substring(seqat);
        }

  		iline++;
 			}
	}
	
	
	protected void readSeqData()
	{
      // [         1                    1                    1         ] 
      // human     aagcttcaccggcgcagtca ttctcataatcgcccacggR cttacatcct 
      //           aagcttcaccggcgcagtca ttctcataatcgcccacggR cttacatcct 
      // chimp     ................a.t. .c.................a .......... 
      //           ................a.t. .c.................a .......... 

  	int seqat, offset= 0;
    OpenString si= sWaiting;
    while (offset<nWaiting && si.charAt(offset) <= ' ') offset++;
		if (si.indexOf(';')>0) indata= false;
		
    if ( offset<nWaiting && Character.isLetterOrDigit(si.charAt(offset)) )  {
      // valid data line starts w/ a left-justified seqq name 
      if (atname) {
 	   		if (firstpass) nseq++; /// this is bad - need to stop incrementing 1st time thru
        atseq++; //??
        seqlencount = 0;
        atname= false;
      	for (seqat= offset; 
      		seqat < nWaiting && !Character.isLetterOrDigit(si.charAt(seqat)); 
      			seqat++) ;

        if (choice == kListSequences) {
          	// ! we must count bases to know when topseqlen is reached ! 
	        countseq(getreadchars(), getreadcharofs()+seqat, nWaiting - seqat);
          if (seqlencount >= topseqlen) atname= true;
          addinfo( si.substring(0,seqat).trim().toString());
          }
          
        else if (atseq == choice) {
	    		addseq(getreadchars(), getreadcharofs()+seqat, nWaiting - seqat);
          seqlencount= seqlen;
          if (seqlencount >= topseqlen) atname= true;
	        seqid= si.substring( 0, seqat).trim().toString();
          }
          
        else {
          countseq(getreadchars(), getreadcharofs()+seqat, nWaiting - seqat);
          if (seqlencount >= topseqlen) atname= true;
          }
        }

      else if (atseq == choice) {
        addseq( getreadchars(), getreadcharofs(), nWaiting);
        seqlencount= seqlen;
        if (seqlencount >= topseqlen) atname= true;
        }
      else {
        countseq(getreadchars(), getreadcharofs(), nWaiting);
        if (seqlencount >= topseqlen) atname= true;
        }
      }
	}
	
	protected void readLoop(boolean interleaved) throws IOException
	{
		indata= first = atname= true;
	 	domatch= (matchchar > 0);
	 	addit = (choice > 0);
	  if (addit) seqlen = 0;
	  seqlencount = iline= 0;
	  do {
	    getline();
	    done = endOfFile();
	    if (done && nWaiting==0) break;
	   	else if (indata) {
	   		if (interleaved) readIndata();
	   		else readSeqData();
	   		}
	    else {
      	String s= sWaiting.toLowerCase();
      	if (s.indexOf("matrix")>=0) {
	      	indata= atname= true;
	      	iline= 0;
	      	if (choice == kListSequences) done = true;
	      	}
	      }
	  } while (!done);
		allDone = true;
	}

};


//public
class PaupSeqWriter extends InterleavedSeqWriter
{

	protected void interleaf(int leaf) {
		if (leaf==0) { writeln(); writeln("MATRIX"); }
		else writeln(); // required
		}

	protected void interleaveHeader()
	{
		String skind= SeqInfo.getKindLabel(bioseq.getSeqtype());
		writeln( "#NEXUS");
		//writeln( "[" + seqid + " -- data title]");
		writeln();
		writeln();
		writeln( "BEGIN DATA;");
		writeString( " DIMENSIONS NTAX=" + Integer.toString(getNseq()) );
		writeln( " NCHAR=" + seqLen() + ";" );
		writeString( " FORMAT DATATYPE=" + skind );
		writeString( " INTERLEAVE MISSING=" + opts.gapchar);
		if (opts.domatch) { writeString(" MATCHCHAR=" + opts.matchchar);  }
		writeln( ";");
	}
	
	public void writeTrailer() { 
		super.writeTrailer(); 
		writeln(";" );
		writeln( "END;"); 
		try { douts.flush(); } catch (IOException ex) {} //? missing END
		}
		
	public void writeRecordStart()
	{
		super.writeRecordStart();

		//testbase= new PaupOutBase();   testbaseKind= kUseTester;
		this.setOutputTranslation( new PaupOutBase( this.getOutputTranslation()));
		
    opts.nameleft = true;
    opts.nameflags= Fmt.LJ;
    opts.namewidth= 20;  // !? name width should be max of all name widths + some?
   	opts.seqwidth = 100; // was 100 ? shorter okay?
   	opts.spacer   = 20;	// was 21
    opts.tab = 0; 
	}

	public void writeDoc()
	{
		super.writeDoc();
   	writeString("[Name: " + Fmt.fmt(idword, 16, Fmt.LJ));
		writeString(" Len:" + Fmt.fmt(seqlen, 6));
		writeString("  Check:" + Fmt.fmt(checksum, 5));
		writeln("]");

		/*if (seqdoc instanceof BioseqDoc) {
			String title=  ((BioseqDoc)seqdoc).getTitle();
			if (title!=null) writeln( title );  
			}*/
	}

};


class PaupOutBase extends OutBiobase
{
	public PaupOutBase(OutBiobaseIntf nextout) { super(nextout); }
	public int outSeqChar(int c) {
		if (outtest!=null) c= outtest.outSeqChar(c);   
		if (c==BaseKind.indelSoft) return BaseKind.indelHard;
		else if (c==BaseKind.indelEdge) return BaseKind.indelHard;  
	 	else return c;
		}
}



public class PrettySeqFormat extends BioseqFormat
{		
	public String formatName() { return "Pretty";  }  
	public String formatSuffix() { return ".pretty"; }  
	public String contentType() { return "biosequence/pretty"; }  

	public boolean canread() { return false; }   //? not readable? - fix
	public boolean canwrite() { return true; }  
	public boolean interleaved() { return true; }  

	public BioseqWriterIface newWriter() { return new PrettySeqWriter(); }		
	//public BioseqReaderIface newReader() { return new PrettySeqReader(); }

}


//public
class PrettySeqReader  extends InterleavedSeqReader //InterleavedSeqreader
{
	public PrettySeqReader() {
		margin	=  0;
		addfirst= true;
		addend 	= true;  
		ungetend= false;
		//formatId= 18;
		}
};


//public
class PrettySeqWriter extends InterleavedSeqWriter
{
	boolean firstseq;
	int interline;
	
	public void writeRecordStart() 			// per seqq
	{
		super.writeRecordStart(); // super does opts.plainInit()
		//if (!opts.userchoice) opts.prettyInit();
		if (firstseq) { opts.numwidth= Fmt.fmt(seqlen).length() + 1; firstseq= false; }
	}
		
	public void writeHeader()  throws IOException			// per file
	{ 
		super.writeHeader();
		if (!opts.userchoice) opts.prettyInit();
		interline= opts.interline;
		firstseq= true;
		if (opts.numtop) {
			// seqlen must be set to min/max seqlen
			opts.numline = 1;
			if (interleaved()) fileIndex.indexit(); 
			writeSeq(); // write number line (numline==1)
			opts.numline = 2;
			if (interleaved()) fileIndex.indexit(); 
			writeSeq(); // write tic line (numline==2)
			opts.numline = 0;
			}
	}

	protected void interleaf(int leaf) {
		for (int i= interline; i>0; i--) writeln(); // is newline legal for phylip here?
		}
	
	public void writeTrailer()  // per file 
	{ 
		if (opts.numbot) {
			opts.numline = 2;
			if (interleaved()) fileIndex.indexit();  
			writeSeq(); // write tic line (numline==2)
			opts.numline = 1;
			if (interleaved()) fileIndex.indexit(); 
			writeSeq(); // write number line (numline==1)
			opts.numline = 0;
			}
		super.writeTrailer();
	}
		
};



