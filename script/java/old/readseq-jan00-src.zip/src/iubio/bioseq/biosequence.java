// dclap/biosequence.java
// move to package dbio ?
// dgg oct'96

//
// make sure this is also C++ able??
//


package iubio.bioseq;
//package iubio.readseq;


// see if we can separate this into two versions, with mask for more complex uses
// class Biobase
// class BiobaseMasked

public class Biobase { 
	//protected ?!
	public byte	c, mask;
	
	public Biobase() { c= (byte)'?'; }
	public Biobase(byte base) { c= base; }
	public Biobase(char base) { c= (byte) base; }
	public Biobase(char base, boolean withmask) { 
		if (withmask) {
			c= (byte) (base & 0x00ff);
			mask= (byte) (base >> 8);
			}
		else c= (byte) base; 
		}
	public Biobase(byte base, byte mask) { c= base; this.mask= mask; }
	public Biobase(char base, byte mask) { c= (byte) base; this.mask= mask; }
	public Biobase(Biobase bb) { c= bb.c; mask= bb.mask; }

	
	// ACCESSORS =================================
	
	public byte base() { return c; }
	public byte mask() { return mask; }
	public char c()    { return (char) c; }
	public char cmask() { return (char) mask; }
	public char basemask() { return (char) (c | mask << 8); }
	public byte maskAsText() { return (byte) ((mask & 0x7F) + '?'); }

	// BASE KINDS =================================

	public final  boolean isPrimenuc() { return BaseKind.isPrimenuc((int)c); }
	public final  boolean isIUBsym() { return BaseKind.isIUBsym((int)c); }
	public final  boolean isDnanuc() { return BaseKind.isDnanuc((int)c); }
	public final  boolean isRnanuc() { return BaseKind.isRnanuc((int)c); }
	public final  boolean isAmino() { return BaseKind.isAmino((int)c); }
	public final  boolean isProtonly() { return BaseKind.isProtonly((int)c); }
	public final  boolean isSeqsym() { return BaseKind.isSeqsym((int)c); }
	public final  boolean isAlphaseq() { return BaseKind.isAlphaseq((int)c); }
	public final  boolean isAlnumseq() { return BaseKind.isAlnumseq((int)c); }
	public final  boolean isIndel() { return BaseKind.isIndel((int)c); }
	public final  boolean isPrint() { return BaseKind.isPrint((int)c); }

	public final  int isSeqChar() { return BaseKind.isSeqChar((int)c); }
	public final  int isGCGSeqChar() { return BaseKind.isGCGSeqChar((int)c); }
	public final  int isSeqNumChar() { return BaseKind.isSeqNumChar((int)c); }
	public final  int isAnyChar() { return BaseKind.isAnyChar((int)c); }


	// MASKS =================================

 	public final static int kMaskEmpty = -1;
			
  public final int maskBit( int masklevel) {
  	return maskBit( mask, masklevel); }

  public static int maskBit(byte maskbyte, int masklevel) 
  { 
    int b= maskbyte;
    switch (masklevel) {
      case 0: b &= 0x7f; break; // return full mask - top (0x80) bit
      case 1: b &= 1;  break;  
      case 2: b &= 2;  break;
      case 3: b &= 4;  break;
      case 4: b &= 8;  break;
          // 5-7 reserved for now
      case 5: b &= 16;  break;
      case 6: b &= 32;  break;
      case 7: b &= 64;  break;
      default: b = kMaskEmpty; break;
      }
    return b;
  }

  public final boolean isMasked( int masklevel) {
    return (maskBit(masklevel) > 0);
  	}
  	
  public static boolean isMasked(byte maskbyte, int masklevel) 
  { 
  	int b= maskBit( maskbyte, masklevel);
    return (b > 0);
  }

	public final byte setMask( int masklevel, int maskval) {
		mask= setMask( mask, masklevel, maskval); return mask; }

	public static byte setMask( byte b, int masklevel, int maskval) 
	{
		switch (masklevel) {
			case 1: if (maskval!=0) b |= 1; else b &= ~1; break;
			case 2: if (maskval!=0) b |= 2; else b &= ~2; break;
			case 3: if (maskval!=0) b |= 4; else b &= ~4; break;
			case 4: if (maskval!=0) b |= 8; else b &= ~8; break;
				// reserve bits 5, 6, 7 for now 
			case 5: if (maskval!=0) b |= 16; else b &= ~16; break;
			case 6: if (maskval!=0) b |= 32; else b &= ~32; break;
			case 7: if (maskval!=0) b |= 64; else b &= ~64; break;
				// -- 7 & 8 may go unused to store data in printchar form
			default: break;
			}
		return b;
	}

	public final byte flipMask( int masklevel) {
		mask= flipMask( mask, masklevel); return mask; }

	public static byte flipMask( byte b, int masklevel)
	{
		switch (masklevel) {
			case 1: b ^= 1;  break;  
			case 2: b ^= 2;  break;
			case 3: b ^= 4;  break;
			case 4: b ^= 8;  break;
					// 5-7 reserved?
			case 5: b ^= 16;  break;
			case 6: b ^= 32;  break;
			case 7: b ^= 64;  break;
			default:  break;
			}
		return b;
	}

};




public interface DSeqChanges {
 	public final static int kDelete = 1, kInsert = 2, kReorder = 4, kChange = 8;
};



public class SeqInfo
{
	protected short seqtype;
	protected int 	basecount;
	protected long 	checksum;
	
	public int getKind() { return seqtype; }
	public int getBaseCount() { return basecount; }
	public long getChecksum() { return checksum; }
	public void setKind(int seqtype) { this.seqtype= (short)seqtype; }
	public void setBaseCount(int 	basecount) { this.basecount= basecount; }
	public void setChecksum(long 	checksum) { this.checksum= checksum; }
	public boolean equals(SeqInfo si) {
		return (si.seqtype == seqtype && si.basecount == basecount && si.checksum == checksum);
		}
}
	

public class SeqKind 
	extends SeqInfo
{
	public final static short kOtherSeq= 0, kDNA= 1, kRNA= 2, kNucleic= 3, kAmino= 4;
	public static int kMaxSeqtest = 500;
	public boolean shorttest= true, wantcrc= false;
	protected int na, aa, po, nt, nu, ns, no;
	protected int testlen; //maxlen
	// short seqtype;
	// int basecount;
	// long checksum;
	
	public SeqKind() { init(0); }
	public SeqKind(int maxlen) { init(maxlen); }
	
	public SeqKind( int maxlen, boolean shorttest, boolean wantcrc) { 
		this.shorttest = shorttest;
		this.wantcrc = wantcrc;
		init(maxlen); 
		}
	
	public void init(int maxlen) {
		na = 0; aa = 0; po = 0; nt = 0; nu = 0; ns = 0; no = 0;
		basecount = 0;
	  seqtype= kOtherSeq;
		checksum = 0xffffffffL;
		//this.maxlen= maxlen;
	  if (shorttest && (maxlen>kMaxSeqtest || maxlen<1))	testlen = kMaxSeqtest; 
	  else testlen= maxlen;
		}

	public static String getKindLabel(int kind)
	{
		switch (kind) {  
			case kAmino   : return "PROTEIN";  	//?"Protein";
			case kNucleic : return "NUCLEOTIDE"; //? "Nucleic";
 			case kRNA     : return "RNA";  
			default:
			case kDNA     : 
			case kOtherSeq: return "DNA"; //? is other == DNA
			}
	}
		
	public int getBaseCount() { return basecount; }
	public long getChecksum() { return checksum ^ 0xffffffffL; }
	 
	public int getKind()
	{
	  if (basecount<2 || (no > 0) || (po+aa+na == 0)) seqtype= kOtherSeq;
	 		//?? test probability of kOtherSeq ?, e.g.,
	  // else if (po+aa+na / maxtest < 0.70) return kOtherSeq;
	  else if (po > 0) seqtype= kAmino;
	  else if (aa == 0) { //  && na > 0 is implied here
	    if (nu > nt) seqtype= kRNA;
	    else seqtype= kDNA;
	    }
	  else if (na > aa) seqtype= kNucleic;
	  else seqtype= kAmino;
	  return seqtype;
	}

	private final void add1( int c) {
		//if (c>='a' && c<='z') c -= 32; // toupper
		basecount++;
		if (BaseKind.isProtonly(c)) po++;
    else if (BaseKind.isPrimenuc(c)) {
      na++;
      if (BaseKind.isDnanuc(c)) nt++;
      else if (BaseKind.isRnanuc(c)) nu++;
      }
    else if (BaseKind.isAmino(c)) aa++;
    else if (BaseKind.isSeqsym(c)) ns++;
    else if (BaseKind.isAlphaseq(c)) no++;
		}

	private final void addcrc( int c) {
		if (c>='a' && c<='z') c -= 32; // toupper
		checksum = BaseKind.crctab[((int)checksum ^ c) & 0xff] ^ (checksum >> 8);
		}
		
	
	public final void add( byte[] ba, int offset, int len) {  
		len= Math.min(len,testlen);
	  for (int i = 0; i < len; i++) add( (int)ba[offset+i] );
	  getKind(); // set seqtype !
		} 
		
	public final void add( char[] ca, int offset, int len) {  
		len= Math.min(len,testlen);
	  for (int i = 0; i < len; i++) add( (int)ca[offset+i] );
	  getKind(); // set seqtype !
		} 
		
	public final void add( String s, int offset, int len) {  
		len= Math.min(len,testlen);
	  for (int i = 0; i < len; i++) add( (int)s.charAt(offset+i) );
	  getKind(); // set seqtype !
		} 
				
	public final void add( Biobase[] bb, int offset, int len) {  
		len= Math.min(len,testlen);
	  for (int i = 0; i < len; i++) add( (int)bb[i+offset].c );
	  getKind(); // set seqtype !
		} 

	public final void add( int c) {
		if (c > ' '  && (c < '0' || c > '9')) {
			add1(c);
			if (wantcrc) addcrc(c);
			}
		}
		
}



// revise this to store/use byte[] instead of Biobase for speed when desired

public class Bioseq 
	implements Cloneable
{
	public static boolean gUseByteArray = false;
		// enum seqType
	public final static short kOtherSeq= 0, kDNA= 1, kRNA= 2, kNucleic= 3, kAmino= 4;
		// enum basePart
	public final static int baseOnly = 0, maskOnly = 1, nucAndMask = 2, maskOnlyAsText= 3;
	public int gBaseType= baseOnly;
	
	protected boolean useByteArray= gUseByteArray;
	protected byte[] bSeq;
	protected Biobase[]	fSeq; // this may not be best	


	public Bioseq() { this(0); }

	public Bioseq(int maxlen) {  this(maxlen,gUseByteArray); }

	public Bioseq(int maxlen, boolean asBytes) { 
		useByteArray= asBytes;
		if (useByteArray) {
			bSeq= new byte[maxlen];
			}
		else {
			fSeq= new Biobase[maxlen]; 
			for (int i=0; i<maxlen; i++) fSeq[i]= new Biobase();
			}
		}

	public Bioseq(Biobase[] bb) { fSeq= bb; useByteArray= false; }

	public Bioseq(byte[] b) { this( b, 0, b.length); }
		
	public Bioseq(byte[] b, int offs, int len) { this( b, 0, b.length, gUseByteArray); }

	public Bioseq(byte[] b, int offs, int len, boolean asBytes) {
		useByteArray= asBytes;
		if (useByteArray) {
			bSeq= new byte[len];
			System.arraycopy( b, offs, bSeq, 0, len);
			}
		else {
			fSeq= new Biobase[len];
			for (int i=0; i<len; i++) fSeq[i]= new Biobase(b[i+offs]);
			}
		}
		
	public Bioseq(char[] c) { this( c, 0, c.length); }
		
	public Bioseq(char[] c, int offs, int len) { this( c, 0, c.length, gUseByteArray); }

	public Bioseq(char[] c, int offs, int len, boolean asBytes) {
		useByteArray= asBytes;
		if (useByteArray) {
			bSeq= new byte[len];
			for (int i=0; i<len; i++) bSeq[i]= (byte) c[i+offs];
			}
		else {
			fSeq= new Biobase[len];
			for (int i=0; i<len; i++) 
				fSeq[i]= new Biobase( c[i+offs], gBaseType == nucAndMask);
			}
		}

	public Bioseq( String s) { this(s, gUseByteArray); }
	
	public Bioseq( String s, boolean asBytes) {
		useByteArray= asBytes;
		int len= s.length();
		if (useByteArray) {
			bSeq= new byte[len];
			for (int i=0; i<len; i++) bSeq[i]= (byte) s.charAt(i);
			} 
		else {
			fSeq= new Biobase[len];
			for (int i=0; i<len; i++) 
				fSeq[i]= new Biobase( s.charAt(i), gBaseType == nucAndMask);
			}
		}

	public int length() { 
		if (useByteArray) return bSeq.length;
		else return fSeq.length; 
		}
		
	public Biobase[] bases() { 
		if (useByteArray && bSeq!=null) {
			int len= bSeq.length;
			Biobase[] bbSeq= new Biobase[len];
			for (int i=0; i<len; i++) bbSeq[i]= new Biobase(bSeq[i]);
			return bbSeq;  
			}
		else return fSeq; 
		} 
		
	public void setbases( Biobase[] theBases) { fSeq= theBases; useByteArray= false; } 

	public void setbases( byte[] theBases) { bSeq= theBases;  useByteArray= true; } 

	public final void setbase(int i, Biobase b) { 
		if (useByteArray) bSeq[i]= b.base(); else fSeq[i]= b; 
		}
	public final void setbase(int i, byte b) { 
		if (useByteArray) bSeq[i]= b; else fSeq[i]= new Biobase(b); 
		}
	public final void setbase(int i, char b) { 
		if (useByteArray) bSeq[i]= (byte) b; else fSeq[i]= new Biobase(b); 
		}
	
	public final Biobase base(int i) { 
		if (useByteArray) return new Biobase(bSeq[i]); else return fSeq[i]; 
		}
	
	public final byte basebyte(int i) {  
		if (useByteArray) return bSeq[i]; else return fSeq[i].base();
		}
		
	public final char basechar(int i) { 
		if (useByteArray) return (char) bSeq[i]; else return fSeq[i].c(); 
		}
	
	public final char base(int i, int basepart) {  
		if (useByteArray) return (char) bSeq[i];
		else {
			switch (basepart) {
				default:
				case baseOnly  : return fSeq[i].c(); 
				case maskOnly  : return (char)fSeq[i].mask();  
				case nucAndMask: return fSeq[i].basemask(); 
				case maskOnlyAsText: return (char)fSeq[i].maskAsText();
				}
			}
		}

	public final boolean isBytes() { return useByteArray; }

	public final byte[] toBytes() {  return toBytes(gBaseType); }
	public final byte[] toBytes(int basepart) { 
		if (useByteArray) return bSeq;
		else return toBytes( 0, -1, basepart); 
		}
	
	public byte[] toBytes( int offset, int count, int basepart) 
	{ 
		if (offset<0) offset= 0;
		if (useByteArray && bSeq!=null) {
			if (offset==0 && count == bSeq.length) return bSeq;
			else {
				int len= bSeq.length - offset;
				if (count>0 && count<len) len= count;
				byte[] b= new byte[len];
				System.arraycopy( bSeq, offset, b, 0, len);
				return b;
				}
			}
		else if (fSeq!=null) {
			int len= fSeq.length - offset;
			if (count>0 && count<len) len= count;
			byte[] b= new byte[len];
			int i;
			switch (basepart) {
				default:
				case baseOnly  : for (i=0; i<len; i++) b[i]= fSeq[i+offset].base(); break;
				case maskOnly  : for (i=0; i<len; i++) b[i]= fSeq[i+offset].mask(); break;
				case maskOnlyAsText: 
										for (i=0; i<len; i++) b[i]= fSeq[i+offset].maskAsText(); break;
				}
			return b;
			}
		else 
			return null;
	}

	public final char[] toChars() { return toChars(gBaseType); }
	public final char[] toChars(int basepart) { return toChars( 0, -1, basepart); }
	
	public char[] toChars( int offset, int count, int basepart) { 
		if (offset<0) offset= 0;
		if (useByteArray && bSeq!=null) {
			int len= bSeq.length - offset;
			if (count>0 && count<len) len= count;
			char[] c= new char[len];
			for (int i= 0; i<len; i++) c[i]= (char) bSeq[i+offset];
			return c;
			}
		else if (fSeq!=null) {
			int len= fSeq.length - offset;
			if (count>0 && count<len) len= count;
			char[] c= new char[len];
			int i;
			switch (basepart) {
				default:
				case baseOnly  : for (i=0; i<len; i++) c[i]= fSeq[i+offset].c(); break;
				case maskOnly  : for (i=0; i<len; i++) c[i]= (char)fSeq[i+offset].mask(); break;
				case nucAndMask: for (i=0; i<len; i++) c[i]= fSeq[i+offset].basemask(); break;
				case maskOnlyAsText: 
							for (i=0; i<len; i++) c[i]= (char)fSeq[i+offset].maskAsText(); break;
				}
			return c;
			}
		else return null;
		}

	public String toString() { return new String(toChars()); }

	public Object clone() {
		try {
			Bioseq bs= (Bioseq) super.clone();
			if (useByteArray) {
				byte[] ba= new byte[bSeq.length];
				System.arraycopy( bSeq, 0, ba, 0, bSeq.length);
				bs.bSeq= ba;
				}
			else bs.fSeq= this.dup(); 
	    return bs;
			}
		catch(CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		}


	//public static int kMaxSeqtest = 500;
	
	public int getSeqtype() 
	{
		int len= length();
		SeqKind sk= new SeqKind( len, true, false);
		if (useByteArray) sk.add( bSeq, 0, len);
		else sk.add( fSeq, 0, len);
		return sk.getKind();
	}

	public static int getSeqtype( String s, int offset, int seqlen) 
	{
		SeqKind sk= new SeqKind(seqlen, true, false);
		sk.add( s, offset, seqlen);
		return sk.getKind();
	}
		
	public static int getSeqtype( byte[] ba, int offset, int seqlen)
	{  
		SeqKind sk= new SeqKind(seqlen, true, false);
		sk.add( ba, offset, seqlen);
		return sk.getKind();
	} 


	public final SeqInfo getSeqStats() { return getSeqStats( 0, length()); }

	public SeqInfo getSeqStats( int offset, int seqlen) {
		SeqKind sk= new SeqKind( seqlen, false, true);
		if (useByteArray) sk.add( bSeq, offset, seqlen);
		else sk.add( fSeq, offset, seqlen);
		return sk;
		}

	/*public static SeqInfo getSeqStats( Biobase[] bb, int offset, int seqlen)
	{
		SeqKind sk= new SeqKind(seqlen, false, true);
		sk.add( bb, offset, seqlen);
		return sk;
	}*/


			//
			// ! fix these for useByteArray
			//
			
	public final void compress(byte gapc) {
		Biobase[] cb= compress(fSeq, 0, fSeq.length, gapc);
		setbases(cb);
		}
	public final void compress(int offset, int seqlen, byte gapc) {
		Biobase[] cb= compress(fSeq, offset, seqlen, gapc);
		setbases(cb);
		}
	public static Biobase[] compress(Biobase[] src, int offset, int seqlen, byte gapc)
	{
		int i, j;
		Biobase[] dst= new Biobase[seqlen];
		for (i= 0, j= 0; i<seqlen; i++) {
			if (src[i+offset].c != gapc) dst[j++]= src[i+offset];
			}
		if (j != seqlen) return expand(dst, j);
		else return dst;
	}


	public final void replace(int len, char oldbase, char newbase) { 
		replace( this, len, oldbase, newbase); 
		}
 	public static void replace(Bioseq seq, int len, char oldbase, char newbase) {
		//Bioseq bs= new Bioseq(seq.bases()); 
  	for (int i=0; i<len; i++) 
  		if (seq.fSeq[i].c == (byte)oldbase) seq.fSeq[i].c= (byte)newbase;  
		}


	public final void replace(int len, String oldbases, String newbases) { 
		replace( this, len, oldbases, newbases); 
		}
 	public static void replace(Bioseq seq, int len, String oldbases, String newbases) {
  	if (oldbases==null||newbases==null) return;
  	int nbases= oldbases.length();
  	for (int j=0; j<nbases; j++) {
  		byte oldb= (byte)oldbases.charAt(j);
  		byte newb= (byte)newbases.charAt(j);
  		for (int i=0; i<len; i++) if (seq.fSeq[i].c == oldb) seq.fSeq[i].c= newb;  
  		}
		}

	public final void expand(int newlen) { 
		Biobase[] exb= expand( fSeq, newlen); 
		setbases(exb);
		}
	public static Biobase[] expand(Biobase[] src, int newlen) {
		int i, minlen= src.length; 
		if (minlen>newlen) minlen= newlen;
		Biobase[] b= new Biobase[newlen];
		System.arraycopy( src, 0, b, 0, minlen); // uses same Biobases
		for (i=minlen; i<newlen; i++) b[i]= new Biobase();
		return b;
		}

	public final Biobase[] dup() { return dup( fSeq); }
	public static Biobase[] dup(Biobase[] src) { 
		int len= src.length;
		Biobase[] b= new Biobase[len];
		//System.arraycopy( src, 0, b, 0, len); //! this reuses Biobase instances !!!
		for (int i=0; i<len; i++) b[i]= new Biobase(src[i]);
		return b;
		}
		
	public final int cmp(Bioseq b, int len) { return cmp( fSeq, b.bases(), len); }
	public static int cmp(Biobase[] a, Biobase[] b, int len) { 
		for (int i=0; i<len; i++) 
			if (a[i].c < b[i].c) return -1;
			else if (a[i].c > b[i].c) return 1;
		return 0;
		}

	public final int indexOf(byte b, int len) { return indexOf( fSeq, b, len); }
	public static int indexOf(Biobase[] a, byte b, int len) { 
		for (int i=0; i<len; i++) if (a[i].c == b) return i;
		return -1;
		}


	public final boolean equals(Bioseq b) { return equals( fSeq, b.bases()); }
	public static boolean equals(Biobase[] a, Biobase[] b) { 
		if (a.length != b.length) return false;
		for (int i=0; i<a.length; i++) 
			if (a[i].c < b[i].c) return false;
			else if (a[i].c > b[i].c) return false;
		return false;
		}
		
		
	public final void copy(Biobase[] dst, int dstOffset, int len) { 
		// this is source
		copy(fSeq, 0, dst, dstOffset, len); 
		}
		
		// note: params are Java/Pascal-esque forward  copy(source -> dest)
		// rather than NCBI Toolbox/C-ish bassakwards  copy(dest <- source)
	public static void copy(Biobase[] src, int srcOffset,
													Biobase[] dst, int dstOffset, int len) 
	{ 
		System.arraycopy( src, srcOffset, dst, dstOffset, len);
		/*
		if (dst.equals(src) && dstOffset >= srcOffset && dstOffset <= srcOffset+len) {
			int d = dstOffset + len;
			int s = srcOffset + len;
			for ( ; len>0; len--) dst[--d]= src[--s];
			}
		else
			for ( ; len>0; len--) dst[dstOffset++]= src[srcOffset++];
		*/
	}
		
}


