// SeqRange.java
// sequence location parsing
// d.g.gilbert, 1997++


package iubio.bioseq;


public class SeqRangeException extends Exception
{
	public SeqRangeException() { super(); }
	public SeqRangeException(String err) { super(err); }
}

/**
 parse, hold and edit biosequence feature locations <pre>
 examples to parse 
 258
 255..457
 105^106
 order(M55673:2559..>3688,<1..254)
 join(M55673:1820..2274,M55673:2378..2558,255..457)
 </pre>
*/

public class SeqRange 
	implements Cloneable, DSeqChanges
{
	public final static int kZero = 1;  // feature table vals are 1 based, want 0 base for useage here?
	public final static int // uncertainty flags
		kStartless = 1, kStartmore = 2, kEndless= 4, kEndmore= 8, kBetween= 16;
	
	public final static String[] sOperators = {
		"join","complement","order","group", "one-of"  // location operators 
		};	
	public final static int //op vals
		opJoin = 0, opComplement = 1, opOrder= 2, opGroup= 3, opOneof= 4, opMax= 5, opNull= 6;
					
	protected int start, nbases;  // use 1 base or 0 base !?
	protected byte uncertain;
	protected byte operation; 	// sOperators[x] 
	protected SeqRange next; 		// next item in list
	protected String refid; 			// for join reference to "remote" accession# data
	
	public SeqRange() {}
	public SeqRange( int start, int nbases) { 
		set(start, nbases); 
		}
	public SeqRange( int start, int nbases, int uncertain) { 
		this(start, nbases, uncertain, null, null, null); 
		}
	public SeqRange( int start, int nbases, int uncertain, String refid) { 
		this(start, nbases, uncertain, refid, null, null); 
		}
	public SeqRange( int start, int nbases, int uncertain, 
		String refid, String soperation, SeqRange next) { 
		this.start= start; this.nbases= nbases; 
		this.uncertain= (byte)uncertain;
		this.refid= refid; 
		this.next= next;
		//this.operation= soperation; 
		this.operation= opJoin;
		if (soperation!=null)
		 for (byte op= opJoin; op < opMax; op++)  
			if (sOperators[op].equals(soperation)) { this.operation= op; break; }
		}

	public final void set( int start, int nbases) { this.start= start; this.nbases= nbases; }

	public final int start() { return start; }
	public final int nbases() { return nbases; }
	public final int stop() { return start + nbases; }
	public final int uncertain() { return (int)uncertain; }
	public final SeqRange next() { return next; }
	public final String operation() { return (operation>=opMax) ? "" : sOperators[operation]; }
	public final String remoteSeq() { return refid; }
	public final boolean isRemote() { return (refid!=null); }

	public final void setStart(int start) { this.start= start; }
	public final void setNbases(int nbases) { this.nbases= nbases; }
	
	public int max() {
		int max= stop();
		for (SeqRange nx= next; nx!=null; nx= nx.next()) max= Math.max( max, nx.stop());
		return max;
		}
		
	public void copy( SeqRange sr) {
		start= sr.start;
		nbases= sr.nbases;
		uncertain= sr.uncertain;
		operation= sr.operation;
		refid= sr.refid;
		next= sr.next; //? or clone
		}
		
	public void add( SeqRange sr) { 
		if (sr!=null && sr.nbases > 0) {
			if ( nbases==0 ) copy(sr); // && start == 0 ??
			else {
				SeqRange nr= this;
				while (nr.next!=null) nr= nr.next;
				nr.next= sr;
				}
			}
		}
		
	public Object clone() {
		try {
			SeqRange sr= (SeqRange) super.clone();
			if (next!=null) sr.next= (SeqRange) next.clone(); //!? recursion okay?
		 	return sr;
			}
		catch(CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		}


	public final boolean updateRange(int changeflags, int astart, int length) 
	{ return updateRange(changeflags, astart, length, null); }
	
	public boolean updateRange(int changeflags, int astart, int length, byte[] basechanges) 
	{
		int astop= astart + length;
		if (astart > stop()) return false; //astop < start || 
		int oldstart= start, oldlen= nbases;
		int istop= stop();
		if (basechanges != null) {
			for (int i=0; i<basechanges.length; i++) {
				int at= i+astart;
				if (at > istop) break;
				switch (basechanges[i]) {
					case kDelete: if (at < start) start--; else if (at < istop) nbases--; break;
					case kInsert: if (at < start) start++; else if (at < istop) nbases++; break;
					//case kReorder: break;// ? move start?
					//case kChange: break;// ? 
					}
				}
			}
		else {
					// does changeflags == (kInsert | kDelete) make any sense? - same length +/-
			if ((changeflags & kInsert) != 0) {
				if (astart < start) start += length; else if (astart < istop) nbases += length;
				}
			else if ((changeflags & kDelete) != 0) {
				if (astart < start) start -= length; else if (astart < istop) nbases -= length;
				}
			//if ((changeflags & kReorder) != 0) {} // ? move start?
			//if ((changeflags & kChange) != 0) { }
			}
		if (start<0) start= 0;
		if (nbases<0) nbases= 0;
		
		boolean changedme= (oldstart != start || oldlen != nbases);
		boolean changednext= false;
		if (next!=null)  // recursively change all ranges till > next.stop()
			changednext= next.updateRange( changeflags, astart,  length, basechanges);
			
		return (changedme || changednext);
	}
			
			
  public String toString() {
  	StringBuffer sb= new StringBuffer();
  	if (next!=null) {
  		sb.append(sOperators[operation]);  
  		sb.append('(');
  		toBuf(sb);
  		sb.append( ')');
  		}
  	else toBuf(sb);
  	return sb.toString();
  	}

	public boolean equals(Object ob) {
		if (ob instanceof SeqRange) {
			SeqRange sr= (SeqRange) ob;
			if (start == sr.start && nbases == sr.nbases)
				return (next==null || next.equals(sr.next));
			}
		return false;
		}

	public boolean intersects(SeqRange sr) {
		if (sr==null) return false;
		if (start <= sr.stop() && stop() >= sr.start) return true;
		if (next!=null && next.intersects(sr)) return true;
		if (sr.next!=null && intersects(sr.next)) return true;
		return false;
		}

	public SeqRange invert(int maxlen)  
	{
		SeqRange invsr= new SeqRange();
		int at= 0;
		for (SeqRange sr= this; sr!=null && at<maxlen; sr= sr.next) {
			if (sr.isRemote()) continue; //?
			if (sr.start > at) invsr.add( new SeqRange(at, sr.start-at) );
			at= sr.stop(); //+1 - NO - off by 1?
			}
		if (at < maxlen) invsr.add( new SeqRange(at, maxlen-at) );
		return invsr;
	}
	
	public SeqRange joinRange(SeqRange sr)  
	{
		SeqRange unionsr= null;
			//? implement only for join()s? - can assume ascending order for each sr
			//? skip refids 
			//? find overall min/max range, then handle holes in range?
		//int min= Math.min( start, sr.start);
		//int max= Math.max( max(), sr.max());
		//unionsr= new SeqRange( min, max-min, uncertain, refid, sOperators[0], null);

		unionsr= new SeqRange();
		unionsr.operation= opJoin; //sOperators[0]; //? join always
		addRange( unionsr, sr);
		return unionsr;
	}


	protected void addRange(SeqRange unionsr, SeqRange sr) 
	{
			// need to screen out sr/this with refid ! for getFeatureRanges/extractFeatureBases
		while (sr!=null && sr.isRemote()) sr= sr.next;
		if (sr==null) {
			if (!this.isRemote())
				unionsr.add( new SeqRange(start, nbases, uncertain, refid) );
			if (next!=null) next.addRange( unionsr, sr);
			}
		else {
			if (start == 0 && nbases == 0) { // empty this
				unionsr.add( new SeqRange( sr.start, sr.nbases, sr.uncertain, sr.refid) );
				addRange( unionsr, sr.next);
				}
			else if (!this.isRemote() && start <= sr.stop() && stop() >= sr.start) {
				int min= Math.min( start, sr.start );
				int max= Math.max( stop(), sr.stop() );
				unionsr.add( new SeqRange(min, max-min, uncertain | sr.uncertain) );
				if (next!=null) next.addRange( unionsr, sr.next);
				else if (sr.next!=null) sr.next.addRange( unionsr, null);
				}
			else if (sr.start < start || this.isRemote()) {
				unionsr.add( new SeqRange( sr.start, sr.nbases, sr.uncertain, sr.refid) );
				addRange( unionsr, sr.next);
				}
			else {
				unionsr.add( new SeqRange(start, nbases, uncertain, refid) );
				sr.addRange( unionsr, next);
				}
			}
	}
		
	/*protected void addRange(SeqRange a, SeqRange b) 
	{
		if (a==null && b==null) 
			return;
		else if (b==null) {
			this.add( new SeqRange( a.start, a.nbases) );
			this.addRange( a.next, null);
			}
		else if (a==null) {
			this.add( new SeqRange( b.start, b.nbases) );
			this.addRange( null, b.next);
			}
		else {
			if (a.start <= b.stop() && a.stop() >= b.start ) {
				int min= Math.min( a.start, b.start );
				int max= Math.max( a.stop(), b.stop() );
				this.add( new SeqRange(min,max-min) );
				this.addRange( a.next, b.next);
				}
			else if (b.start < a.start) {
				this.add( new SeqRange( b.start, b.nbases) );
				this.addRange( a, b.next);
				}
			else {
				this.add( new SeqRange( a.start, a.nbases) );
				this.addRange( a.next, b);
				}
			}
	}*/

		
	protected void toBuf(StringBuffer sb) {
	 	if (refid!=null) { sb.append(refid); sb.append(':'); }
	 	if ((uncertain & kStartless) != 0) sb.append( '<');
	 	else if ((uncertain & kStartmore) != 0) sb.append( '>');
	 	sb.append( start+kZero);
  	if ( nbases>1 ) {
			if ((uncertain & kBetween) != 0) sb.append('^'); //? or just test if (start+1 == stop())
			else sb.append("..");
		 	if ((uncertain & kEndless) != 0) sb.append( '<');
		 	else if ((uncertain & kEndmore) != 0) sb.append( '>');
			sb.append( stop() - 1 + kZero);
			}
		if (next!=null) {
			sb.append( ',');
			next.toBuf(sb);
			}
		}

		//
		// parsing
		//
  	
	protected final int getMyMark( String s)  {	
  	int at= s.indexOf(':');
  	if (at>0) { refid= s.substring(0,at); s= s.substring(at+1); }
  	return getMyMark( s, kStartless, kStartmore); 
  	}
  	
  protected final int getMyEndMark( String s)  {	
  	return getMyMark( s, kEndless, kEndmore); 
  	}
  
  protected int getMyMark( String s, int lessflag, int moreflag) 
  {
  		// note: Feature Table numbers are +1 of our 0 based indexing
		boolean minus= false;
  	int val= 0, b= -1, e = -1;
  	StringBuffer nums= new StringBuffer();
		for (int i= 0; i<s.length(); i++) {
			char c= s.charAt(i);
			if (c <= ' ') continue; // eat whitespace
			//if (b == -1 && Character.isDigit(c)) { b= i; }
			//else if (e == -1 && b >= 0 && !Character.isDigit(c)) { e= i; break; }
			else if (Character.isDigit(c)) { nums.append(c); if (b == -1) b= i; }
			else if (b >= 0) { e= i; break; }
			else switch (c) {
				case '<': uncertain |= lessflag; break; // kEndless for end
				case '>': uncertain |= moreflag; break; // kEndmore for end
				case '^': uncertain |= kBetween; break;  
				case '-': minus= true; break;
				}
  		}
  	if (b<0) return -1;
		//if (e<0) e= s.length();
  	//try { val= Integer.parseInt( s.substring(b,e)); } catch (Exception ex) {}
  	try { val= Integer.parseInt( nums.toString()); } catch (Exception ex) {}
  	if (minus) val= -val;
  	val -= kZero; // change to 0 based
  	return val;
	}
  	
  protected void getMyRange(String s) 
  {
		int sepwid= 2;
		int e= s.indexOf("..");
		if (e<0) {
		  e= s.indexOf('^'); 
			if (e>0) { uncertain |= kBetween; sepwid= 1; }
			}
		if (e>=0) { 
			int start= getMyMark( s.substring(0,e));
			int stop = getMyEndMark( s.substring(e+sepwid));
			set( start, stop - start + 1);
			}
		else 
			set( getMyMark( s), 1);
	}
  	
	protected void getNextJoin(String s) 
	{
  	int c= s.indexOf(',');	
		if (c<0) getMyRange( s);
		else {
			getMyRange( s.substring(0,c));
			this.next= new SeqRange();
			next.getNextJoin( s.substring(c+1)); //? should go to parse2() to check for oper?
			}
  }

	public void parse1(String s) throws SeqRangeException
	{ parse2( s.trim()); } //.toLowerCase() -- no, ops are always lc & lc mangles refid
	   
	public void parse2(String s) throws SeqRangeException
  {
  	try {
	  	operation= opNull; //null;
	  	for (byte op= opJoin; op < opMax; op++)  
	  		if (s.startsWith( sOperators[op])) {
	  			operation= op; //sOperators[i];
	  			break;
	  			}
	  	if (operation!=opNull) {  
	  		int e = 0;
	  		int i= s.indexOf('(');
	  		if (i>=0) e= s.indexOf(')', i);
	  		if (e<0) e= s.length();
	  		
	  		// is oper(loc,loc), oper2(loc,loc),... possible?
	  		// or oper( oper2(loc,loc), oper2(loc,loc) ); ??
	  		if (i>0) s= s.substring( i+1, e); //? check for anything after ')'? 
	  		else s= s.substring( sOperators[operation].length() ); //? error
	  		}
	  		
	  	getNextJoin( s); // always - does ',' test
	  	//int c= s.indexOf(','); if (c>0) getNextJoin( s); else getMyRange( s);
	  	}
  	catch (Exception e) {
  		//System.err.println("SeqRange error parsing '"+s+"'");
  		throw new SeqRangeException("SeqRange error parsing '"+s+"'");
  		}
 	}
 	
	public static SeqRange parse(String s) throws SeqRangeException
  {
  	if (s==null) return null;
		SeqRange sr= new SeqRange();
		sr.parse1( s );
		return sr;
	}
	
	
}




