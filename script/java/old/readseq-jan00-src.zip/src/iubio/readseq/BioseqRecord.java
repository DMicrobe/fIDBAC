// BioseqRecord.java
// d.g.gilbert 

package iubio.readseq;

import java.io.*;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import iubio.bioseq.*;
		 


/**
  * BioseqRecord, like SeqFileInfo is an object to join seq and seqdoc objects.
  * It also includes some manipulations for managing features of sequences
  * @author  Don Gilbert
  * @version 	July 1999

 <pre>
  Sample program for feature extraction
  
import java.io.*;
import java.util.*;
import iubio.bioseq.*;
import iubio.readseq.*;
import flybase.Utils;

public class features {
  public static void main( String[] args) 
  {
    if (args==null || args.length==0) System.out.println(
      "Usage: jre -cp .:readseq.jar features find=exon,CDS,... inputfile(s)");
    else try {
      Hashtable feathash= new Hashtable();
      Vector names= new Vector();
      PrintStream out= System.out;
      for (int iarg= 0; iarg &lt; args.length; iarg++) {
        if (args[iarg].startsWith("find=")) {
          String[] ss= Utils.splitString( args[iarg].substring(5), " ,;:");
          out.println("Find features:");
          for (int k=0; k &lt; ss.length; k++) { feathash.put( ss[k], ss[k]); out.println(ss[k]); }
          }
        else names.addElement(args[iarg]);  
        }
      Readseq rd= new Readseq();
      Enumeration en= names.elements();
      while (en.hasMoreElements()) {
        String name= rd.setInputObject( en.nextElement());
        out.println("Reading from " + name);
        if ( rd.isKnownFormat() &amp;&amp; rd.readInit() )  {
          while (rd.readNext()) {
            SeqFileInfo sfi= rd.nextSeq();
            BioseqRecord bsrec= new BioseqRecord(sfi);
            out.println(bsrec);
            FeatureItem[] fits= bsrec.findFeatures( feathash);
            if (fits==null) out.println("  No such features found.");
            else {
              out.println("  Extracted features");
              for (int k= 0; k &lt; fits.length; k++) out.println( fits[k]);
              out.println("  Extracted sequence");
              try { 
                Bioseq bseq= bsrec.extractFeatureBases( feathash);
                out.println(bseq); out.println();
                }
              catch (SeqRangeException sre) { out.println(sre.getMessage()); }
              }
            }
          }
        }
      }
    catch (Exception ex) { ex.printStackTrace(); }
  }
}

	</pre>
  */
	
public class BioseqRecord 
	//implements Cloneable
{
		// for current seq
	public int seqlen, offset;
	//public boolean ismask= false, hasmask= false;

	public Bioseq seq; // Bioseq -  ?don't want to be tied here to specific structure
	public BioseqDocImpl seqdoc; 
	public String seqid;
	
	public BioseqRecord() {}

	public BioseqRecord( Bioseq seq, BioseqDocImpl seqdoc, String seqid) { 
		this.seq= seq;
		this.seqid= seqid;
		this.seqdoc= seqdoc;
		this.seqlen= seq.length();
		//this.offset= offset;
		if (seqid==null && hasdoc()) seqid= seqdoc.getID();
		}

	public BioseqRecord( SeqFileInfo si) { 
		seqid= si.seqid;
		seqlen= si.seqlen;
		offset= si.offset;
		if (si.seq instanceof Bioseq) seq= (Bioseq) si.seq;
		if (si.seqdoc instanceof BioseqDocImpl) seqdoc= (BioseqDocImpl) si.seqdoc;
		if (seqid==null && hasdoc()) seqid= seqdoc.getID();
		}
		
	public final boolean hasseq() { return (seq!=null && seqlen>0); }
	public final boolean hasdoc() { return (seqdoc!=null); }
	public final boolean hasid() { 
		return (seqid!=null && seqid.length()>0 && (seqid != SeqFileInfo.gBlankSeqid) ); }
	//public final boolean hasmask() { return (ismask || hasmask); }
	
	public String toString() {
		StringBuffer sb= new StringBuffer( this.getClass().getName());
		sb.append(": id="); sb.append( seqid);
		sb.append(", length="); sb.append(seqlen);
		if (hasdoc()) {
			sb.append(", title=\""); sb.append(seqdoc.getTitle()); sb.append('"');
			}
		return sb.toString();
		}

	public void copyTo( SeqFileInfo si) {
		si.seqlen= seqlen;
		si.offset= offset;
		si.seq= seq;
		si.seqdoc= seqdoc;
		si.seqid= seqid;
		}

	public final FeatureItem[] findFeatures( Hashtable wantfeatures) {
		return findFeatures(wantfeatures , null);
		}
	public final FeatureItem[] findFeatures(SeqRange wantrange) {
		return findFeatures(null , wantrange);
		}

	public FeatureItem[] findFeatures( Hashtable wantfeatures, SeqRange wantrange)
	{
		if ((wantfeatures!=null || wantrange != null) && seqdoc!=null) {
			if (wantfeatures==null) 	return seqdoc.findFeatures( wantrange);
			Vector v= new Vector();
			Enumeration names= wantfeatures.keys();
			while (names.hasMoreElements()) {
				String name= (String) names.nextElement();
				v= seqdoc.findFeatures( name, wantrange, v);
				}
			if (v.isEmpty()) return null;
			FeatureItem[] fs= new FeatureItem[v.size()];
			v.copyInto(fs);
			return fs;
			}
		else return null;
	}

	public final Bioseq extractFeatureBases( Hashtable wantfeatures)  
		throws SeqRangeException
		{ return extractRemoveFeatureBases( true, wantfeatures, null); }
		
	public final Bioseq extractFeatureBases( Hashtable wantfeatures, SeqRange wantrange)  
		throws SeqRangeException
		{ return extractRemoveFeatureBases(true, wantfeatures, wantrange); }
		
	public final Bioseq removeFeatureBases( Hashtable wantfeatures)  
		throws SeqRangeException
		{ return extractRemoveFeatureBases(false, wantfeatures, null); }
		
	public final Bioseq removeFeatureBases( Hashtable wantfeatures, SeqRange wantrange) 
		throws SeqRangeException
		{ return extractRemoveFeatureBases(false, wantfeatures, wantrange); }
		
	public Bioseq extractRemoveFeatureBases( boolean extract, 
				Hashtable wantfeatures, SeqRange wantrange) throws SeqRangeException
	{
		if (wantfeatures!=null && seqdoc!=null) {
			seqdoc.setWantedFeatures( extract, wantfeatures, wantrange);
			SeqRange featsr= seqdoc.getFeatureRanges(seqlen);
			Bioseq bseq= extractBases( featsr);
			seqdoc.setWantedFeatures( extract, null, null);
			return bseq;
			}
		else return null;
	}
	
	public Bioseq extractBases( SeqRange range) throws SeqRangeException
	{
		if (range==null) 
			throw new SeqRangeException("Null SeqRange");  
		int totlen= 0;
		for (SeqRange sr= range; sr!=null; sr= sr.next())  {
			if (sr.isRemote()) continue;
			totlen += sr.nbases();
			}
			
		if (totlen > 0) {
			int bat= 0;
			byte[] ba= new byte[totlen];
			byte[] bases= seq.toBytes(); // always? or check bioseq.isBytes() ?
			for (SeqRange sr= range; sr!=null; sr= sr.next())  {
				if (sr.isRemote()) continue;
				int start= sr.start();
				int len= sr.nbases();
				
				String err;
				if (start < 0) err= String.valueOf(start) + " start<0";
				else if (start+len > seqlen ) err= String.valueOf(start+len ) + " end>" + String.valueOf(seqlen);
				else if (bat+len > totlen) err= String.valueOf(bat+len) + "  size>" + String.valueOf(totlen);
				else err= null;
				if (err!=null) {
					err= "Bad range: "+ err + " for "+ sr;
					// System.err.println(err); 
					throw new SeqRangeException(err);
					}
				else {
					System.arraycopy( bases, start, ba, bat, len);
					bat += len;
					}
				}
			Bioseq newseq= new Bioseq();
			newseq.setbases(ba);
			return newseq;
			}
		else
			throw new SeqRangeException("Empty SeqRange");  
	}
	

	/*
	public Object clone() {
		try {
			BioseqRecord si= (BioseqRecord) super.clone();
			// reset the per-sequence fields
			si.seqid=  gBlankSeqid;
			si.ismask= si.hasmask= false;
			si.seqlen= 0;
			si.offset= 0;
			si.seq= null;
			si.seqdoc= null;
			si.modtime= 0;
	    return si;
			}
		catch (CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		} 
	*/
}



