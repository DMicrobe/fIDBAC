// BioseqDoc.java
// sequence format information (document,features) handlers
// d.g.gilbert, 1997++


package iubio.readseq;


import java.io.*;
import java.util.*;

import iubio.bioseq.*;
import flybase.*;
import Acme.Fmt;


public interface BioseqDocVals
{
		// some common fields among formats
		// !! update getBioseqdocProperties() below if changes are made here
		// see also BioseqDoc.properties
		
	public final static int 
		kUnknown = 0,  // for extras ...
		kBioseqSet=1, 
		kBioseq=2,  
		kBioseqDoc=3,
		kName = 10, // == ID in general
		kDivision= 11, // databank division: INV, UNA, etc... db specific
		kDataclass= 12, // data class: standard, preliminary, unannotated, backbone
		kDescription = 20,
		kAccession = 30,
		kNid = 31,
		kVersion = 32,
		kKeywords = 40,
		kSource = 50,
		kTaxonomy = 51,
		kReference = 60,
		kAuthor = 61,
		kTitle = 62,
		kJournal = 63,
		kRefCrossref = 64,
		kRefSeqindex = 65,
			
			// various feature flds
		kFeatureTable = 70,
		kFeatureItem = 71,
		kFeatureNote = 72,
		kFeatureKey= 73,
		kFeatureValue=74,
		kFeatureLocation=75,  

		kDate = 80,
		kCrossRef = 90,
		kComment = 100,
		
			// sequence fields
		kSeqstats = 110, // base counts, length, ...
		kSeqdata = 111,
		kSeqlen = 112,
		kSeqkind= 113, //DNA, RNA, tRNA, rRNA, mRNA, uRNA
		kChecksum= 114,
		kSeqcircle= 115, // circular (linear default)
		kStrand= 116, 	// ds, ss, ms
		kNumA= 117, kNumC= 118, kNumG= 119, kNumT = 120, kNumN= 121, // kSeqStats breakdown
		kBlank = 200
			;

			// flags for parsing location in doc
	public final static int 
		kBeforeFeatures = 0,  kAtFeatureHeader= 1, kInFeatures = 2, kAfterFeatures= 3;

			// flags for general doc field kind
	public final static int 
		kField = 1, kSubfield = 2, kContinue = 3, 
		kFeatField= 4, kFeatCont = 5, kFeatWrap= 6;
}

		
public interface BioseqDoc
	extends BioseqDocVals
{
	public String getID();
	public String getTitle();
	public String getFieldName(int kind); //? change to keys - or enumerate keys?
	public String getDocField(int kind);  
	public String getBiodockey(String field); 

	public void addBasicName(String line);
	public void addDocLine(String line); 	
	public void addDocLine(OpenString line); 	
	public void addDocField(String field, String value, int level, boolean append);
				// ^^ drop leve, append from interface ?
				
	public FastVector documents(); 	//? change to enumeration?
	public FastVector features(); 	//?  ""
}



/**
  * sequence format information (document,features)
  * common document fields among formats
  *	@see iubio.drawseq.DrawableBioseqDoc for display of features
	*/
	
public abstract class BioseqDocImpl
	implements BioseqDoc, Cloneable //!?
{
	public static String bioseqprop= "BioseqDoc"; 
	public static String gbfeatname= "Features";
		
	protected static FastHashtable  biodockeys = new FastHashtable();  // biodockey => intval
	protected static FastHashtable	biodockinds= new FastHashtable();  // intval => biodockey
	protected static FastHashtable	biodoclabels= new FastHashtable();  // biodockey => label
	
	static { 
  	//String pname= System.getProperty( propname, propname);
		//getBioseqdocProperties(pname);  //! better not allow changes - see below
		getBioseqdocProperties();
		}
		
		//
		// ! keep this in sync with above BioseqDoc values
		//
	private static void getBioseqdocProperties()
	{ 
		putdocval("kUnknown",kUnknown,"Other field");
		putdocval("kBioseqSet",kBioseqSet,"Biosequence collection");
		putdocval("kBioseq",kBioseq,"Biosequence record");
		putdocval("kBioseqDoc",kBioseqDoc,"Documentation");
		putdocval("kName",kName,"Locus name");
		putdocval("kDivision",kDivision,"Databank division");
		putdocval("kDataclass",kDataclass,"Data class");
		
		putdocval("kDescription",kDescription,"Description");
		putdocval("kAccession",kAccession,"Accession");
		putdocval("kNid",kNid,"NID (part id)");
		putdocval("kVersion",kVersion,"Version");
		putdocval("kKeywords",kKeywords,"Keywords");
		putdocval("kSource",kSource,"Organism source");
		putdocval("kTaxonomy",kTaxonomy,"Organism taxonomy");
		putdocval("kReference",kReference,"Reference number");
		putdocval("kAuthor",kAuthor,"Reference author");
		putdocval("kTitle",kTitle,"Reference title");
		putdocval("kJournal",kJournal,"Reference journal");
		putdocval("kRefCrossref",kRefCrossref,"Reference database ID (Medline)");
		putdocval("kRefSeqindex",kRefSeqindex,"Reference sequence index");
		
		putdocval("kFeatureTable",kFeatureTable,"Feature table");
		putdocval("kFeatureItem",kFeatureItem,"Feature item");
		putdocval("kFeatureNote",kFeatureNote,"Feature note");
		putdocval("kFeatureKey",kFeatureKey,"Feature name");
		putdocval("kFeatureValue",kFeatureValue,"Feature value");
		putdocval("kFeatureLocation",kFeatureLocation,"Feature location");
		 
		putdocval("kDate",kDate,"Date");
		putdocval("kCrossRef",kCrossRef,"Database cross reference");
		putdocval("kComment",kComment,"Comment ");
		putdocval("kSeqstats",kSeqstats,"Sequence statistics");
		putdocval("kNumA",kNumA,"No. A bases");
		putdocval("kNumC",kNumC,"No. C bases");
		putdocval("kNumG",kNumG,"No. G bases");
		putdocval("kNumT",kNumT,"No. T bases");
		putdocval("kNumN",kNumN,"No. other bases");

		putdocval("kSeqdata",kSeqdata,"Sequence data");
		putdocval("kSeqlen",kSeqlen,"Sequence length");
		putdocval("kSeqkind",kSeqkind,"Molecule kind");
		putdocval("kChecksum",kChecksum,"Sequence checksum");
		putdocval("kSeqcircle",kSeqcircle,"Circular sequence");
		putdocval("kStrand",kStrand,"Sequence strandedness");
		putdocval("kBlank",kBlank,"blank line");
	}
	
	private static void putdocval(String key, int val, String label)
	{ 
		Integer ival= new Integer(val);
		biodockeys.put(key, ival);
		biodockinds.put(ival, key);
		//? store label somewhere?
		biodoclabels.put(ival,label); //? by key or by ival?
	}
	

	/*private static void getBioseqdocProperties(String propname)
	{ 
		//key=int val|label
		//ID=10|Locus name
		//AC=30|Accession
		biodockeys.loadProperties(propname);
		Enumeration en= biodockeys.propertyNames();
		while (en.hasMoreElements()) {
			String key= (String) en.nextElement();
			String s= biodockeys.getProperty( key);
			String sval;
			int at= s.indexOf('|');
			if (at>0)  sval= s.substring(0,at); else sval= s;
			//? save label - use some ival, label structure ?
			Integer ival;
			try { ival= new Integer(sval); } 
			catch (Exception e) { ival= new Integer(0); }
			biodockeys.put(key, ival);
			biodockinds.put(ival, key);
			}
	}*/


	/*
	protected static FastProperties gbfeatures; //= new FastProperties(); // load only if asked for
	public static Enumeration getStandardFeatureList()
	{
		int count= getStandardFeatureCount(); // just to save init code
		return gbfeatures.propertyNames();
	}
	
	public static int getStandardFeatureCount()
	{
		if (gbfeatures==null) {
			gbfeatures= new FastProperties();
	  	String pname= System.getProperty( gbfeatname, gbfeatname);
			gbfeatures.loadProperties(pname);
			}
		return gbfeatures.size();
	}
	*/
	
	protected static String[] gbfeatures;  
	public static String[] getStandardFeatureList()
	{
		if (gbfeatures==null) try {
				// want these names sorted ! - are sorted in file...so read file not as properties...
	  	String pname= System.getProperty( gbfeatname, gbfeatname);
	  	pname= AppResources.global.findPath(pname + ".properties");
			Debug.println("Feature list: " + pname);
			InputStream ins= AppResources.global.getStream( pname);
			//if (ins==null) return null;  
			//BufferedReader rdr= new BufferedReader( new InputStreamReader(ins));
			DataInputStream rdr= new DataInputStream( new BufferedInputStream(ins));
			FastVector v= new FastVector();
			String s;
			do { 
				s= rdr.readLine(); 
				if (s!=null) { 
					s= s.trim();
					if (s.length()>0 && !s.startsWith("#")) {
						v.addElement(s); 
						Debug.print(s + ", ");
						}
					}
			} while (s!=null);
			ins.close();
			gbfeatures= new String[v.size()];
			v.copyInto(gbfeatures);
			Debug.println();
			Debug.println(" n = "+v.size());
			/*
			FastProperties fp= new FastProperties();
	  	String pname= System.getProperty( gbfeatname, gbfeatname);
			fp.loadProperties(pname);
			int size= gbfeatures.size();
			Enumeration en= fp.propertyNames();
			gbfeatures= new String[size];
			for (int i= 0; i<size; i++) gbfeatures[i]= (String)en.nextElement();
			*/
			}
		catch (Exception e) {
			e.printStackTrace();
			}
		return gbfeatures;
	}
	


	public BioseqDocImpl() {
		rootdoc = new FastVector();  
		featlist= new FastVector(); 
		//roothash= new FastHashtable();
		}

	public BioseqDocImpl( BioseqDoc source) {
		//this(); // don't need new vectors
		setSourceDoc(source);
		}
		
		
		//
		// subclass for each format
		//
		
	public abstract String getFieldName(int kind);
	public abstract String getBiodockey(String field); 
	public abstract void addDocLine(String line); 	
	public void addDocLine(OpenString line) { addDocLine( line.toString()); }

	
	
	public static String getBiodockey(int kind) { 
		return (String) biodockinds.get( new Integer(kind));
		}

	public static String getBiodoclabel(int kind) { 
		return (String) biodoclabels.get( new Integer(kind));
		}

	public Integer getBiodocKind(String field) { 
		String bdkey= getBiodockey(field); 
		return ((bdkey==null) ? null : (Integer) biodockeys.get( bdkey));
		}

	protected static void getDocProperties(String propname, 
				FastProperties keys2label, FastHashtable label2keys)
	{ 
		keys2label.loadProperties(propname);
		Enumeration en= keys2label.keys(); //propertyNames();
		while (en.hasMoreElements()) {
			String biodockey= (String) en.nextElement();
			String label= keys2label.getProperty(biodockey);
			label2keys.put( label, biodockey);
			}
	}

	public Object clone() {
		try {
			int i;
			BioseqDocImpl c= (BioseqDocImpl) super.clone();
			if (rootdoc!=null) {
				c.rootdoc= (FastVector) rootdoc.clone();
				//c.rootdoc.cloneItems();
		    for ( i= 0; i< rootdoc.size(); i++) {
		    	Object el= c.rootdoc.elementAt(i);
					if (el instanceof DocItem) el= ((DocItem) el).clone();
		    	c.rootdoc.setElementAt(el, i);
					} 
				}

			if (roothash!=null) {
				//? clone it -- are we using this clone()?
				// if so, use rootdoc elements...
				}
			if (wantedFeatures != null) {
				//? clone
				}
		
			if (featlist!=null) {
				c.featlist= (FastVector) featlist.clone();
				//c.featlist.cloneItems();
		    for ( i= 0; i< c.featlist.size(); i++) {
		    	Object el= c.featlist.elementAt(i);
					if (el instanceof DocItem) el= ((DocItem) el).clone();
		    	c.featlist.setElementAt(el, i);
					} 
				}
			//c.doc= c.rootdoc;
			//if (featkinds!=null) c.featkinds= (FastHashtable)featkinds.clone();
		 	return c;
			}
		catch(CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		}


		
	protected FastVector rootdoc, featlist;  
	protected FastHashtable roothash; 
	//protected FastHashtable featkinds; // moved to DrawableBioseqDoc
	protected Hashtable wantedFeatures;
	protected SeqRange wantedRange;
	protected boolean fFromForeignFormat, featWrit, dontWriteId, notWantedFeature;


		//
		// data accessor methods
		//

	public String getID() { return getDocField(kName); } // "ID"
	public String getTitle() { return getDocField(kDescription); } 
		
	public boolean hasFeatures() { return (featlist!=null && featlist.size()>0); }
	public boolean hasDocument() { return (rootdoc!=null && rootdoc.size()>0); }

	public FastVector documents() { return rootdoc; }

	public FastVector features()  { 
		//if (updatingfeats && featkinds==null) updateFeatures();
		return featlist; 
		}
		
	public void setSourceDoc(BioseqDoc source)
	{
		rootdoc= source.documents();
		featlist= source.features();  
		if (source instanceof BioseqDocImpl) copyWanted((BioseqDocImpl)source);
		//roothash= source.roothash;
		fFromForeignFormat = true; // assume yes
	}
	

			// get field by number - only for rootdoc/primary fields
			//
			
	public final String getDocField(int kind) { 
		DocItem di= findDocItem( rootdoc, kind, 0);
		if (di==null) return null; else return di.getValue();
		}
			
	public final String getDocField( FastVector doc, int kind, int which) { 
		DocItem di= findDocItem( doc, kind, which);
		if (di==null) return null; else return di.getValue();
		}
	
	public void deleteDocItem( int kind ) { 
		DocItem di= findDocItem(rootdoc, kind, 0);
		if (di!=null) rootdoc.removeElement(di);
		}
		
	public void deleteDocItem( FastVector doc, int kind, int which) { 
		DocItem di= findDocItem(doc, kind, which);
		if (di!=null) doc.removeElement(di);
		}

	protected int docItemAt;

	public final void replaceDocItem( int kind, DocItem newitem ) { 
		if (newitem==null) deleteDocItem( kind);
		else {
			DocItem di= findDocItem(rootdoc, kind, 0);
			if (di!=null && docItemAt>-1) rootdoc.setElementAt(newitem, docItemAt);
			}
		}
	
	public DocItem findDocItem( FastVector doc, int kind, int which) 
	{ 
		Object ob= null;
		docItemAt= -1;
		if (doc!=null) 
		for (int i= 0, count= 0; i<doc.size(); i++) 
			try {
			ob= doc.elementAt(i);
			if (ob instanceof DocItem) {
				DocItem anv= (DocItem) ob;
				if (anv.getKind()==kind) { 
					docItemAt= i;
					if (count == which) return anv; //.getValue();
					count++;
					}
				}
			else if (ob instanceof FastVector) {  
				DocItem res= findDocItem((FastVector) ob, kind, which);
				if (res!=null) return res;
				}
			}
			catch (Exception e) {
				System.err.println("failure in getDocField("+kind+") for object " + ob);
				e.printStackTrace();
				}
		return null;
	}


			// get field by name
			//
			
	public final String getDocField( String field) { return getDocField(field,0); }
	public final String getFeature( String field) { return getDocField( features(), field,0);  }

	public final String getDocField(String field, int which) {
		//return getDocField(rootdoc,field,which); 
		DocItem di= findDocItem( rootdoc, field, which);
		if (di==null) return null; else return di.getValue();
		}

	public final String getDocField( FastVector doc, String field, int which) { 
		DocItem di= findDocItem( doc, field, which);
		if (di==null) return null; else return di.getValue();
		}

	public DocItem findDocItem( FastVector doc, String field, int which) 
	{ 
		if (doc!=null) for (int i= 0, count= 0; i<doc.size(); i++) {
			Object ob= doc.elementAt(i);
			if (ob instanceof DocItem) {
				DocItem anv= (DocItem) ob;
				if (anv.sameName(field)) { //sameNameOrKind
					if (count == which) return anv; //.getValue();
					count++;
					}
				}
			else if (ob instanceof FastVector) {  
				DocItem res= findDocItem((FastVector) ob, field, which);
				if (res!=null) return res;
				}
			}
		return null;
	}

		


		//
		// methods for parsing doc
		//
		
	protected DocItem curDocitem;
	protected FeatureItem curFieldItem;
	protected int lastlev= kField;
	protected boolean skipdocs;
	protected String lastfld;
	protected int  inFeatures= kBeforeFeatures;
	protected FastHashtable keepFields; 
	
	
	public FeatureItem getCurFieldItem() { return curFieldItem; }
	public void setCurFieldItem(FeatureItem fi) { curFieldItem= fi; }
	
	public void setKeepField(int kind) {
		if (keepFields==null) keepFields= new FastHashtable();
		Integer ikind= new Integer(kind);
		keepFields.put(ikind,ikind);
		}

	protected boolean keepField(int kind) {
		return (keepFields==null || keepFields.get(new Integer(kind))!=null);
		}
		
	public void setSkipDocs(boolean turnon) {
		skipdocs= turnon;
		if (turnon) {
			setKeepField(kName); // only best info
			setKeepField(kDescription);  
			setKeepField(kAccession);  
			setKeepField(kSeqdata);  
			}
		else keepFields= null;
	}
	
		
		/** store a basic locus id/description from various formats */
	public void addBasicName(String line)
	{
		// from seqwriter:public void setSeqName( String name) 
		int i;
		String desc= line;
		desc= desc.trim();
		if ( desc.indexOf("checksum") >0 ) {
	  	i= desc.indexOf("bases");
	  	if (i<0) i= desc.indexOf(" bp");
	    if (i>0) {
	    	for ( ; i > 0 && desc.charAt(i) != ','; i--) ;
	      if (i>0) desc= desc.substring(0, i);
	      }
	    }
		i= desc.indexOf(' ');
		if (i<=0) i= desc.length();
		if (i>30) i= 30;
		if (i == desc.length()) { 
			//idword= desc; desc= null; 
			addDocField( getFieldName( kName), desc, kField, false);
			}
		else { 
			String idword= desc.substring(0,i); 
			addDocField( getFieldName( kName), idword, kField, false);
			addDocField( getFieldName( kDescription), desc, kField, false);
			}
	}

	public void addDocText(String text) {
		inFeatures= kBeforeFeatures;
		addText(text);
		}
	
	public void addFeatureText(String text) {
		inFeatures= kInFeatures;
		addText(text);
		}

	protected void addText(String text) {
		StringTokenizer st= new StringTokenizer(text, "\r\n");
		while (st.hasMoreTokens()) addDocLine( st.nextToken());
		} 	


			
	public void addDocField( DocItem di) { 
		rootdoc.addElement( di); curDocitem= di;
		//? also store hash - 1st only, or last only?
		//if (roothash.get(ikind)==null)
		//	roothash.put( new Integer(di.getKind()), di);
		}

	public void addDocField( String field, String value, int level, boolean append) {
		int kind= kUnknown;
		Integer ikind= getBiodocKind(field); 
		if (ikind!=null) kind= ikind.intValue();
		addDocField(field,value,kind,level,append);
		}
		
	public void addDocField(String field, String value, int kind, int level, boolean append) 
	{ 
		if (!keepField(kind)) return; //?
		if (append && curDocitem != null) {
			//? check that curDocitem.field,kind matches ?
			curDocitem.appendValue( value); 
			// ?? preserve append continuation line feeds ? or store as new item?
			}
		else {
			addDocField( new DocItem(field,value,kind,level) );
			lastlev= level;
			}
	}



				// feature syntax is common to genbank & embl
				//  featfield   location
				//              /featnote=value 
				//              /featnote2=value  
				
	public void addFeature( FeatureItem fi) { 
		featlist.addElement( fi); curFieldItem= fi;
		//featkinds= null; // force updateFeatures
		}

	public void addFeature( String name, SeqRange sr)  { 
		addFeature( new FeatureItem( name, sr, kFeatField) );
		}

	public void addFeatures( FastVector addfeats)  { 
		FastVector feats= features();
		for (int i=0; i<addfeats.size(); i++) {
			Object el= addfeats.elementAt(i);
			if (el instanceof FeatureItem && findFeature(el) == null) {
				el= ((FeatureItem) el).clone(); //?
				feats.addElement((FeatureItem) el);  
				}
			}
		}
	
	public void addFeature(String field, String value, int level, boolean append) 
	{ 
		if (level == kFeatField) { if (!keepField(kFeatureItem)) return; }
		else if (level == kFeatCont) { if (!keepField(kFeatureNote)) return; }
		// add opt to drop specific features? - but use w/ extract/remove sequence?
		
		if (level == kFeatField) {
			if (append && curFieldItem != null)  
				curFieldItem.appendValue(value);
			else  
				addFeature( new FeatureItem(field, value, kFeatField) );
			//^^ needs to append sometimes !!!
			}
		else if (curFieldItem!=null) {
			if (value.charAt(0) == '/') {  
				int at= value.indexOf('='); // field == value if no = ?
				if (at<0) {
					field= value; value= "";
					}
				else {
					field= value.substring(0, at);
					value= value.substring(at+1);
					}
				curFieldItem.putNote( new FeatureNote(field, value, kFeatureNote, level)); 
				}
			else {
				 // continuation?, append to last note value?
				curFieldItem.appendNote( value); 
				}
			}
	}

	public void deleteFeature(String name, SeqRange sr) 
	{ 
		FeatureItem fi= findFeature(name, sr);
		if (fi!=null) features().removeElement(fi);
	}
	
	
	public FeatureItem findFeature(String name, SeqRange sr) 
	{ 
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			if (sr==null) { if (fi.getName().equals(name)) return fi; }
			else if (name==null) { if (fi.getLocation().intersects(sr)) return fi; }
			else if (fi.getName().equals(name) && fi.getLocation().intersects(sr)) return fi;
			}
		return null;
	}

	public FeatureItem findFeature(String name) 
	{ 
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			if (fi.getName().equals(name)) return fi;  
			}
		return null;
	}

	public FeatureItem findFeature(Object item) 
	{ 
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			if (fi.equals(item)) return fi;
			}
		return null;
	}
	
	public final FeatureItem[] findFeatures( SeqRange sr) { 
		return findFeatures( (String)null, sr);
		}
	public final FeatureItem[] findFeatures( String name) { 
		return findFeatures(name, (SeqRange)null);
		}
	public FeatureItem[] findFeatures(String name, SeqRange sr) 
	{ 
		Vector v= findFeatures(name,sr, null);
		FeatureItem[] ss= new FeatureItem[v.size()];
		v.copyInto(ss);
		return ss;
	}
	
	public final Vector findFeatures( SeqRange sr, Vector addto) { 
		return findFeatures(null, sr, addto);
		}
	public final Vector findFeatures( String name, Vector addto) { 
		return findFeatures(name, null, addto);
		}
	public Vector findFeatures( String name, SeqRange sr, Vector addto) 
	{ 
		if (addto==null) addto= new Vector();
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			if (sr==null) {
				if (fi.getName().equals(name)) addto.addElement(fi);
				}
			else if (name==null || fi.getName().equals(name))
				if (fi.getLocation().intersects(sr)) addto.addElement(fi);
			}
		return addto;
	}

	public String[] getFeaturesAt( SeqRange sr) 
	{ 
		Vector v= new Vector();
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			if (fi.getLocation().intersects(sr)) v.addElement(fi.getName());
			}
		String[] ss= new String[v.size()];
		v.copyInto(ss);
		return ss;
	}

 		/** changeflags: SeqRange.kDelete = 1, kInsert = 2, kReorder = 4, kChange = 8; */
	public void updateRange(int changeflags, int start, int length, byte[] changes) 
	{
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			fi.updateRange(changeflags, start, length, changes);
			}
	}

	public final void removeRange(SeqRange sr) {
		for (SeqRange loc= sr; loc!=null; loc= loc.next())  
			updateRange( SeqRange.kDelete, loc.start(), loc.nbases(), null);
		}
		
	public final void insertRange(SeqRange sr) {
		for (SeqRange loc= sr; loc!=null; loc= loc.next())  
			updateRange( SeqRange.kInsert, loc.start(), loc.nbases(), null);
		}
		
		//!? dec'99 overload this to handle doc field extract/removal
		// and permit mix of extract/remove, per field (using 'false' or 'true' value of hash key)
	public Hashtable wantedFeatures() { return wantedFeatures; }
	public SeqRange wantedRange() { return wantedRange; }
	public boolean isNotWantedFeature() { return notWantedFeature; }
 
 	protected void copyWanted(BioseqDocImpl src) {
 		setWantedFeatures(src.wantedFeatures, src.wantedRange);
 		}
 		
 	public void setWantedFeatures( Hashtable wantfeatures) {
		setWantedFeatures( wantfeatures, null);
		}
		
 	public void setWantedFeatures( Hashtable wantfeatures, SeqRange wantedrange) {
		boolean extract= true;
		if (wantfeatures!=null) 
			try { extract= ! ("false".equals( wantfeatures.elements().nextElement())); } 
			catch (Exception ex) {} // NoSuchElementException
				/// ^^ is check of 1st all we need?
		setWantedFeatures( extract, wantfeatures, wantedrange);
		}

 	public void setWantedFeatures( boolean extract, Hashtable wantfeatures, SeqRange wantedrange) {
		wantedFeatures= wantfeatures;
		wantedRange= wantedrange;
		notWantedFeature= !extract;
		}
	
	public final SeqRange getFeatureRanges(int seqlen) {
		SeqRange srlist= getFeatureRanges(wantedFeatures,seqlen);
		wantedRange= srlist; //?
		return srlist;
		}
		
	public SeqRange getFeatureRanges( Hashtable wantfeatures, int seqlen) 
	{
		if (wantfeatures==null) return null;
		SeqRange srlist= new SeqRange(); // return empty range for no features found?
		boolean foundfeat= false;
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			String fname= fi.getName();
			if (wantfeatures.get(fname)!=null) { 
				foundfeat= true;
				SeqRange sr= fi.getLocation();
				srlist= srlist.joinRange( sr);  
				}
			}
		if (notWantedFeature) {
			if (foundfeat) srlist= srlist.invert(seqlen);
			else return null; // process as if no wantedRange
			}
		if (Debug.isOn) Debug.println("getFeatureRanges: "+srlist);
		return srlist;
	}

	/*
	public SeqRange getFeatureRanges0( Hashtable wantfeatures) 
	{
		if (wantfeatures==null) return null;
		SeqRange srlist= new SeqRange(); // return empty range for no features found?
		boolean hasExcluded= false;
		FastVector feats= features();
		for (int i= 0, n= feats.size(); i<n; i++) {
			FeatureItem fi= (FeatureItem) feats.elementAt(i);
			String fname= fi.getName();
			boolean keep;
			if (notWantedFeature) {
				keep= (wantfeatures.get(fname)==null);
				if (!keep) hasExcluded= true;
				}
			else 
				keep= (wantfeatures.get(fname)!=null);
			if (keep) { 
				SeqRange sr= fi.getLocation();
				if (srlist==null) srlist= (SeqRange)sr.clone();
				else srlist= srlist.joinRange( sr);  
				}
			}
		if (Debug.isOn) Debug.println("getFeatureRanges: "+srlist);
		if (notWantedFeature && !hasExcluded) return null; // process as if no wantedRange
		return srlist;
	}
	*/
	
	
		//
		//  methods for writing doc
		//
		
	public static int kLinewidth= 78;
	
	protected int indent, subindent, linesout;
	protected PrintWriter pr;
	
	public int linesWritten() { return linesout; }


	final String spaces(int n) { return Fmt.fmt( "", n); }
		
	protected String getFieldLabel( DocItem di)  { return getFieldLabel( di.getLevel(), di); }
	
	protected String getContinueLabel( DocItem di)  
	{
		switch (di.getLevel()) 
		{
			default:
				return getFieldLabel( kContinue, di);
			case kFeatField : 
			case kFeatCont  : 
			case kFeatWrap  : 
				return getFieldLabel( kFeatWrap, di);
		}
	}

	protected String getFieldLabel( int level, DocItem di)  
	{
		indent= 5;
		return Fmt.fmt( di.getName(), indent, Fmt.LJ);
	}

	protected String getFieldValue( DocItem di) { 
			// FeatureItem now does this as getValue()
		// if (di instanceof FeatureItem) return ((FeatureItem) di).locationString(); else 
		String val= di.getValue();
		//if (val!=null) val= val.trim();  //? is value ever null?
		return val; 
		}

	public void setOutput( Writer outs)
	{
		if (outs instanceof PrintWriter) {
			this.pr= (PrintWriter) outs;
			}
		else {
			BufferedWriter bufout;
			if (outs instanceof BufferedWriter) bufout=(BufferedWriter)outs; 
			else bufout= new BufferedWriter(outs); 
			this.pr= new PrintWriter(bufout);
			}
		linesout= 0;
		indent= 0;
	}

	public void setOutput( OutputStream outs)
	{
		BufferedOutputStream bufout;
		if (outs instanceof BufferedOutputStream) bufout=(BufferedOutputStream)outs; 
		else bufout= new BufferedOutputStream(outs); 
		this.pr= new PrintWriter(bufout);
		linesout= indent= 0;
	}

		
	public int writeTo(Writer outs) { return writeTo(outs, false); } 
	public int writeTo(Writer outs, boolean doId) 
	{
		this.dontWriteId= !doId;
		setOutput( outs);
		writeAllText();
		return linesWritten();
	}

	public void writeAllText() 
	{ 
		featWrit= false;
		writeTextTop( rootdoc, true); 
			// force write features if not done
		if (!featWrit && features().size()>0) {
			String fn= getFieldName( kFeatureTable);
			writeDocItem( new DocItem( fn, "", kFeatureTable, kField), true); 
			}
	}

	public void writeDocumentText() { writeTextTop( documents(), false);	}
	public void writeFeatureText()  { writeTextTop( features(), false); }

	public String getDocumentText() { 
		ByteArrayOutputStream baos= new ByteArrayOutputStream();
		setOutput( new PrintWriter(baos));
		writeDocumentText(); 
		pr.flush();
		return baos.toString();
		}
		
	public String getFeatureText() { 
		ByteArrayOutputStream baos= new ByteArrayOutputStream();
		setOutput( new PrintWriter(baos));
		writeFeatureText();
		pr.flush();
		return baos.toString();
		}
		

	protected void writeTextTop( FastVector v, boolean writeAll) {
		writeDocVector( v, writeAll);  
		}
	
	protected void writeDocVector( FastVector v, boolean writeAll) {
		for (int i= 0; i<v.size(); i++) writeDocItem( (DocItem)v.elementAt(i), writeAll);
		}

	protected final static String sExtractionFeature = "extracted_range";
	
	protected boolean wantFeature(DocItem di) {
		if (wantedFeatures==null) return true;
		String name= di.getName();
		if (sExtractionFeature.equals(name)) return true;

		String wantval= (String) wantedFeatures.get(name);
		if (wantval==null) return notWantedFeature; // this is rub - what is default for no explicit value?
		else if ("true".equals(wantval)) return true;
		else if ("false".equals(wantval)) return false;
		else return notWantedFeature; // this is rub - what is default for no explicit value?
		//if (notWantedFeature)  return (wantedFeatures.get(name)==null);
		//else return (wantedFeatures.get(name)!=null);
		}
		
	protected void writeExtractionFeature() 
	{
		if (wantedFeatures != null && wantedRange!=null) { 
				//? write this as feature? -- or as comment ?
				//? write list of features removed?
						// dang - for embl/gb need "" around text, not for xml
			String dq= (this instanceof XmlDoc) ? "" : "\"";
			FeatureItem wfi= new FeatureItem( sExtractionFeature, wantedRange, kFeatField);
			wfi.putNote( new FeatureNote("/note", 
				 dq + "Range of sequence extracted from original, due to feature selection."
			  		+"  Feature locations are not valid for this sequence, but for original." + dq, 
				kFeatureNote, kFeatCont)); 
			writeDocItem( wfi, false);
			}
	}
		
	protected boolean writeKeyValue( DocItem di ) 
	{
		//String name= di.getName();
		//String val= di.getValue(); //? allow non-string vals, like SeqRange ?
		//int kind= di.getKind();  
		//int lev1= di.getLevel(); 
		
		String lab= getFieldLabel( di); // lev1, kind, name, di.hasValue() 
		if (lab!=null) { 
			pr.print( lab );
			String val= getFieldValue( di); //val, lev1, kind, name
			while (val!=null) {
				val= writeWrapText( val, indent, kLinewidth); 
				if (val!=null) {
					String continuelab= getContinueLabel( di);  
					pr.print( continuelab );
					}
				}
			return true;
			}
		else return false;
	}

	
	protected void writeDocItem( DocItem nv, boolean writeAll) 
	{
		switch (nv.getKind()) 
		{
			case kSeqdata: 
				return; // doing elsewhere

			case kName:
				if (!dontWriteId) writeKeyValue( nv);
				break;
			
			case kFeatureTable:
				if (!featWrit) {
					if (writeKeyValue( nv) && writeAll) {
						writeDocVector( features(), writeAll); 
						writeExtractionFeature();
						featWrit= true;
						}
					}
				break;
			
			case kFeatureItem:
				if (wantFeature(nv)) {
					if (writeKeyValue( nv) && (nv instanceof FeatureItem)) {  
						FeatureItem fi= (FeatureItem) nv; 
						if (fi.notes != null) writeDocVector( fi.notes, false);  
						}
					}
				break;
			
			case kFeatureNote:
				writeKeyValue( nv);
				break;
				
			default:
				if (wantFeature(nv)) writeKeyValue( nv); // added dec'99 - okay?
				break;
		}
		
	}
	
	
	protected String writeWrapText( String val, int indent, int width)
	{
		String rval= null;
		int maxw= width - indent;
		if (val.length() > maxw) {
			int max2= maxw+2;
			int at= val.lastIndexOf(' ',max2);
			if (at < 0) { at= val.lastIndexOf(',', max2); if (at>0) at++; }
			if (at < 0) { at= val.lastIndexOf(';', max2); if (at>0) at++; }
			if (at < 0) { at= val.lastIndexOf('.', max2); if (at>0) at++; }
			if (at < 0) at= maxw; // force break?
			if (at > 10) {
				rval= val.substring( at).trim();
				val= val.substring( 0, at);
				}
			}
		pr.println( val); linesout++;
		return rval;
	}
	

	
};







public class EmblDoc extends BioseqDocImpl
{
	public static String emblprop= "EmblDoc"; 
	private static FastHashtable elabel2keys = new FastHashtable();  // format label => biodockey
	private static FastProperties	keys2elabel= new FastProperties();  // biodockey => format label
	
	static { 
  	String pname= System.getProperty( emblprop, emblprop);
  	//getDocProperties(pname);
  	getDocProperties(pname,keys2elabel,elabel2keys);
		}

		
	public EmblDoc() { }
	
	public EmblDoc(BioseqDoc source) {
		super(source);
		fFromForeignFormat = !(source instanceof EmblDoc);
		}
		
	public EmblDoc(String idname) { 
		super();
		addBasicName( idname);
		//addDocLine("ID   " + idname);
		//addDocLine("FT   "); //? to allow adding features
		//addDocField("ID", idname, kField, false); 
		//addDocField("FT", "", kField, false);  //? for adding features
		}

	private static String  fFeatureTag= "FT";
	private static int fFeatIndent= 21, fFieldIndent= 5;
	private boolean gotOneFT;
	

	public void setSourceDoc(BioseqDoc source)
	{
		super.setSourceDoc(source);
		fFromForeignFormat = !(source instanceof EmblDoc);
	}
		
	//public String getID() { return getDocField(kName); } //"ID"
	//public String getTitle() { return getDocField(kDescription); } //"DE"
		
	public void addDocLine(String line) 
	{ 
		String field, value;
		boolean append= false;
		
		int level= kField;
		int at= line.indexOf(' ');
		int len= line.length();
		
		if (at<0) {
			if (line.startsWith("XX")) return;
			line= line.trim();
			len= line.length();
			field= line;
			value= null;
				// are all such value-less fields window-dressing or bogus?
			switch (inFeatures) {
				case kBeforeFeatures: 
					if (field.equals(fFeatureTag)) inFeatures= kInFeatures;
					break;
				case kInFeatures: 
					//if (!field.equals(fFeatureTag)) inFeatures= kAfterFeatures;
					if (field.equals(fFeatureTag)) return; // 2nd value-less FT tag is redundant...
					else inFeatures= kAfterFeatures;
					break;
				}
			if (inFeatures != kInFeatures)  level= kField;
			else level= kFeatField; 
			}
			
		else {
			field= line.substring(0,at);
			while (at<len && line.charAt(at) == ' ') at++;
							
			switch (inFeatures) {
				case kBeforeFeatures: 
					if (field.equals(fFeatureTag)) inFeatures= kInFeatures;
					break;
				case kInFeatures: 
					if (!field.equals(fFeatureTag)) inFeatures= kAfterFeatures;
					break;
				}

			if (inFeatures != kInFeatures) {
				if (field.equals(lastfld)) {
					level= kContinue;  
					append= true;
					}
				else  
					level= kField;
				}
				
			else {
				if (at<fFeatIndent) {
					level= kFeatField; 
					int e= at;
					len= line.length();
					while (e<len && line.charAt(e) != ' ' && e<fFeatIndent) e++;
					field= line.substring(at, e);
					at= e;
					while (at<len && line.charAt(at) == ' ' && at<fFeatIndent) at++;
					}
				else {
						// ! this could be an append of kFeatField ! -- long locations wrap
					if (lastlev == kFeatField && line.charAt(at) != '/') {
						level= kFeatField; append= true;
						}
					else level= kFeatCont; 
					field= lastfld; //??
					//? append or not - if key starts with / and has = ???
					}
				}

			value= line.substring(at).trim();  //?? always trim?
			}
			
		if (inFeatures==kInFeatures) addFeature( field, value, level, append);
		else addDocField( field, value, level, append);
		if (level != kContinue) { lastfld= field; lastlev= level; }
	}

	private int addlinefield( String val, int vallen, int at, String scanto, 
														String fldname, int fldkind, int fldlev)
	{
		if (at > vallen) return -1;
		int e= val.indexOf(scanto, at);
		if (e<0) e= vallen;
		String sv= val.substring( at, e).trim();
		if (sv.length()>0) super.addDocField( fldname, sv, fldkind, fldlev, false);
		return e + scanto.length();
	}

	public void addDocField(String field, String val, int level, boolean append) 
	{ 
		int kind= kUnknown;
		if (level == kField || level == kSubfield || level == kContinue) {
			Integer ikind= getBiodocKind(field); 
			if (ikind!=null) kind= ikind.intValue();
				
			switch (kind) {
			
				//ID   DMEST6A    standard; DNA; INV; 1754 BP.
				//ID   BDEJM5357  unannotated; RNA; UNC; 168 BP.
				//ID   PPJCG      standard; circular DNA; UNC; 1288 BP.
				case kName: {
					int vlen= val.length();
					int at= addlinefield( val, vlen, 0, " ", field, kName, kField);
					if (at>0) at= addlinefield( val, vlen, at, "; ", "dataclass", kDataclass, kField);
					if (at>0) {
						int cir= val.indexOf("circular", at);
						if (cir>0) {
							super.addDocField( "circ", "circular", kSeqcircle, kField, false);
							at= cir + "circular".length();
							}
						}
					if (at>0) at= addlinefield( val, vlen, at, "; ", "mol", kSeqkind, kField);
					if (at>0) at= addlinefield( val, vlen, at, "; ", "div", kDivision, kField);
					if (at>0) at= addlinefield( val, vlen, at, " BP", "length", kSeqlen, kField);
					return;					
					}
					
				//SQ   Sequence 1859 BP; 609 A; 314 C; 355 G; 581 T; 0 other;
			 	case kSeqstats: {
					int vlen= val.length();
					super.addDocField( field, "", kSeqstats, kField, false);	// add blank seqstats, build for output				
					int at= val.indexOf("BP;") + 4; // skip past Sequence  462 BP;
					if (at>0) at= addlinefield( val, vlen, at, " A;", "na", kNumA, kSubfield);
					if (at>0) at= addlinefield( val, vlen, at, " C;", "nc", kNumC, kSubfield);
					if (at>0) at= addlinefield( val, vlen, at, " G;", "ng", kNumG, kSubfield);
					if (at>0) at= addlinefield( val, vlen, at, " T;", "nt", kNumT, kSubfield);
					if (at>0) at= addlinefield( val, vlen, at, " other", "nn", kNumN, kSubfield);
					return;
					}
					
			 	case kReference: {
			 		int a= val.indexOf('[');
			 		int e= val.indexOf(']');
			 		if (a>=0 && e>a) val= val.substring(a+1,e);
			 		break;
					}
				
				case kCrossRef:	
			  case kDate:
					level= kField;  
			  	append= false; // make sep. fields for each embl DT
			  	break;
	
				case kTitle: {
					if (level == kField) level= kSubfield; // fix to match GB subfields
					if (val.startsWith("\"")) val= val.substring(1);
					int vlen= val.length();
					if (val.endsWith("\";")) val= val.substring(0,vlen-2);
					else if (val.endsWith(";")) val= val.substring(0,vlen-1);
					break;
					}
					
				
				case kTaxonomy:
				case kAuthor:
				case kJournal:
				case kRefCrossref:
				case kRefSeqindex:
					if (level == kField) 
					level= kSubfield; // fix to match GB subfields
					break;
					
					// trim some trailing ';'
				case kAccession:
					//int e= val.lastIndexOf(';');
					//if (e>0) val= val.substring(0,e);
					val= val.replace(';',' ');
					break;		  	
			 	}
	 	 
 			}
		super.addDocField( field, val, kind, level, append);
	}
	

	int lastkind;
	
	protected void writeDocItem( DocItem nv, boolean writeAll) 
	{
		int kind= nv.getKind();
		switch (kind) 
		{
			case kSeqkind: 
			case kSeqlen: 
			case kDivision: 
			case kDataclass:
			case kSeqcircle:
			case kStrand:
			case kNumA: 
			case kNumC: 
			case kNumG: 
			case kNumT: 
			case kNumN: 
			case kBioseqSet:
			case kBioseq:
			case kBioseqDoc:
				break; // doing elsewhere
				
			case kSeqstats: //? always write - EMBL must have before seq data
				lastkind= kind; 
				pr.println("XX");
				writeKeyValue( nv);
				break;

			default:
					//??? put in some XX's for prettiness/compat w/ embl
				if (kind!=lastkind && kind!=kName && kind!=kSeqdata && nv.getLevel() == kField)  
					pr.println("XX");
				lastkind= kind; 
				super.writeDocItem( nv, writeAll);
				break;
		}
	}
		
	private void putlinefield( StringBuffer sb, String sv, String defval, String tail)
	{
		sb.append( (sv==null ? defval : sv));  
		sb.append(tail);
	}
	
	protected String getFieldValue( DocItem di)  
	{ 
		switch (di.getKind()) 
		{
			case kFeatureTable:
				return "Key             Location/Qualifiers";
				
				//ID   DMEST6A    standard; DNA; INV; 1754 BP.
				//ID   BDEJM5357  unannotated; RNA; UNC; 168 BP.
				//ID   PPJCG      standard; circular DNA; UNC; 1288 BP.
			case kName: {
				StringBuffer sb= new StringBuffer();
				putlinefield( sb, Fmt.fmt( di.getValue(), 10, Fmt.LJ), "Noname", " ");
				putlinefield( sb, getDocField(kDataclass), "standard", "; ");

				String sv= getDocField( kSeqcircle);
				if (sv!=null) { sb.append( sv); sb.append(' '); }
				putlinefield( sb, getDocField(kSeqkind), "DNA", "; ");
				putlinefield( sb, getDocField(kDivision), "UNC", "; ");
				putlinefield( sb, getDocField(kSeqlen), "0", " BP.");
				return sb.toString();
				}

			case kReference:
				String rn= di.getValue();
 				return "["+rn+"]";
 				
				//SQ   Sequence 1859 BP; 609 A; 314 C; 355 G; 581 T; 0 other;
			case kSeqstats:
				{
				StringBuffer sb= new StringBuffer("Sequence ");
				putlinefield( sb, getDocField(kSeqlen), "0", " BP; ");
				putlinefield( sb, getDocField(kNumA), "0",  " A; ");  
				putlinefield( sb, getDocField(kNumC), "0",  " C; ");  
				putlinefield( sb, getDocField(kNumG), "0",  " G; ");  
				putlinefield( sb, getDocField(kNumT), "0",  " T; "); 
				putlinefield( sb, getDocField(kNumN), "0",  " other;");  
				return sb.toString();  
				}
				
				// add back ';'
			case kAccession: {
				String val= di.getValue();
				if (val.indexOf(' ')>0) {
					StringBuffer sb= new StringBuffer();
					StringTokenizer st= new StringTokenizer(val, " ");
					while (st.hasMoreTokens()) { sb.append( st.nextToken()); sb.append("; "); }
					return sb.toString();
					}
				else return val + ";";
				}	  	

			case kTitle: {
				String val= di.getValue();
				if (val.length()>1 && !val.endsWith("\";")) val= "\"" + val + "\";";
				return val;
				}

			default:
				return super.getFieldValue(di);  
		}
	}


	protected String getFieldLabel( int level, DocItem di) //int level, int kind, String name, boolean hasval
	{
		String name= null;
		indent= 0;
		subindent= 0; // none in embl	
		switch (level) 
		{
			default:
			case kContinue  : 
			case kField     : 
			case kSubfield  :  
				if (fFromForeignFormat) name= getFieldName( di.getKind()); else name= di.getName();
				if ( name==null || name.length()==0 ) return null;
				//if ( di.getKind() == kSeqstats) return null; //??
				indent= fFieldIndent; 
				return Fmt.fmt( name, indent, Fmt.LJ);
								
			case kFeatField : 
				indent= fFeatIndent;
				return "FT" +  spaces( fFieldIndent - 2)  + Fmt.fmt( di.getName(), indent - fFieldIndent, Fmt.LJ); 
				
			case kFeatCont  : 
				name= di.getName();
				if (di.hasValue()) name += "="; 
				indent= fFeatIndent;
				return "FT" +  spaces( indent - 2)  + name;

			case kFeatWrap  : 
				indent= fFeatIndent;
				return Fmt.fmt( "FT", indent, Fmt.LJ);
		}
	}

	public String getBiodockey(String field) { return (String) elabel2keys.get(field); }
	
	public String getFieldName(int kind) 
	{ 
		indent= fFieldIndent;
		String lab= null; //getDoclabel( kind);
		String biodockey= getBiodockey(kind);
		if (biodockey!=null) lab= (String) keys2elabel.get( biodockey);
		switch (kind) {
			case kFeatureTable: 
				if (gotOneFT) return null;
				gotOneFT= true;
				indent= fFeatIndent;
				break;
			case kFeatureItem: 	 
			case kFeatureNote:  indent= fFeatIndent; break;  
			}
		return lab;
	}
	
};






public class GenbankDoc extends BioseqDocImpl
{
	public static String gbprop= "GenbankDoc"; 
	private static FastHashtable glabel2keys = new FastHashtable();  // format label => biodockey
	private static FastProperties	keys2glabel= new FastProperties();  // biodockey => format label

	static { 
  	String pname= System.getProperty( gbprop, gbprop);
  	getDocProperties(pname,keys2glabel,glabel2keys);
		}
	
	public GenbankDoc() {  }
	
	public GenbankDoc(String idname) { 
		super();
		addBasicName( idname);
		}
		
	public GenbankDoc(BioseqDoc source) {
		super(source);
		fFromForeignFormat = !(source instanceof GenbankDoc);
		}


	private boolean gotOneFT;
	private final static String fFeatureTag= "FEATURES";
	private final static int fFeatIndent= 21, fFieldIndent= 12;
	private final static int fFieldIndent1= fFieldIndent+1;


	public void setSourceDoc(BioseqDoc source)
	{
		super.setSourceDoc(source);
		fFromForeignFormat = !(source instanceof GenbankDoc);
	}


	public void addDocLine(String line) 
	{ 
		String field= null, value= null;
		boolean append= false;
		int level= kField, at= line.indexOf(' ');
		int len= line.length();
		if (at<0) at= len; //?
		
		if (at>0) {  
			level= kField;
if (true) {
			int cut= fFieldIndent;
			if (len <= cut) cut= len; // error !
			field= line.substring( 0, cut).trim();
			value= line.substring( cut ); // don't trim, at least not for BASE COUNT line...	
			int vlen= value.length();
			int e= vlen;
			while (e>0 && value.charAt(e-1) <= ' ') e--;
			if (e<vlen) value= value.substring(0,e); // trim tail, esp. newline
} else {
			if (at<fFieldIndent-1 && Character.isLetterOrDigit(line.charAt(at+1)))
				at= line.indexOf(' ',at+1); // fix for 'BASE COUNT'
			field= line.substring(0,at);
			while (at<len && line.charAt(at) == ' ') at++;
			value= line.substring(at);
}			
			switch (inFeatures) {
				case kInFeatures: inFeatures= kAfterFeatures; break;
				case kBeforeFeatures: 
					if (field.equals(fFeatureTag)) inFeatures= kAtFeatureHeader;
					break;
				}
			}
			
		else if (at == 0) {
			while (at < len && line.charAt(at) == ' ' && at<fFieldIndent) at++;
			if (at>=fFieldIndent) {
						// continue last field value
				value= line.substring(at).trim(); //? trim okay? need for '/' test
				field= lastfld;
				if (inFeatures==kInFeatures) {
					if (lastlev == kFeatField && !value.startsWith("/")) {
						level= kFeatField; append= true;
						}
					else level= kFeatCont; 
 					//field= " ";  //??
					}
				else {
					level= kContinue;  //??
					append= true;
					}
				}
			else {
					// indented subfield
				if (inFeatures==kInFeatures) 
					level= kFeatField; 
				else  
					level= kSubfield;  
				int e= line.indexOf(' ',at);
				if (e<0) e= len;
				field= line.substring(at,e);
				at= e; while (at < len && line.charAt(at) == ' ') at++;
				value= line.substring(at);
				}
			if (value!=null) value= value.trim(); //?? always
			}
		
		if (inFeatures==kInFeatures) addFeature( field, value, level, append);
		else addDocField( field, value, level, append);
		if (inFeatures==kAtFeatureHeader) inFeatures= kInFeatures;
		if (level != kContinue) { lastfld= field; lastlev= level; }
	}


	
	private int addlinefield( String val, int vallen, int btab, int etab, 
														String fldname, int fldkind, int fldlev)
	{
		btab -= fFieldIndent1; etab -= fFieldIndent1;
		if (etab > vallen) return -1;
		String sv= val.substring( btab, etab).trim();
		if (sv.length()<=0) return 0;
		super.addDocField( fldname, sv, fldkind, fldlev, false);
		return 1;
	}
	
	
	public void addDocField( String field, String val, int level, boolean append) 
	{ 
		int kind= kUnknown;
		if (level == kField || level == kSubfield || level == kContinue) {
			Integer ikind= getBiodocKind(field); 
			if (ikind!=null) kind= ikind.intValue();
			int vlen= val.length();
				
			switch (kind) {
			
				//LOCUS       AF005656     1504 bp    DNA   circular  UNA       02-JAN-1999
				//LOCUS       TRN10A02      178 bp ss-RNA             UNA       04-OCT-1994
			  //............13........23......31.34.37....43........53........63.........75
				case kName: {
					if (0 > addlinefield( val, vlen, 13, 23, field, kName, kField))
						return;
					if (0 > addlinefield( val, vlen, 23, 31, "length", kSeqlen, kField))
						return;
					if (0 > addlinefield( val, vlen, 34, 36, "strand", kStrand, kField))
						return;
					if (0 > addlinefield( val, vlen, 37, 43, "mol", kSeqkind, kField))
						return;
					if (0 > addlinefield( val, vlen, 43, 53, "circ", kSeqcircle, kField))
						return;
					if (0 > addlinefield( val, vlen, 53, 63, "div", kDivision, kField))
						return;
					addlinefield( val, vlen, 63, vlen+fFieldIndent1, "date", kDate, kField);
					return;
					}
					
			  //BASE COUNT      276 a    246 c    295 g    262 t
				//BASE COUNT       27 a     40 c     32 g     17 t      2 others
			  //....................21.......30.......39.......48.......57.........
			 	case kSeqstats: {
					super.addDocField( field, "", kSeqstats, kField, false);	// add blank seqstats, build for output				
					if (0 > addlinefield( val, vlen, 13, 20, "na", kNumA, kSubfield))
						return;
					if (0 > addlinefield( val, vlen, 23, 29, "nc", kNumC, kSubfield))
						return;
					if (0 > addlinefield( val, vlen, 32, 38, "ng", kNumG, kSubfield))
						return;
					if (0 > addlinefield( val, vlen, 41, 47, "nt", kNumT, kSubfield))
						return;
					addlinefield( val, vlen, 50, 56, "nn", kNumN, kSubfield);
			 		return;
					}
					
			 	case kReference: {
			 		int a= val.indexOf("(bases");
			 		int e= val.indexOf(')');
			 		if (a>=0 && e>a) {
			 			String rsi= val.substring(a + "(bases".length(),e).trim();
			 			val= val.substring(0,a).trim();
			 			a= rsi.indexOf(" to ");
			 			if (a>0) rsi= rsi.substring( 0, a) + "-" + rsi.substring(a+4);
						super.addDocField( field, val, kReference, kField, false);
						super.addDocField( "pubseq", rsi, kRefSeqindex, kSubfield, false);
						return;
			 			}
			 		break;
			   	}
			   	
			 	}
	 		}
		super.addDocField( field, val, kind, level, append);
	}


	public String getBiodockey(String field) { return (String) glabel2keys.get(field); }



		//? need/want a getFieldLevel(int kind)
		// so embl/xml subfields match gb - ref subflds, source subflds ...
		
	public String getFieldName(int kind) 
	{ 
		indent= fFieldIndent;
		subindent= 0;
		String lab= null; //getDoclabel( kind);
		String biodockey= getBiodockey(kind);
		if (biodockey!=null) lab= (String) keys2glabel.get( biodockey);

		switch (kind) {
				//! hack - add subfield indent - need another way!
			case kTaxonomy: 
			case kAuthor: 
			case kTitle:  
			case kJournal:  
			case kRefCrossref: subindent= 2; break;
							
			case kFeatureTable: 
				if (gotOneFT) return null;
				indent= fFeatIndent; 
				gotOneFT= true;
				return "FEATURES"; 
			case kFeatureItem: return " "; //lab= fldlab; indent= 5; break;  
			case kFeatureNote: return " "; //lab= " "; indent= fFeatIndent; break;  
			}
		return lab;
	}


	protected void writeDocItem( DocItem nv, boolean writeAll) 
	{
		switch (nv.getKind()) 
		{
			case kSeqkind: 
			case kSeqlen: 
			case kDivision: 
			case kDataclass:
			case kSeqcircle:
			case kStrand:
			case kDate:
			case kCrossRef:	 // not in GB
			case kRefSeqindex:
			case kNumA: 
			case kNumC: 
			case kNumG: 
			case kNumT: 
			case kNumN: 
			case kBioseqSet:
			case kBioseq:
			case kBioseqDoc:
				break; // doing elsewhere
				
			default:
				super.writeDocItem( nv, writeAll);
				break;
		}
	}
		
	private boolean putlinefield( StringBuffer sb, String val, int etab, int just)
	{
		int width= etab - fFieldIndent1 - sb.length();
		if (val==null) { sb.append( spaces( width) ); return false; }
		else { sb.append( Fmt.fmt( val, width, just) ); return true; }
	}
	
	protected String getFieldValue( DocItem di) //String val, int level, int kind, String name
	{ 
		switch ( di.getKind()) 
		{
			case kFeatureTable: 
				return "         Location/Qualifiers";

				// massage kName line
				//LOCUS       AF005656     1504 bp    DNA   circular  UNA       02-JAN-1999
				//LOCUS       TRN10A02      178 bp ss-RNA             UNA       04-OCT-1994
			  //............13........23......31.34.37....43........53........63.........75
			case kName: {
				StringBuffer sb= new StringBuffer();
				putlinefield( sb, di.getValue(), 23, Fmt.LJ); 
				putlinefield( sb, getDocField(kSeqlen), 30, 0);
				sb.append( " bp ");
				if (putlinefield( sb, getDocField(kStrand), 36, 0))
					sb.append('-'); else sb.append(' ');
				putlinefield( sb, getDocField(kSeqkind), 43, Fmt.LJ);
				putlinefield( sb, getDocField(kSeqcircle), 53, Fmt.LJ);
				putlinefield( sb, getDocField(kDivision), 63, Fmt.LJ);
				String dt= getDocField(kDate);
				// chop any frass
				if (dt!=null) {
					int sp= dt.indexOf(' '); // or trunc if dt.length()>11
					if (sp>0) dt= dt.substring(0,sp);
					}
				putlinefield( sb, dt, 75, Fmt.LJ); //+Fmt.TRUNC ?
				return sb.toString();  
				}

// need to fiddle with source/taxonomy fields also
//SOURCE      Acetobacter sp. (strain MB 58) rRNA.
//  ORGANISM  Acetobacter sp.
//            Prokaryotae; Gracilicutes; Scotobacteria; Aerobic rods and cocci;
//            Azotobacteraceae.


				//REFERENCE   1  (bases 1 to 118)
			case kReference: {
				StringBuffer sb= new StringBuffer(di.getValue());
				String rsi= getDocField(kRefSeqindex);
				if (rsi!=null) {
					sb.append("  (bases ");
					int mi= rsi.indexOf('-');
					if (mi>0 && mi < rsi.length()) {
						sb.append(rsi.substring(0,mi)); 
						sb.append(" to "); 
						sb.append(rsi.substring(mi+1));
						}
					else sb.append(rsi);
					sb.append(')');
					}
				return sb.toString();  
				}
				
				//BASE COUNT       27 a     40 c     32 g     17 t      2 others
			  //....................21.......30.......39.......48.......57.........
			case kSeqstats: {
				StringBuffer sb= new StringBuffer();
				putlinefield( sb, getDocField(kNumA), 20, 0); sb.append( " a");
				putlinefield( sb, getDocField(kNumC), 29, 0); sb.append( " c");
				putlinefield( sb, getDocField(kNumG), 38, 0); sb.append( " g");
				putlinefield( sb, getDocField(kNumT), 47, 0); sb.append( " t");
				if ( putlinefield( sb, getDocField(kNumN), 56, 0) ) sb.append(" others");
				return sb.toString();  
				}
				
			default: 
				return super.getFieldValue(di);  
		}
	}


	protected String getFieldLabel( int level, DocItem di) //int level, int kind, String name, boolean hasval
	{
		String name= null;
		indent= 0;
		subindent= 0;
		
		switch (level) {
		
					// need to know if kSubfield for "  " indent !! -- getFieldName() sets subindent
			default:
			case kSubfield  : 
			case kField     :  
				if (fFromForeignFormat) name= getFieldName( di.getKind());
				else name= di.getName();
				if ( name==null || name.length()==0 ) return null;
				indent= fFieldIndent;
				if (level == kSubfield) subindent= 2;  
				return Fmt.fmt( spaces(subindent) + name, indent, Fmt.LJ);
								
			case kContinue  : 
				indent= fFieldIndent;  //?? or fFeatIndent
				return spaces(indent);

			case kFeatField : 
				indent= fFeatIndent;
				return Fmt.fmt( spaces(5) + di.getName(), indent, Fmt.LJ);
				
			case kFeatCont  : 
				name= di.getName();
				if (di.hasValue()) name += "=";
				indent= fFeatIndent; 
				return spaces( indent) + name;

			case kFeatWrap  : 
				indent= fFeatIndent;
				return spaces( indent);
			}
	}

	protected void writeTextTop( FastVector v, boolean writeAll) 
	{
		gotOneFT= false;
		super.writeTextTop( v, writeAll);
	}



	
};


