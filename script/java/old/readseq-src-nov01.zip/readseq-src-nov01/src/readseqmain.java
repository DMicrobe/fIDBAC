/** 
	readseqmain.java
	-- IBM trick to put real main in package and wrapper main w/o package  
	@see iubio.readseq.run
*/

public class run  {	
	public static void main(String[] args) { new iubio.readseq.run(args); 	}
	}

/** @see iubio.readseq.help */
public class help {
	static public void main(String[] args)  { new iubio.readseq.help(args); }
	}

/**  @see iubio.readseq.app */
public class app  {	
	public static void main(String[] args) { new iubio.readseq.app(args); }
	}

/**  @see iubio.readseq.cgi */
public class cgi  {	
	public static void main(String[] args) { new iubio.readseq.cgi(args); }
	}


/**  @see iubio.readseq.test */
public class test  {	
	public static void main(String[] args) { iubio.readseq.test.main(args); }
	}



