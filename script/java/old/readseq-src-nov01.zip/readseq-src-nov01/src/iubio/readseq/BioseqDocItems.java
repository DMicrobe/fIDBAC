// BioseqDocItems.java
// sequence format information (document,features) handlers
// d.g.gilbert, 1997++


package iubio.readseq;


import java.io.*;
import java.util.*;

import flybase.*;
import iubio.bioseq.*;

public interface PrintableDocItem
{
	public void print( PrintWriter pr, BioseqDocImpl doc, String label, String value);
}

public class DocItem 
	implements Cloneable
{	
	//public static boolean bPreserveNewlines = true; // may01 test
	public static String sAppendBreak = "\n"; // may01 test - was " "
	
	public String name; 	// field name or key
	public String value;	// field value
	public int kind;			// field kind; a readseq constant where name changes per databank format
	public int level;			// level in document heirarchy: kField, kSubfield, kFeatField, kFeatCont of BioseqDocVals
		
	public DocItem() { this("", "", 0, 0); }
	public DocItem(DocItem p) { this(p.getName(), p.getValue(), p.getKind(), p.getLevel()); }
	public DocItem(String name, String value, int kind, int level) {
		this.kind= kind;
		this.level = level;
		this.name= name; 		//? ever null
		setValue(value); 		//this.value= value;	//? ever null
    }
    
	public final int getLevel() { return level; }
	public final void setLevel(int level) { this.level= level; }

	public final String getName() { return name; }
	public final int getKind() { return kind; }

	public final boolean hasValue() { return (value!=null && value.length()>0); }
	public String getValue() { return value; }
	public void setValue(String other) { this.value= (other==null ? "" : other); }

	public void appendValue(String appendval) { // can be called a lot w/ long docs
		appendValue( sAppendBreak, appendval);
		//if (appendval!=null) setValue( value + " " + appendval); //? space
		}
		
	static protected StringBuffer apbuf= new StringBuffer(); 
		// for efficiency, skip so many s + s -- static ? need to be thread-safe

	public void appendValue(String joinval, String appendval) { 
		if (appendval!=null) { 
			//if (apbuf==null) apbuf= new StringBuffer(value); else 
			{ apbuf.setLength(0); apbuf.append(value); }
			apbuf.append(joinval); 
			apbuf.append(appendval);
			setValue( apbuf.toString() );  
			}
		}

	public final boolean sameLevel(DocItem other) { return level == other.getLevel(); }
	public final boolean sameName(String other)  { return name.equals(other); }
	public final boolean sameName(DocItem other) { return name.equals(other.name); }
	public final boolean sameKind(int otherkind) { return kind == otherkind; }
	public final boolean sameKind(DocItem other) { return kind == other.kind; }
	public final boolean sameValue(String other)  { return value.equals(other); }

	public String toString() {
		StringBuffer sb= new StringBuffer();
		if (Debug.isOn) { sb.append( this.getClass().getName()); sb.append(": "); }
		sb.append( name); sb.append("="); sb.append( value);
		if (Debug.isOn) {
			sb.append(" [k="); sb.append( kind);
			sb.append(", l="); sb.append( level); sb.append("]");
			}
		return sb.toString();
		}
		
	public boolean equals(Object other) {
		if (other instanceof DocItem) {
			DocItem odoc= (DocItem) other;
			if (!sameKind(odoc.kind)) return false;
			if (!sameName(odoc.name)) return false;
			if (!sameValue(odoc.value)) return false;
			//return ( sameKind((DocItem)other) && super.equals((DocItem) other) );
			return true;
			}
		else return false;
		}

	public boolean sameNameOrKind(Object other) {
		if (other instanceof DocItem) 
			return ( sameKind((DocItem)other) && sameName((DocItem) other) );
		else if (other instanceof Integer) return sameKind(((Integer)other).intValue() );
		else if (other instanceof String) return sameName((String) other);
		else return false;
		}
	
	public Object clone() {
		try {
			DocItem c= (DocItem) super.clone();
	    return c;
			}
		catch(CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		}
};


	/** trivial subclass to identify feature notes */
public class FeatureNote extends DocItem
{
	public FeatureNote() { super(); }
	public FeatureNote(DocItem p) { 
		super(p); 
		this.kind= BioseqDocVals.kFeatureNote; 
		this.level= BioseqDocVals.kFeatCont; 
		}
	public FeatureNote(String name, String value) {
		this(name,value,BioseqDocVals.kFeatureNote,BioseqDocVals.kFeatCont);
    }
	public FeatureNote(String name, String value, int kind, int level) {
		//? force name to start with '/' ???
		super(name,value,kind,level);
    }

	/*
	public String toString() {
		StringBuffer sb= new StringBuffer();
		if (Debug.isOn) { sb.append( this.getClass().getName()); sb.append(": "); }
		sb.append( name); sb.append("="); sb.append( value);
		return sb.toString();
		}
	*/
}

public class FeatureItem  extends DocItem
{
	//public static Font defont= new Font("SansSerif", 0, 9);
	protected SeqRange location;  
	protected FastVector notes; // of FeatureNote, "/name=value"
	protected DocItem curnote;
	    
	public FeatureItem(String name, SeqRange value ) {
		super(name, value.toString(), BioseqDoc.kFeatureItem,  BioseqDoc.kFeatField);
		location= value;
    }
	public FeatureItem(String name, SeqRange value, int level) {
		super(name, value.toString(), BioseqDoc.kFeatureItem, level);
		location= value;
    }
    
	public FeatureItem(String name, String value, int level) {
		super(name, value, BioseqDoc.kFeatureItem, level);
		setValue(value);  
    }

	public FeatureItem( ) {
		super("", "", BioseqDoc.kFeatureItem, BioseqDoc.kFeatField);
  	}
  	
	public void set(String name, SeqRange value) {
		this.name= name;
		setValue(value.toString()); //? ever null
    }

	public Object clone() { 
 		FeatureItem fi= (FeatureItem) super.clone();  
 		if (notes!=null) fi.notes= (FastVector) notes.clone(); // doesn't clone contents !
 		//fi.notes.cloneItems();
 		if (location!=null) fi.location= (SeqRange) location.clone();
 		fi.curnote= null; //?
 		//? featkind?
 		return fi;
		}


	public boolean equals(Object ob) {
		if (ob instanceof FeatureItem) {
			FeatureItem fi= (FeatureItem) ob;
			return (getName().equals(fi.getName()) && location.equals(fi.getLocation()));
			}
		return false;
		}
		
			// override
	public String getValue() { return getLocationString(); } 

	public void setValue(String newval) {
		super.setValue(newval);
		try { location= SeqRange.parse(value); }
		catch (SeqRangeException sre) { System.err.println(sre.getMessage()); } // (sre)
		}

	public void appendValue(String appendval) {
		super.appendValue( "", appendval);
		//if (appendval!=null) setValue( this.value + appendval); //? no space
		}
		
	public SeqRange getLocation() { return location; }
	public String getLocationString() {  return location.toString(); }
	
	public void updateRange(int changeflags, int start, int length, byte[] changes) {
 		//public final static int kDelete = 1, kInsert = 2, kReorder = 4, kChange = 8;
 		location.updateRange(changeflags, start, length, changes);
		}

	public FastVector getNotes() { return notes; }
		
	public String getNotesText() { 
		StringBuffer sb= new StringBuffer();
		//if (Debug.isOn) { sb.append( this.getClass().getName()); sb.append(": "); }
		sb.append( getName()); sb.append("="); sb.append( getLocationString());
		sb.append('\n'); //?
		if (notes!=null) for (int i=0; i<notes.size(); i++) {
			DocItem di= (DocItem) notes.elementAt(i);
			sb.append(di.getName());
			sb.append('=');
			sb.append(di.getValue());
			sb.append('\n');
			}
		return sb.toString();
		}
		
		//? need getNotesText opposite setNotesText()
	public void setNotesText(String notetext, boolean append) 
	{
		if (!append && notes!=null) notes.removeAllElements();
		StringTokenizer st= new StringTokenizer(notetext,"\n\r");
		while (st.hasMoreTokens()) { 
			String kv= st.nextToken();
			int eq= kv.indexOf('=');
			if (eq>0) {
				String key= kv.substring(0,eq).trim();
				String val= kv.substring(eq+1).trim();
				if ("name".equals(key)) {
					name= val; //? allow name change?
					}
				else if ("location".equals(key)) {
					setValue(val);
					}
				else {
					if (!key.startsWith("/")) key= "/" + key;
					putNote( new FeatureNote( key, val)); 
					}
				}
			}
	}
	 
		
	public void putNote(DocItem note) { 
		if (notes==null) notes= new FastVector();
		notes.addElement(note); 
		curnote= note;
		}
		
	public void appendNote(String value) { 
		if (curnote!=null && value!=null) {
			if ("/translation".equals(curnote.getName())) 
				curnote.appendValue( "", value.trim()); // special hack - keep spaces out of this
			else
				curnote.appendValue( curnote.sAppendBreak, value); 
		//	String curval= curnote.getValue();
		//	if (!"/translation".equals(curnote.getName())) curval += " "; // special hack - keep spaces out of this
		//	curnote.setValue( curval + value); //? space
			}
		}
		
  public DocItem getNote(String name) {
  	if (notes==null) return null;
		String n2= (name.startsWith("/")) ? null : "/" + name;
  	for (int i=0; i<notes.size(); i++) {
  		DocItem nv= (DocItem) notes.elementAt(i);
   		if (nv.sameName(name) ) return nv;
 			else if (n2!=null && nv.sameName(n2) ) return nv;
  		}
  	return null;
  	}
  	
  public String getNoteValue(String name) {
  	DocItem di= getNote(name);
  	if (di!=null) return di.getValue(); else return null;
  	}
  	
	public String toString() {
		StringBuffer sb= new StringBuffer();
		if (Debug.isOn) { sb.append( this.getClass().getName()); sb.append(": "); }
		sb.append( name); sb.append("="); sb.append( value);
		if (notes!=null) for (int i=0; i<notes.size(); i++) {
			sb.append('\n'); sb.append( notes.elementAt(i));
			}
		return sb.toString();
		}


};




