// iubio.bioseq.SeqRangeException.java
// sequence location parsing
// d.g.gilbert, 1997++


package iubio.bioseq;


public class SeqRangeException extends Exception
{
	public SeqRangeException() { super(); }
	public SeqRangeException(String err) { super(err); }
}
