// BioseqDocItems.java
// sequence format information (document,features) handlers
// d.g.gilbert, 1997++


package iubio.readseq;


import java.io.*;
import java.util.*;

import flybase.*;
import iubio.bioseq.*;



public class DocItem 
	implements Cloneable
{	
	public String name; 	// field name or key
	public String value;	// field value
	public int kind;			// field kind; a readseq constant where name changes per databank format
	public int level;			// level in document heirarchy: kField, kSubfield, kFeatField, kFeatCont of BioseqDocVals
	
	public DocItem() { this("", "", 0, 0); }
	public DocItem(DocItem p) { this(p.getName(), p.getValue(), p.getKind(), p.getLevel()); }
	public DocItem(String name, String value, int kind, int level) {
		this.kind= kind;
		this.level = level;
		this.name= name; 		//? ever null
		setValue(value); 		//this.value= value;	//? ever null
    }
    
	public final int getLevel() { return level; }
	public final void setLevel(int level) { this.level= level; }

	public final String getName() { return name; }
	public final int getKind() { return kind; }

	public final boolean hasValue() { return (value!=null && value.length()>0); }
	public String getValue() { return value; }
	public void setValue(String other) { this.value= (other==null ? "" : other); }

	public void appendValue(String appendval) { 
		if (appendval!=null) setValue( value + " " + appendval); //? space
		}
		

	public final boolean sameLevel(DocItem other) { return level == other.getLevel(); }
	public final boolean sameName(String other)  { return name.equals(other); }
	public final boolean sameName(DocItem other) { return name.equals(other.name); }
	public final boolean sameKind(int otherkind) { return kind == otherkind; }
	public final boolean sameKind(DocItem other) { return kind == other.kind; }
	public final boolean sameValue(String other)  { return value.equals(other); }

	public String toString() {
		StringBuffer sb= new StringBuffer( this.getClass().getName());
		sb.append(": name="); sb.append( name);
		sb.append(", value="); sb.append(value);
		sb.append(", kind="); sb.append(kind);
		sb.append(", level="); sb.append(level);
		return sb.toString();
		}
		
	public boolean equals(Object other) {
		if (other instanceof DocItem) {
			DocItem odoc= (DocItem) other;
			if (!sameKind(odoc.kind)) return false;
			if (!sameName(odoc.name)) return false;
			if (!sameValue(odoc.value)) return false;
			//return ( sameKind((DocItem)other) && super.equals((DocItem) other) );
			return true;
			}
		else return false;
		}

	public boolean sameNameOrKind(Object other) {
		if (other instanceof DocItem) 
			return ( sameKind((DocItem)other) && sameName((DocItem) other) );
		else if (other instanceof Integer) return sameKind(((Integer)other).intValue() );
		else if (other instanceof String) return sameName((String) other);
		else return false;
		}
	
	public Object clone() {
		try {
			DocItem c= (DocItem) super.clone();
	    return c;
			}
		catch(CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		}
};


	/** trivial subclass to identify feature notes */
public class FeatureNote extends DocItem
{
	public FeatureNote() { super(); }
	public FeatureNote(DocItem p) { super(p); }
	public FeatureNote(String name, String value, int kind, int level) {
		super(name,value,kind,level);
    }
	public String toString() {
		StringBuffer sb= new StringBuffer( this.getClass().getName());
		sb.append(": name="); sb.append( name);
		sb.append(", value="); sb.append(value);
		return sb.toString();
		}
}

public class FeatureItem  extends DocItem
{
	//public static Font defont= new Font("SansSerif", 0, 9);
	protected SeqRange location;  
	protected FastVector notes; // of FeatureNote, "/name=value"
	protected DocItem curnote;
	
	
	public FeatureItem(String name, String value, int level) {
		super(name, value, BioseqDoc.kFeatureItem, level);
		setValue(value);  
    }

	public FeatureItem(String name, SeqRange value, int level) {
		super(name, value.toString(), BioseqDoc.kFeatureItem, level);
		location= value;
    }
    
	public Object clone() { 
 		FeatureItem fi= (FeatureItem) super.clone();  
 		if (notes!=null) fi.notes= (FastVector) notes.clone(); // doesn't clone contents !
 		//fi.notes.cloneItems();
 		if (location!=null) fi.location= (SeqRange) location.clone();
 		fi.curnote= null; //?
 		//? featkind?
 		return fi;
		}

	public boolean equals(Object ob) {
		if (ob instanceof FeatureItem) {
			FeatureItem fi= (FeatureItem) ob;
			return (getName().equals(fi.getName()) && location.equals(fi.getLocation()));
			}
		return false;
		}
		
			// override
	public String getValue() { return getLocationString(); } 

	public void setValue(String newval) {
		super.setValue(newval);
		try { location= SeqRange.parse(value); }
		catch (SeqRangeException sre) { System.err.println(sre.getMessage()); } // (sre)
		}

	public void appendValue(String appendval) {
		setValue( this.value + appendval);
		}
		
	public SeqRange getLocation() { return location; }
	public String getLocationString() {  return location.toString(); }
	
	public void updateRange(int changeflags, int start, int length, byte[] changes) {
 		//public final static int kDelete = 1, kInsert = 2, kReorder = 4, kChange = 8;
 		location.updateRange(changeflags, start, length, changes);
		}

	public FastVector getNotes() { return notes; }
		
	public void putNote(DocItem note) { 
		if (notes==null) notes= new FastVector();
		notes.addElement(note); 
		curnote= note;
		}
		
	public void appendNote(String value) { 
		if (curnote!=null && value!=null) {
			String curval= curnote.getValue();
			curnote.setValue( curval + " " + value); //? space
			}
		}
		
  public DocItem getNote(String name) {
  	if (notes==null) return null;
  	for (int i=0; i<notes.size(); i++) {
  		DocItem nv= (DocItem) notes.elementAt(i);
  		if ( nv.sameName(name) ) return nv;
  		}
  	return null;
  	}
  	
	public String toString() {
		StringBuffer sb= new StringBuffer( this.getClass().getName());
		sb.append(": name="); sb.append( name);
		sb.append(", location="); sb.append( location);
		if (notes!=null) for (int i=0; i<notes.size(); i++) {
			sb.append('\n'); sb.append( notes.elementAt(i));
			}
		return sb.toString();
		}

	/*
		//
		//? needed only for DrawableFeatureItem ?
		//
		
	protected FeatureKind featkind;

	public void setFeatureKind(FeatureKind fk) { this.featkind= fk; }
	public FeatureKind getFeatureKind() { return this.featkind; }

	public boolean getVisible() {
		if (featkind!=null)  return featkind.visible(); elsereturn false;
		}	
		
	public void setVisible(boolean turnon) {
		if (featkind!=null) featkind.setVisible(turnon);
		}	
		
	public int getHeight() {
		if (featkind!=null) return featkind.height(); else return 5;
		}	
		
	public int getYtop() {
		if (featkind!=null) return featkind.ytop(); else return 0;
		}	
		
	public int getFlavor() { 
		if (featkind!=null) return featkind.kind(); else return 0;
		}
				
	
		// need a Graphics subclass for this
		
	public void draw( Graphics gr, Rectangle r, int cwidth, SeqRange visr)
	{
		if (!getVisible()) return;
		int y= 1 + getYtop(); 
		SeqRange loc= getLocation();
		do {
			draw( gr, r, y, cwidth, loc, visr);
			loc= loc.next;
		} while (loc!=null);
	}
	
	public void draw(Graphics gr, Rectangle r, int row, int cwidth, SeqRange seqr, SeqRange visr)
	{
		int startcol= visr.start(); // == GetLeft
		int stopcol= visr.stop();
		int seqstart= seqr.start();
		int seqstop= seqr.stop();

		if (seqstart <= stopcol && seqstop >= startcol) {
			int xoff= cwidth * Math.max( 0, seqstart - startcol);
			int x= r.x + xoff;
			int y= r.y + row;

			int len= Math.max(1,Math.min( visr.nbases(), 
							seqr.nbases() - Math.max(0,startcol - seqstart)));
			int wid= Math.min( r.width - xoff, cwidth * len);
			int midx= Math.max(x, (x + wid) / 2);
			
			Color colr= (featkind==null) ? Color.blue : featkind.color();
			gr.setColor(colr);
			gr.fillRect( x, y, wid, 5);
			gr.setColor(Color.black);
			Font savef= gr.getFont();
			Font font= (featkind==null) ? defont : featkind.font();
			gr.setFont(font);
			gr.drawString( getName(), midx, y + 5);
			gr.setFont( savef);
			}
	}
	*/

};


/***
	//
	// ? need only for DrawableFeatureItem/Doc ?
	//
public class FeatureKind 
{
	static int atkind;
	static int atheight;
	static int colors[] = { 0xF080F0, 0xF0F080, 0x80F0F0, 0x80A0F0, 0xA080F0, 0xF080A0,
			0xA0A0F0, 0xF0A0A0, 0xA0F0A0, 0xA0A080, 0x8080F0, 0xF08080, 0xA0E0C0, 0xC0C0F0,
			0xD0D080, 0xD0C0A0 };

	String name;
	//Color color;
	//Font font;
	boolean visible;
	int	kind, height, ytop;
	FeatureKind tpl;
	//DSeqStyle style;
	
	// look in DSeqStyle st= DStyleTable.getStyleFromName(name) 
	// for framecolor, backcolor, visible, font?, other draw styles 
	
	public FeatureKind(String name) 
	{
		this.name= goodName(name);
		kind= name.hashCode(); //++atkind;
		//style= DStyleTable.getStyleFromName(name); // may be null
		//if (style!=null) color= style.framecolor;
		//else color= new Color( colors[ Math.abs(kind % colors.length) ]);
		//font= new Font("SansSerif", 0, 9);
		//if (style!=null) visible= style.visible;
		//else visible= (!name.equals("source"));  //?
		height= 9; //??!
		ytop= atheight;
		atheight += height;
		//tpl= this;
	}

	public static String goodName(String name) {
		name= name.toLowerCase(); //?
		int at= name.indexOf('.'); // disallow for prefs
		if (at>=0) name= name.replace('.','_');
		return name;
		}
			
	public void setTemplate(FeatureKind tpl) {
		visible= tpl.visible();
		this.tpl= tpl;
		//font= tpl.font();
		//color= tpl.color();
		//height=
		}
		
	public static void reset() { atkind= 0; atheight= 0; }
	public int ytop() { return ytop; }
	public int height() { return height; } //(visible ? height : 0); 
	public int kind() { return kind; }
	public String name() { return name; }
	public String getName() { return name; }
	//public Font font() { return font; }
	//public Color color() { 
	//	if (style!=null) return style.framecolor; else return color; 
	//	}
	//public DSeqStyle style() { return style; }

	public boolean visible() { 
		if (tpl!=null && !tpl.visible()) return false; else 
		return visible; 
		}
	public void	setVisible(boolean turnon) { 
		//if (tpl!=null && !tpl.visible()) visible= false; else 
		visible= turnon; 
		}
		
		
	public static FeatureKind fromString(String s) {
		int at= s.indexOf('=');
		String name= (at<0) ? s : s.substring(0,at);
		FeatureKind fk= new FeatureKind(name);
		
		at= s.indexOf("visible=");
		fk.visible= (at<0 || s.substring(at+8).startsWith("true"));
		at= s.indexOf("ytop=");
		if (at>=0) {
			int e= s.indexOf(',',at+5);
			if (e<0) e= s.indexOf(']',at+5);
			String sn= s.substring(at+5,e);
			try { fk.ytop= Integer.parseInt(sn); } catch (Exception ex) {}
			}
		return fk;
		}
		
	public String toString() {
		StringBuffer sb= new StringBuffer(name);
		sb.append("=[");
		sb.append("visible="); sb.append(visible);
		sb.append(",ytop="); sb.append(ytop);
		//sb.append("height="); sb.append(height);
		//sb.append("font="); sb.append(font.toString()); // don't care yet about color, font, height...
		//sb.append("color="); sb.append(color.toString()); // don't care yet about color, font, height...
		sb.append("]");
		return sb.toString();
		}
		
}

***/

