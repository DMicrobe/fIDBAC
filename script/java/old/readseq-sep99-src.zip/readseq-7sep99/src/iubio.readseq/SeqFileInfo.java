// SeqFileInfo.java
// d.g.gilbert 

package iubio.readseq;

import java.io.*;
import iubio.bioseq.*;
		 

/**
	* a lightweight class to pass seq and file info 
	* between reader/writer and others
	*/
	
public class SeqFileInfo
	implements Cloneable
{
	public static String gBlankSeqid = "nameless";
	public static String gMaskName = "#Mask";  
	public static boolean gWriteMask= true;

		// for file 
	public int format, skiplines, err;
	public int atseq, nseq;
	public long	modtime;
		// for current seq
	public int seqlen, offset;
	public boolean ismask= false, hasmask= false;

	public Object seq; // Bioseq -  ?don't want to be tied here to specific structure
	public Object seqdoc; 
	public String seqid = gBlankSeqid;
	
	public SeqFileInfo() {}

	public SeqFileInfo( Object seq, int offset, int seqlen) { // Bioseq seq
		this.seq= seq;
		this.offset= offset;
		this.seqlen= seqlen;
		}

	public String toString() {
		StringBuffer sb= new StringBuffer( this.getClass().getName());
		sb.append(": id="); sb.append( seqid);
		sb.append(", length="); sb.append(seqlen);
		sb.append(", hasdoc="); sb.append(hasdoc());
		return sb.toString();
		}
		
	public final boolean hasseq() { return (seq!=null && seqlen>0); }
	public final boolean hasdoc() { return (seqdoc!=null); }
	public final boolean hasid() { return (seqid!=null && seqid.length()>0 && (seqid != gBlankSeqid) ); }
	public final boolean hasmask() { return (ismask || hasmask); }
	
	public void checkSeqID() {
 		this.ismask= false;
 		String sid= this.seqid;
 		if (sid!=null && sid.length() > 0) {
  		int at= sid.indexOf(gMaskName);
  		if (at>0) {
       	this.ismask= true;  
       	sid= sid.substring(0,at);
 				}
   		this.seqid= cleanSeqID(sid);
   		}
		}

	public static String cleanSeqID( String s) { 
		int i;
		s= s.trim();
		if ((i= s.indexOf(' ')) > 0) s= s.substring(0,i);
		if ((i= s.indexOf(',')) > 0) s= s.substring(0,i);
		return s;
  	}

	public void copyto(SeqFileInfo si) {
		si.format= format;
		si.skiplines= skiplines;
		si.err= err;
		si.atseq= atseq;
		si.nseq= nseq;
		si.modtime= modtime;
		si.seqlen= seqlen;
		si.offset= offset;
		si.ismask= ismask;
		si.hasmask= hasmask;
		si.seq= seq;
		si.seqdoc= seqdoc;
		si.seqid= seqid;
		}

	public Object clone() {
		try {
			SeqFileInfo si= (SeqFileInfo) super.clone();
			// reset the per-sequence fields
			si.seqid=  gBlankSeqid;
			si.ismask= si.hasmask= false;
			si.seqlen= 0;
			si.offset= 0;
			si.seq= null;
			si.seqdoc= null;
			si.modtime= 0;
	    return si;
			}
		catch (CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		} 
}



