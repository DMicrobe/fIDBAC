// seqread1.java
// low level readers & writers : sequential formats
// d.g.gilbert, 1990-1999

package iubio.readseqC;

import java.io.*;
import java.util.Date;

import flybase.OpenString;

import Acme.Fmt;
		 
import iubio.readseq.Biobase;
import iubio.readseq.Bioseq;
import iubio.readseq.BaseKind;

import iubio.readseq.BioseqDoc;
import iubio.readseq.GenbankDoc;
import iubio.readseq.EmblDoc;
	
	
//========= sequential BioseqReader subclasses ==========

public class PlainSeqFormat extends BioseqFormat
{
	public String formatName() { return "Plain|Raw"; }  
	public String formatSuffix() { return ".seq"; } 
	public String contentType() { return "biosequence/plain"; } 
	public BioseqReaderIface newReader() { return new PlainSeqReader(); }
	public BioseqWriterIface newWriter() { return new PlainSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }
}

public class PlainSeqReader  extends BioseqReader
{
	// very simple format -- blank line b/n sequences, no seqid

	public PlainSeqReader() {
		margin	=  0;
		addfirst= true;
		addend 	= true;  
		ungetend= false;
		//formatId= 13;
		}
	
	public boolean endOfSequence() {
	  return (nWaiting == 0 || getreadbuf(0) == '\n');
		}
}

public class PlainSeqWriter  extends BioseqWriter
{
	//protected void writeRecordEnd() { writeln(); } // newLine();
};



public class IgSeqFormat extends BioseqFormat
{
	public String formatName() { return "IG|Stanford"; }  
	public String formatSuffix() { return ".ig"; } 
	public String contentType() { return "biosequence/ig"; } 
	public BioseqReaderIface newReader() { return new IgSeqReader(); }
	public BioseqWriterIface newWriter() { return new IgSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.charAt(0) == ';') {
      formatLikelihood= 55;
      if (recordStartline==0) recordStartline= atline;
      return false; //!
      }
    else
    	return false;
	}

}

public class IgSeqReader  extends BioseqReader
{
	public IgSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= true;  
		ungetend= false;
		//formatId= 1;
		}

	public boolean endOfSequence() {
	  return ( indexOfBuf('1')>=0 || indexOfBuf('2')>=0);
		}

	protected void read() throws IOException
	{
	  while (!allDone) {
	    do {
	      getline();
	      sWaiting= sWaiting.trim(); 
	      nWaiting= sWaiting.length();
	    } while (!(endOfFile() || (nWaiting>0 && sWaiting.charAt(0) != ';' ) ));
	    
	    if (!endOfFile()) {
	      seqid= sWaiting.toString();
	      readLoop();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}
};

public class IgSeqWriter  extends BioseqWriter
{
	public void writeSeqEnd() { writeString("1"); }
	
	public void writeDoc()
	{
		//writeln( ";" + seqid + "  " + seqlen + " bases  " + checksumString());
		writeString( ";");
		writeString( seqid);
		writeString("  ");
		writeString( String.valueOf( seqlen));
		writeString(  " bases  ");
		writeln( checksumString());
		writeln( idword);
  	//linesout += 2;
	}
   
};




public class PearsonSeqFormat extends BioseqFormat
{
	public String formatName() { return "Pearson|Fasta"; }  
	public String formatSuffix() { return ".fasta"; } 
	public String contentType() { return "biosequence/fasta"; } 
	public BioseqReaderIface newReader() { return new PearsonSeqReader(); }
	public BioseqWriterIface newWriter() { return new PearsonSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.charAt(0) == '>') {
      formatLikelihood = 55;
      if (recordStartline==0) recordStartline= atline;
      return false; //!
      }
    else
    	return false;
	}

}

public class PearsonSeqReader  extends BioseqReader
{
	public PearsonSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 8;
		}

	public boolean endOfSequence() {
	  return (nWaiting > 0 && getreadbuf(0) == '>');
		}

	protected void read() throws IOException
	{
	  while (!allDone) {
	    if (nWaiting > 0) seqid= sWaiting.substring(1).toString();
	    readLoop();
	    if (!allDone) {
	    	while (!(endOfFile() || (nWaiting > 0 && getreadbuf(0) == '>') ))
	        getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}
};


public class PearsonSeqWriter  extends BioseqWriter
{
	final static int seqwidth= 60; // up from default 50, jul'99
	
	public void writeRecordStart() {
		super.writeRecordStart();
   	opts.seqwidth = seqwidth; 
		}

	public void writeRecordEnd() { } // no extra newline!

	public void writeSeq() {  
		// writeLoop();
		//  ^^ ? replace w/ simpler one for this format? just dump seq, 60/line
		int i;
		boolean newline= true;
		for (i= 0; i < seqlen; i++) {
	   	//char bc= (char) testbase.outSeqChar( bioseq.base(offset+i,fBasePart));
	   	char bc= bioseq.base(offset+i,fBasePart);
			writeByte( bc); newline= false;
			if (i % seqwidth == seqwidth-1) { 
				writeln(); newline= true; 
				}
			}
		if (!newline) writeln();
	}
		
	public void writeDoc() {
   	writeString(">");
   	writeString(seqid);
   	writeString("  ");
   	writeString( String.valueOf(seqlen));
   	writeString(" bp ");
   	// add some other doc here if available - EMBL/GB def line
   	writeln(checksumString());
		//linesout += 1;
		}
};



public class GenbankSeqFormat extends BioseqFormat
{
	public String formatName() { return "GenBank|GB"; }  
	public String formatSuffix() { return ".gb"; } 
	public String contentType() { return "biosequence/genbank"; } 
	public BioseqReaderIface newReader() { return new GenbankSeqReader(); }
	public BioseqWriterIface newWriter() { return new GenbankSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.startsWith(GenbankSeqReader.kLocus)) {
      formatLikelihood= 80;
      if (recordStartline==0) recordStartline= atline;
    	return false;
      }
    else if (line.startsWith(GenbankSeqReader.kOrigin)) {
      formatLikelihood += 70;
      return false;
      }
    else if (line.startsWith("//")) {
      formatLikelihood += 20;
      return false;
      }
    else
    	return false;
	}
}

public class GenbankSeqReader  extends BioseqReader
{
	final static String kLocus  = "LOCUS ";
	final static String kOrigin = "ORIGIN";
	GenbankDoc doc;
	
	public GenbankSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 2;
		}

	//public BioseqDoc getInfo() { return doc; }

	public boolean endOfSequence() {
		ungetend= (indexOfBuf(kLocus) == 0);
	  return (ungetend || indexOfBuf("//") >= 0);
		}

	
	protected void read() throws IOException
	{  
		doc= new GenbankDoc();
		seqdoc= doc;
	  while (!allDone) {
	  	doc.addDocLine( sWaiting.toString());
	    if (nWaiting > 12) seqid= sWaiting.substring(12).toString();
	    while (!(endOfFile() || sWaiting.startsWith(kOrigin))) {
	  		doc.addDocLine( getline());
	   		}
	    readLoop();
			if (!allDone) {
	    	while (!(endOfFile() || (nWaiting > 0 && indexOfBuf(kLocus) == 0)))
	        getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}

};

public class GenbankSeqWriter  extends BioseqWriter
{

	public void writeRecordStart()
	{
		super.writeRecordStart();
    opts.spacer = 11;
    opts.numleft = true;
    opts.numwidth = 8;  // dgg. 1Feb93, patch for GDE fail to read short numwidth 
	}
	
	public void writeRecordEnd() { writeln("//"); }
		
	public void writeDoc()
	{
	//	writeln( "LOCUS       " + idword + "       " + seqlen + " bp");
		writeString("LOCUS       ");
		writeString(idword);
		writeString("       ");
   	writeString( String.valueOf(seqlen));
		writeln(" bp");
    //linesout += 1;

		if (seqdoc!=null && seqdoc instanceof BioseqDoc) {
			linesout += new GenbankDoc((BioseqDoc)seqdoc).writeTo(douts);
			}
		else {
			//writeln( "DEFINITION  "+ seqid + "  " + seqlen + " bases  " + checksumString());
			writeString("DEFINITION  ");
			writeString( seqid);
   		writeString( String.valueOf(seqlen));
			writeString(" bases  ");
   		writeln(checksumString());
	    //linesout += 1;
			}
		writeln( "ORIGIN      ");
    //linesout += 1;
 	}
 	
};



public class PirSeqFormat extends BioseqFormat
{
	public String formatName() { return "PIR|CODATA"; }  
	public String formatSuffix() { return ".pir"; } 
	public String contentType() { return "biosequence/codata"; } 
	public BioseqReaderIface newReader() { return new PirSeqReader(); }
	public BioseqWriterIface newWriter() { return new PirSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }
	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.startsWith(PirSeqReader.kEntry)) {
      formatLikelihood += 80;
      if (recordStartline==0) recordStartline= atline;
      return false;
      }
    else if (line.startsWith(PirSeqReader.kSequence)) {
      formatLikelihood += 70;
      return false;
      }
    else if (line.startsWith("///")) {
      formatLikelihood += 20;
      return false;
      }
    else
    	return false;
	}
}

public class PirSeqReader  extends BioseqReader
{
	final static String kEntry = "ENTRY ";
	final static String kSequence = "SEQUENCE";
	
	public PirSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 14;
		}


	public boolean endOfSequence() {
		ungetend= (indexOfBuf(kEntry) == 0);
	  return (ungetend || indexOfBuf("///") >= 0);
		}

	protected void read() throws IOException
	{  
	  while (!allDone) {
	    while (!(endOfFile() || sWaiting.startsWith(kSequence) 
	    	|| sWaiting.startsWith(kEntry)
	    	)) getline();
	    if (nWaiting > 16) seqid= sWaiting.substring(16).toString();
	    while (!(endOfFile() || sWaiting.startsWith(kSequence)))
	    	getline();
	    readLoop();
			if (!allDone) {
	    	while (!(endOfFile() || (nWaiting > 0 && indexOfBuf(kEntry) == 0)))
	        getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}

	
};


public class PirSeqWriter  extends BioseqWriter
{

	public void writeRecordStart()
	{
		super.writeRecordStart();
    opts.numwidth = 7;
    opts.seqwidth= 30;
    opts.spacer = kSpaceAll;
    opts.numleft = true;
	}
			
	public void writeHeader() throws IOException { 
		super.writeHeader();
		writeln( "\\\\\\"); 
		}

	public void writeRecordEnd() { writeln("///"); }
	
	public void writeDoc()
	{
   	// somewhat like genbank...  
		writeString("ENTRY           ");
		writeString(idword);
		writeln(" ");

		writeString("TITLE           ");
		writeString(seqid);
		writeString(" ");
   	writeString( String.valueOf(seqlen));
		writeString(" bases  ");
  	writeln(checksumString());
		
		writeln( "SEQUENCE        ");
    //run a top number line for PIR 
    int j;
    for (j=0; j<opts.numwidth; j++) writeByte(' ');
    for (j=5; j<=opts.seqwidth; j += 5) writeString( Fmt.fmt( j, 10));
    writeln();  
    //linesout += 5;
	}
	
	
};



public class NbrfSeqFormat extends BioseqFormat
{
	public String formatName() { return "NBRF"; }  
	public String formatSuffix() { return ".nbrf"; } 
	public String contentType() { return "biosequence/nbrf"; } 
	public BioseqReaderIface newReader() { return new NbrfSeqReader(); }
	public BioseqWriterIface newWriter() { return new NbrfSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.charAt(0) == '>' && line.charAt(3) == ';') {
      formatLikelihood += 70; //?
      if (recordStartline==0) recordStartline= atline;
      return false; //?
      }
    else
    	return false;
	}

}


public class NbrfSeqReader  extends BioseqReader
{
	public NbrfSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 3;
		}
		
	public boolean endOfSequence()
	{
		int starat= indexOfBuf('*');
	  if (starat >= 0) { /* end of 1st seqq */
	    /* "*" can be valid base symbol, drop it here */
	    sWaiting= bufSubstring(0,starat); //?? don't need unless needString set
	    nWaiting= starat;
	   	addend  = true;
	   	ungetend= false;
	    return(true);
	    }
	  else if (getreadbuf(0) == '>') { /* start of next seqq */
	    addend  = false;
	    ungetend= true;
	    return(true);
	    }
	  else
	    return(false);
	}
	  

	protected void read() throws IOException
	{
	  while (!allDone) {
	    if (nWaiting > 4) seqid= sWaiting.substring(4).toString();
	    getline();   /*skip title-junk line*/
	    readLoop();
	    if (!allDone) {
	     	while (!(endOfFile() || (nWaiting > 0 && getreadbuf(0) == '>')))
	   			getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}
};


public class NbrfSeqWriter  extends BioseqWriter
{

	public void writeRecordStart()
	{
		super.writeRecordStart();
    opts.spacer = 11;
	}
		
	public void writeSeqEnd() { writeString("*");  }
	
	public void writeDoc()
	{
    String tag;
    if (bioseq.getSeqtype() == Bioseq.kAmino)  tag= ">P1;"; else tag= ">DL;";
		writeln( tag + idword);
		writeln( seqid + "  " + seqlen + " bases  " + checksumString());
    //linesout += 3;
   }
   
};



public class EmblSeqFormat extends BioseqFormat
{
	public String formatName() { return "EMBL"; }  
	public String formatSuffix() { return ".embl"; } 
	public String contentType() { return "biosequence/embl"; } 
	public BioseqReaderIface newReader() { return new EmblSeqReader(); }
	public BioseqWriterIface newWriter() { return new EmblSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }
	
	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.startsWith(EmblSeqReader.kID)) {
      formatLikelihood += 80;
      if (recordStartline==0) recordStartline= atline;
      return false; //!?
      }
    else if (line.startsWith(EmblSeqReader.kAcc)) {
      formatLikelihood += 10;
      return false; //!
      }
    else if (line.startsWith(EmblSeqReader.kDesc)) {
      formatLikelihood += 10;
      return false; //!
      }
    else if (line.startsWith(EmblSeqReader.kSequence)) {
      formatLikelihood += 70;
      return false; //!?
      }
    else
    	return false;
	}

}

public class EmblSeqReader  extends BioseqReader
{
	final static String kID = "ID   ";
	final static String kSequence = "SQ   ";
	// other tags in this format
	final static String kAcc = "AC   ";
	final static String kDate = "DT   ";
	final static String kDesc = "DE   ";
	final static String kOrganism = "OS   ";
	EmblDoc doc;

	public EmblSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 4;
		}
		
	//public BioseqDoc getInfo() { return doc; }

	public boolean endOfSequence() {
		ungetend= ( indexOfBuf(kID) == 0);
	  return (ungetend || indexOfBuf("//") >= 0);
		}

	
	protected void read() throws IOException
	{
		doc= new EmblDoc();
		seqdoc= doc;
  	while (!allDone) {
	  	doc.addDocLine( sWaiting);
	    if (nWaiting > 5) seqid= sWaiting.substring(5).toString();
	    do {
	  		doc.addDocLine( getline());
	    } while (!(endOfFile() || (sWaiting.startsWith(kSequence))));

	    readLoop();
	    if (!allDone) {
	      while (!(endOfFile() || (nWaiting>0 && indexOfBuf(kID) == 0)))
	      	getline();
	    	}
	    if (endOfFile()) allDone = true;
	  }
	}

};


public class EmblSeqWriter  extends BioseqWriter
{
	final static int seqwidth= 60, ktab= 6, kspacer= 10, knumwidth= 8, knumflags= 0;  

	public void writeRecordStart()
	{
		super.writeRecordStart();
   	opts.tab = ktab;    
    opts.spacer = kspacer+1;  
   	opts.seqwidth = seqwidth;
    opts.numright = true; //  added aug'97
    opts.numwidth = knumwidth;  
	}
		
	public void writeRecordEnd() {  writeln("//"); }

	public void writeSeq() // per sequence
	{
		// writeLoop();
		int i, j;
		boolean newline= true;
		for (i= 0; i < seqlen; i++) {
			if (newline) {
				for (j=0; j<ktab; j++) writeByte(' '); 
				newline= false;
				}

	   	char bc= bioseq.base(offset+i,fBasePart);
			writeByte( bc);
			
			if (i % seqwidth == seqwidth-1) { 
	    	writeString( "  " + Fmt.fmt( i+1, knumwidth, knumflags));
				writeln(); newline= true; 
				}
			else if (i % kspacer == kspacer-1) 
				writeByte(' ');
			}
		if (!newline) writeln();
  }
  
	public void writeDoc()
	{
		//ID   DMEST6A    standard; DNA; INV; 1754 BP.
		writeString("ID   ");
		writeln(idword);

    //linesout += 1;
		if (seqdoc!=null && seqdoc instanceof BioseqDoc) {
			linesout += new EmblDoc((BioseqDoc)seqdoc).writeTo(douts);
			}
		else {
			writeString( "DE   ");
			writeString(seqid);
			writeString("  ");
   		writeString( String.valueOf(seqlen));
			writeString(" bases ");
  		writeln(checksumString());
    	//linesout += 1;
			}
		writeString( "SQ   Sequence ");
  	writeString( String.valueOf(seqlen));
		writeln(" BP");
    //linesout += 1;
	}
   
};



public class FitchSeqFormat extends BioseqFormat
{
	public String formatName() { return "Fitch"; }  
	public String formatSuffix() { return ".fitch"; } 
	public String contentType() { return "biosequence/fitch"; } 
	public BioseqReaderIface newReader() { return new FitchSeqReader(); }
	//public BioseqWriterIface newWriter() { return new FitchSeqWriter(); }
	public boolean canread() { return false; }
	public boolean canwrite() { return false; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		int splen= line.length();
		boolean isfitch= true;
    for (int k=0; isfitch && (k < splen); k++) {
      if (k % 4 == 0) isfitch &= (line.charAt(k) == ' ');
      else isfitch &= (line.charAt(k) != ' ');
      }
    if (isfitch && (splen > 20)) formatLikelihood += 10;
    return false;
	}
	
}

public class FitchSeqReader  extends BioseqReader
{
	public FitchSeqReader() {
		margin	=  0;
		addfirst= true;
		addend 	= true;  
		ungetend= false;
		//formatId= 7;
		}
};


public class ZukerSeqFormat extends BioseqFormat
{
	public String formatName() { return "Zuker"; }  
	public String formatSuffix() { return ".zuker"; } 
	public String contentType() { return "biosequence/zuker"; } 
	public BioseqReaderIface newReader() { return new ZukerSeqReader(); }
	//public BioseqWriterIface newWriter() { return new ZukerSeqWriter(); }
	public boolean canread() { return false; }
	public boolean canwrite() { return false; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.charAt(0) == '(') {
      formatLikelihood= 25;
      if (recordStartline==0) recordStartline= atline;
      return false; //!
      }
    else
    	return false;
	}
}

public class ZukerSeqReader  extends BioseqReader
{
	public ZukerSeqReader() {
		margin	=  0;
		addfirst= true;
		addend 	= true;  
		ungetend= false;
		//formatId= 9;
		}
};



public class  Asn1SeqFormat extends BioseqFormat
{
	public String formatName() { return "ASN.1"; }  
	public String formatSuffix() { return ".asn"; } 
	public String contentType() { return "biosequence/asn1"; } 
	public BioseqReaderIface newReader() { return new Asn1SeqReader(); }
	public BioseqWriterIface newWriter() { return new Asn1SeqWriter(); }
	public boolean canread() { return false; }
	public boolean canwrite() { return false; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if ( line.indexOf("::=")>=0 &&
       ( line.indexOf("Bioseq")>=0 ||       // Bioseq or Bioseq-set 
        line.indexOf("Seq-entry")>=0 ||
        line.indexOf("Seq-submit")>=0 ) ) { 
		      formatLikelihood= 90;
		      return true;
		      }
    else
    	return false;
	}
}

public class Asn1SeqReader  extends BioseqReader
{
	public Asn1SeqReader() {
		margin	=  0;
		addfirst= true;
		addend 	= true;  
		ungetend= false;
		//formatId= 16;
		}
};

public class Asn1SeqWriter  extends BioseqWriter
{
	public void writeHeader()  throws IOException { 
		super.writeHeader();
		writeln("Bioseq-set ::= {\nseq-set {"); 
		}
	public void writeTrailer() { 
		writeln("} }"); 
		super.writeTrailer();
		}
};


public class  StriderSeqFormat extends BioseqFormat
{
	public String formatName() { return "DNAStrider"; }  
	public String formatSuffix() { return ".strider"; } 
	public String contentType() { return "biosequence/strider"; } 
	public BioseqReaderIface newReader() { return new StriderSeqReader(); }
	public BioseqWriterIface newWriter() { return new StriderSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }
	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.charAt(0) == ';' && line.indexOf("Strider")>0) {
      formatLikelihood= 75;
      if (recordStartline==0) recordStartline= atline;
      return true;
      }
    else
    	return false;
	}

}

public class StriderSeqReader  extends BioseqReader
{
	public StriderSeqReader() {
		margin	=  0;
		addfirst= true;
		addend 	= false;  
		ungetend= false;
		//formatId= 6;
		}

	public boolean endOfSequence() {
	  return ( indexOfBuf("//")>=0);
		}

	protected void read() throws IOException
	{
	  while (!allDone) {
      getline();
      sWaiting= sWaiting.trim(); 
      nWaiting= sWaiting.length();
	    if (sWaiting.indexOf("; DNA sequence  ")==0)
    		seqid= sWaiting.substring(16).toString();
	    else if (nWaiting > 0)
    		seqid= sWaiting.substring(1).toString();
			while (!(endOfFile() || (nWaiting>0 && sWaiting.charAt(0) != ';' ) )) {
	      getline();
	      sWaiting= sWaiting.trim(); 
	      nWaiting= sWaiting.length();
	    	}
	    
	    if (!endOfFile()) {
	      readLoop();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}
};


public class StriderSeqWriter  extends BioseqWriter
{		
	public void writeRecordEnd() { writeln("//"); }

	public void writeDoc()
	{
		writeln( "; ### from DNA Strider ;-)");
		writeString( "; DNA sequence  ");
		writeString( seqid); 
		writeln( "  " + seqlen + " bases " + checksumString());
		writeln( ";");
		//linesout += 3;
	}
	
};





class TestGcgBase extends TestBiobase
{

	public int isSeqChar(int c) {
		//if (Character.isSpace((char)c) || Character.isDigit((char)c)) return 0;
		if (c<=' ' || (c >= '0' && c <= '9')) return 0;
		else {
	    if (c == '.') return '-';  //do the indel translate 
	    else return c;
	    }
		}
		
	public int outSeqChar(int c) {
			// output translation
		if (c==BaseKind.indelHard) return '.';
		else if (c==BaseKind.indelSoft) return '.';
		else if (c==BaseKind.indelEdge) return '.'; // for GCG-9/RSF, this should be ~
	 	else return c;
		}
		
}

public class  GcgSeqFormat extends BioseqFormat
{
	public String formatName() { return "GCG"; }  
	public String formatSuffix() { return ".gcg"; } 
	public String contentType() { return "biosequence/gcg"; } 
	public BioseqReaderIface newReader() { return new GcgSeqReader(); }
	public BioseqWriterIface newWriter() { return new GcgSeqWriter(); }
	public BioseqWriterIface newWriter(int nseqs) { 
		// can't write more than one seq in this format !
		if (nseqs>1)
			return BioseqFormats.newWriter(
				BioseqFormats.formatFromContentType("biosequence/msf"),nseqs);
		else 
			return new GcgSeqWriter();
		}
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.indexOf("..")>0 && line.indexOf("Check:")>0) {
      formatLikelihood += 80; //92; //??
      //if (recordStartline==0) recordStartline= atline;
      return false; //!?
      }
    else
    	return false;
	}
}

public class GcgSeqReader  extends BioseqReader
{
	public GcgSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		testbase= new TestGcgBase();
		testbaseKind= kUseTester;
		//formatId= 5;
		}

	public boolean endOfSequence() {
		return false;
		}

	protected void read() throws IOException
	{
    boolean gotuw;
    do {
      getlineBuf();
     	gotuw = ( indexOfBuf("..")>=0);
    } while (!(gotuw || endOfFile()));
    if (gotuw) readUWGCG(); 
	}

	protected void readUWGCG()  throws IOException
	{
		atseq++;
		addit = (choice > 0);
	  if (addit) seqlen = 0;
		seqid= sWaiting.toString();
		int i;
	  if ((i = seqid.indexOf("  Length: "))>0) seqid= seqid.substring(i);
	  else if ((i = seqid.indexOf(".."))>0) seqid= seqid.substring(i);
		boolean done;
	  do {
	 		done = endOfFile();
	    getlineBuf();
	    if (!done) addseq(getreadchars(), getreadcharofs()+margin, nWaiting - margin);
	  } while (!done);
	  if (choice == kListSequences) addinfo(seqid);
		allDone = true;
	}
	
 	
};



public class GcgSeqWriter  extends BioseqWriter
{

	protected long calculateChecksum()
	{
		return GCGchecksum( bioseq, offset, seqlen);
	}

	public void writeRecordStart()
	{
		super.writeRecordStart();
		testbase= new TestGcgBase();
		testbaseKind= kUseTester;
		/*
		//dupSeqForOutput= true; // due to bioseq.replace()
		if (dupSeqForOutput) {
			Biobase[] bb= ((Bioseq) seqob).dup();
			this.bioseq= new Bioseq( bb);
			}
    if (BaseKind.indelHard != '.' && bioseq.indexOf( BaseKind.indelHard)>=0) {
    	bioseq= bioseq.clone();
    	String oldb= new String( { indelHard, indelSoft, indelEdge } );
    	String newb= new String( "..." );
    	bioseq.replace(seqlen, oldb, newb);  
    	//bioseq.replace(seqlen, BaseKind.indelHard, '.');   
			} */
   	opts.spacer = 11;
    opts.numleft = true;
	}
		
	//protected void writeRecordEnd() { writeln(); }
	
	public void writeDoc()
	{
		Date date= new Date();
		writeln( seqid );
		writeString( "    " + idword + "  Length: " + seqlen );
		writeln( "  " + date + "  Check: " + checksum + "  ..");
    //linesout += 3;
	}
		
};


		
 