// readseqToba.java

package iubio.readseq;

import java.io.*;
import iubio.readseq.*;
import java.util.Properties;

/**
	* test for Toba Java to C translator (no more development on this project !!)
	*/
	
public class readseqToba 
{ 
  public static void main(String args[]) 
  {        	
  		//!? need caller to pass all env key/value pairs as "env=key=value" args?
  	ReadseqClassList.register(); //? so TOBA compiles runtime classes
		Properties sp= System.getProperties();
		//System.out.println("readseqToba -- System.properties");
		//sp.list(System.out);
		sp.put("TOBA","1");// make sure we know this system?
		new run(args);
  }
}

/*
public class ReadseqClassList
{
	// dummy for replacement w/ generated .java for TOBA j2c
	public static void register() { System.out.println("ReadseqClassList.register"); }
}*/

public class ReadseqClassLister { 
  public static void main(String args[]) { 
  	String outname= args[0];
  	for (int i=0; i<args.length; i++) {
  		String arg= args[i];
  		if (arg.startsWith("out=")) outname= arg.substring(4);
  		}
		PrintStream outs= System.out;
		if (outname!=null) try { 
				outs= new PrintStream(new FileOutputStream(outname)); 
				System.out.println("Printing to "+ outname);
				}
		catch (IOException e) {}
		generateClassJava(outs); 
	}
	
 	public static void generateClassJava(PrintStream pr)
 	{ 
			// write ReadseqClassList.java for use w/ TOBA j2c
		pr.println("// ReadseqClassList.java");
		pr.println("package iubio.readseq;");
		pr.println("public class ReadseqClassList {"/*}*/);
		//pr.println("  public static java.util.Vector list= new java.util.Vector(); ");
		//pr.println("  static void addc( Class c) { list.addElement(c); }");
		pr.println("  public static void dummyregister() { System.out.println(\"ReadseqClassList.register\"); }");
		pr.println("  public static void register() {"/*}*/); 

   		// add sax parser
		pr.println("    new com.ibm.xml.parsers.SAXParser()"); 
		
  	int nf= BioseqFormats.nFormats();
  	for (int i=1; i <= nf; i++) {
  		BioseqFormat fmt= BioseqFormats.bioseqFormat(i);
  		printClass( pr, fmt);

			BioseqReaderIface brd= fmt.newReader();
  		if (brd!=null) printClass( pr, brd);
			BioseqWriterIface bwr= fmt.newWriter();
  		if (bwr!=null) printClass( pr, bwr);
  		}
  		
  	pr.println(/*{*/"  }");
  	pr.println(/*{*/"}");
		}

	final static void printClass(PrintStream pr, Object ob) {
		pr.println("     new " + ob.getClass().getName() + "();");
		}
}

