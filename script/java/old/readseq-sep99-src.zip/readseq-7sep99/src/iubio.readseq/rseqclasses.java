// ReadseqClassList.java
package iubio.readseq;
public class ReadseqClassList {
  //public static java.util.Vector list= new java.util.Vector(); 
 	//static void addc( Class c) { list.addElement(c); }
  public static void dummyregister() { System.out.println("ReadseqClassList.register"); }
  public static void register() {
  	// add sax parser
  	 new com.ibm.xml.parsers.SAXParser();
  	 //
     new iubio.readseq.BioseqFormat();
     new iubio.readseq.GenbankSeqFormat();
     new iubio.readseq.GenbankSeqReader();
     new iubio.readseq.GenbankSeqWriter();
     new iubio.readseq.EmblSeqFormat();
     new iubio.readseq.EmblSeqReader();
     new iubio.readseq.EmblSeqWriter();
     new iubio.readseq.PearsonSeqFormat();
     new iubio.readseq.PearsonSeqReader();
     new iubio.readseq.PearsonSeqWriter();
     new iubio.readseq.GcgSeqFormat();
     new iubio.readseq.GcgSeqReader();
     new iubio.readseq.GcgSeqWriter();
     new iubio.readseq.PlainSeqFormat();
     new iubio.readseq.PlainSeqReader();
     new iubio.readseq.PlainSeqWriter();
     new iubio.readseq.IgSeqFormat();
     new iubio.readseq.IgSeqReader();
     new iubio.readseq.IgSeqWriter();
     new iubio.readseq.PirSeqFormat();
     new iubio.readseq.PirSeqReader();
     new iubio.readseq.PirSeqWriter();
     new iubio.readseq.NbrfSeqFormat();
     new iubio.readseq.NbrfSeqReader();
     new iubio.readseq.NbrfSeqWriter();
     new iubio.readseq.Asn1SeqFormat();
     new iubio.readseq.Asn1SeqReader();
     new iubio.readseq.Asn1SeqWriter();
     new iubio.readseq.PrettySeqFormat();
     new iubio.readseq.PrettySeqWriter();
     new iubio.readseq.StriderSeqFormat();
     new iubio.readseq.StriderSeqReader();
     new iubio.readseq.StriderSeqWriter();
     new iubio.readseq.PhylipSeqFormat();
     new iubio.readseq.PhylipSeqReader();
     new iubio.readseq.PhylipSeqWriter();
     new iubio.readseq.MsfSeqFormat();
     new iubio.readseq.MsfSeqReader();
     new iubio.readseq.MsfSeqWriter();
     new iubio.readseq.PaupSeqFormat();
     new iubio.readseq.PaupSeqReader();
     new iubio.readseq.PaupSeqWriter();
     new iubio.readseq.BlastOutputFormat();
     new iubio.readseq.BlastOutputReader();
     new iubio.readseq.XmlSeqFormat();
     new iubio.readseq.XmlDoc();
		 new iubio.readseq.XmlSeqReader();
		 new iubio.readseq.XmlSeqWriter();
     new iubio.readseq.OlsenSeqFormat();
     new iubio.readseq.OlsenSeqReader();
  }
}
