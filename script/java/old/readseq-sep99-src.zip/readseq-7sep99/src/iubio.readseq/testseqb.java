// testseq.java
// d.g.gilbert, 1990-1999


package iubio.readseqB;

import java.io.*;

import flybase.OpenString;
	
	// interfaces
import iubio.readseq.BioseqReaderIface;
import iubio.readseq.BioseqWriterIface;
//import iubio.readseq.BaseData;
//import iubio.readseq.DocumentData;
import iubio.readseq.BioseqDoc;

import iubio.readseq.BaseKind;
import iubio.readseq.SeqKind;
import iubio.readseq.SeqFileInfo;
import iubio.readseq.Bioseq;
import iubio.readseq.BioseqFormats;


/**
 * Test biosequence input stream for known formats
 *
 * @author  Don Gilbert
 * @version 	Jul 1999
 * @see iubio.readseq.Readseq
 */
public class Testseq 
{
	public static int maxlines2check= 500; // change to use kBufferSize
	public static int kBufferSize = 4094; //8192; 
	protected static int plainFormatID= BioseqFormats.formatFromContentType("biosequence/plain");

	protected boolean done;
	protected int	splen, nbytes, nlines;
	protected int	format, skiplines, maxbytes2check;
	protected SeqKind seqkind;
	
	private final static boolean bSuckAll = true;

	public Testseq()	{
		initTest();
		}
	
	public int getFormat() { return format; }
	public int getStartLine() { return skiplines; }
	
	protected void initTest() {
		format= BioseqFormats.kUnknown;
		done= false;
		nbytes= nlines= splen= skiplines= 0;
		seqkind= new SeqKind( 99999, false, false);
		maxbytes2check= kBufferSize - 200;
		}
			
	protected final OpenString readLine() {
if (bSuckAll) {
		return readOSLine();
} else {
		return readInsLine();
}
		}

	private DataInputStream dis;
	
	protected OpenString readInsLine()  
	{
		OpenString sp= null; 
		splen= 0;
		try {
			done |= dis.available() <= 0; 
			sp= new OpenString( dis.readLine());  
			if (sp==null) done= true;
			else { splen = sp.length(); ++nlines; nbytes += splen; }
			}
		catch (IOException ex) { done= true; }
		return sp;
	}

	private byte[] osval;
	private OpenString osbuf;
	private int oslinei, oslen;
	private char osnewline; // add skipfactor for \r\n newlines?

	protected OpenString readOSLine()
	{
		OpenString sp; 
		if (oslinei<0) {
			done= true;
			splen= 0;
			sp= null;
			}
		else {
			int e= osbuf.indexOf( osnewline, oslinei);
			if (e<oslinei) {
				sp= osbuf.substring( oslinei);
				oslinei= -1; // eof
				}
			else {
				sp= osbuf.substring( oslinei, e);
				oslinei= e+1;  
				}
			splen= sp.length(); // oslen - oslinei
			++nlines; nbytes += splen;
			}
		return sp;	
	}
	
	protected void openStream( InputStream ins) {	
if (bSuckAll) {
			// suck all into one openstring -- reader will reset stream as needed !?
		if (osval==null) osval= new byte[kBufferSize];
		try { 
			oslen= ins.read( osval); 
			osbuf= new OpenString( osval, 0, 0, oslen);
			oslinei= 0;
		} catch (IOException e) { oslen= 0; oslinei= -1; }
		for (int i=0; i<oslen; i++) {
			if (osval[i] == '\n')  { osnewline= '\n'; break; }
			else if (osval[i] == '\r')  { osnewline= '\r'; break; }
			}
} else {
		InputStream bufin;
		if (ins.markSupported()) bufin= ins;
		else bufin= new BufferedInputStream( ins, kBufferSize);
		bufin.mark( kBufferSize); 
		dis= new DataInputStream( bufin);
}
	}



	public int testFormat( InputStream ins, SeqFileInfo si) 
	{
	  int maybeskip = 0, iform, bestform = -1, bestpct = 0,
				otherlines= 0, aminolines= 0, dnalines= 0;
		
	  if (ins == null) { 
	  	si.err = -1; //eFileNotFound
	  	format= BioseqFormats.kNoformat; 
	  	return format; 
	  	// throw new FileNotFoundException();
	  	} 
	  	
		initTest();
		BioseqFormats.formatTestInit();
	 	openStream( ins); 			
					
	  while ( !done ) {
	    OpenString sp= readLine();

	    			// check for mailer head & skip if found 
	    if (nlines < 10 && !done) {
	   		int k;
	      if (sp.indexOf("From ") == 0 || sp.indexOf("Received") == 0 ) {
	        do {
	         			// skip all lines until find one blank line 
	    			k=0;
	    			sp= readLine();
	          if (!done) for (k=0; (k<splen) && (sp.charAt(k)==' '); k++) ;
	          } while ((!done) && (k < splen));
	        skiplines = nlines; // !? do we want #lines or #bytes ?? 
	        }

	      else if (sp.indexOf("<html>") >= 0 || sp.indexOf("<HTML>") >= 0 ) {
	        do {
	          // skip all lines until find </form> or </FORM> or <PRE> or <pre> 
	    			k=0;
	    			sp= readLine();
	          if (!done) done= (sp.indexOf("<PRE>")>=0);
	          if (!done) done= (sp.indexOf("<pre>")>=0);
	          } while ((!done) && (k < splen));
	        skiplines = nlines; 
	        }
	        
	      }

	    boolean testLineFound= false;
	    if (sp!=null && splen > 0) {
				for (iform=0; iform< BioseqFormats.nFormats(); iform++) {
					if (BioseqFormats.formatTestLine( iform, sp, nlines, skiplines) ) {
						testLineFound= true;
						//?? break;
						}
					}

		   	if (!testLineFound || nlines - skiplines > 10) {
					seqkind.add( sp.toString(), 0, splen);		     	
		      		// kRNA && kDNA are fairly certain...
		      switch (seqkind.getKind()) {
		        case Bioseq.kDNA     :
		        case Bioseq.kRNA     : if (splen>20) dnalines++; break;
		        case Bioseq.kNucleic : break; // not much info ? 
	        	case Bioseq.kOtherSeq: otherlines++; break;
		        case Bioseq.kAmino   : if (splen>20) aminolines++; break;
			    	}
	      	}
				}
			
			for (iform=0, bestform= -1, bestpct= 0; 
				iform< BioseqFormats.nFormats(); iform++) {
					int percent= BioseqFormats.formatTestLikelihood(iform); 
					if (percent > bestpct) {
						bestform= iform;
						bestpct= percent;
						}
					}
				
			if (bestform>=0 && bestpct >= 90) {
				format= BioseqFormats.formatFromIndex(bestform);  
				done= true;
				}

	    else if (done 
	    	//|| (dnalines > 1)  
	    	//|| (aminolines > 1) //!?!? need for prot data, but confused with regular text !!!
	    	//|| (nlines > maxlines2check) 
	    	|| (nbytes > maxbytes2check)
	    	) {
	          // decide on most likely format 
	      if (bestform >= 0 && bestpct > 50) 
	      	format= BioseqFormats.formatFromIndex(bestform);  
	     
	          // no format chars: 
	      else if (otherlines > 0) format= BioseqFormats.kUnknown;
	      else if (dnalines > 1) format= plainFormatID;  
	      else if (aminolines > 1) format= plainFormatID;  
	      else format= BioseqFormats.kUnknown;

	      done= true;
	      }

	    	// need this for possible long header in olsen format (
	  	//else if (sp.indexOf("): ")>=0)   
	      // maxlines2check++;
	    }
				
		if (bestform>=0) maybeskip= BioseqFormats.recordStartLine(bestform) - 1;
		if (skiplines==0 && maybeskip>0) skiplines= maybeskip;  
		si.format= format;
		si.skiplines= skiplines;	
	  return format;
	}  

	
} //Testseq
