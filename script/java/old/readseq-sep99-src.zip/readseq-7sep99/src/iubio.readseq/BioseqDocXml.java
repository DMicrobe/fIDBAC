// iubio/readseq/BioseqDocXML.java

package iubio.readseq;


import java.io.*;
import java.util.*;

import flybase.*;
//import Acme.Fmt;

//import iubio.bioseq.*;
import iubio.bioseq.BaseKind;
import iubio.bioseq.SeqKind;
//import iubio.bioseq.Biobase;
import iubio.bioseq.Bioseq;


import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.Parser;
import org.xml.sax.helpers.ParserFactory;
//import org.xml.sax.HandlerBase; // below interfaces make up HandlerBase
import org.xml.sax.EntityResolver;
import org.xml.sax.DTDHandler;
import org.xml.sax.DocumentHandler;
import org.xml.sax.ErrorHandler;
import org.xml.sax.AttributeList;
import org.xml.sax.Locator;
import org.xml.sax.InputSource;


public class  XmlSeqFormat extends BioseqFormat
{
	public String formatName() { return "XML"; }  
	public String formatSuffix() { return ".xml"; } 
	public String contentType() { return "biosequence/xml"; }  //? biosequence/xml  or "text/xml"
	public boolean canread() { return hasXmlParser; }
	public boolean canwrite() { return true; }
	public boolean hasdoc() { return true; }

	public BioseqReaderIface newReader() { return new XmlDoc(); }
	public BioseqWriterIface newWriter() { return new XmlDoc(); }

	public static String tag1= "<Bioseq"; //, tag2; //! this could be changed in XmlDoc.properties !
	
	private static boolean hasXmlParser;
	public  static String saxParserClass;
	private static String saxlParserClasses[] =
				{ "com.ibm.xml.parsers.SAXParser",
	    		"com.sun.xml.parser.Parser",
	    	 	"com.microstar.xml.SAXDriver"
				};  
				
	static { locateXmlParser(); }
	
	public static void locateXmlParser()
	{
		if (System.getProperty("TOBA")!=null) {
			saxParserClass = System.getProperty ("org.xml.sax.parser", saxlParserClasses[0]);
			hasXmlParser= true;
			}
		else for (int i= 0; !hasXmlParser && i<saxlParserClasses.length; i++) 
			try { 
			String className= saxlParserClasses[i];
			if (i==0)  className = System.getProperty ("org.xml.sax.parser", className);
			Class c= Class.forName(className); 
			if (c!=null) { saxParserClass= className; hasXmlParser= true; }
			}
			catch (Exception ce) {}
	}
	
	/* public void formatTestInit() {
		super.formatTestInit();
		if (tag1==null) try  {
			tag1=  "<" + XmlDoc.getXMLFieldName(BioseqDoc.kBioseqSet);
			//tag2=  "<" + XmlDoc.getXMLFieldName(BioseqDoc.kBioseq);
						//^ these calls to XmlDoc force loading of xml classes - avoid for testing?
			} 
		catch (Exception e) {}
		}*/
	
	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
			//? check for <?xml tag ?
		if ( line.indexOf(tag1)>=0) {  //match Bioseq or Bioseq-set 
		 	formatLikelihood += 90;
		 	return true;
		 	}
		else if ( line.indexOf("<?xml")>=0) {
		 	formatLikelihood= 40; // could be someone else's xml
		 	return false;
			}
    else
    	return false;
	}
}



/**
	* Read and write XML formatted biosequence data <p>
	* using xml tags from BioseqDoc.properties, and feature items as tags <p>
	* [?? split into reader and writer parts? kind of messy now]
	*/
	
public class XmlDoc 
	extends BioseqDocImpl
	implements BioseqWriterIface
		, BioseqReaderIface
  	, EntityResolver, DTDHandler, DocumentHandler, ErrorHandler // SAX HandlerBase
{
	public static String xmlprop= "XmlDoc"; 
	public boolean showErrors;
	public static int readChunkSize= 2048; //8192;
	//public static int readFreeSize = readChunkSize * 100;
	//public static int kBigSeqBuf = readFreeSize;
	private static FastHashtable label2keys = new FastHashtable();  // format label => biodockey
	private static FastProperties	keys2label= new FastProperties();  // biodockey => format label
	
	static { 
  	String pname= System.getProperty( xmlprop, xmlprop);
  	getDocProperties(pname,keys2label,label2keys);
		}
		
	public XmlDoc() { 
		//super(); 
		initx(); }
	
	public XmlDoc(BioseqDoc source) {
		super(source);
		fFromForeignFormat = !(source instanceof XmlDoc);
		initx();
		}
		
	public XmlDoc(String idname) { 
		super();
		initx(); 
		addBasicName( idname);
		}

	public void setSourceDoc(BioseqDoc source)
	{
		super.setSourceDoc(source);
		fFromForeignFormat = !(source instanceof XmlDoc);
	}
	
	protected void initx() {
		//fFieldIndent= 5;
		//fFeatIndent= 21;
		//fFeatureTag= "FT";
		//refnum= 0;
		showErrors= Debug.isOn;
		}


		//
		// Doc reader
		//
		
	public void addDocLine(String line) //abstract
	{
		// need an XML parser here... see below, use SAX parser, not this method
	}	


	public String getBiodockey(String field) { 
		//return field;  // uncouple biodockey from xml tags
		return (String)label2keys.get(field); 
		}
		
	public  String getFieldName(int kind) {
		return getXMLFieldName(kind);
		}
	
	public final static String getXMLFieldName(int kind) {
		return getXMLFieldName( new Integer(kind)); 
		}

	public static String getXMLFieldName(Integer kind) {
		String lab= null, biodockey= null; 
		try {
			//biodockey= getBiodockey(kind); // can't do static
			biodockey= (String) biodockinds.get(kind);
			lab= (String) keys2label.get( biodockey);
			} 
		catch (Exception e) { 
			if (biodockey!=null) lab= biodockey; 
			else if (kind!=null) lab= "Noname"+kind; 
			}
		return lab;
		}
	

		//
		// interface BioseqWriterIface
		//
	 
	final static int kSeqwidth= 78; // up from default 50, jul'99 - ASN.1 uses 78
	final static int kLinewidth= 78;

	protected BufferedWriter douts; 
	protected boolean newline= true;
	protected boolean noendeol, needindent; //? same as newline
	protected int writecol ;
	protected int formatId;
	protected int err;
	protected int seqlen, offset, nseq, atseq;
  protected long checksum = 0;
  
	protected int fBasePart= Bioseq.baseOnly;
	protected String seqid= SeqFileInfo.gBlankSeqid;
	protected String idword= SeqFileInfo.gBlankSeqid;
	protected Bioseq	bioseq; // change to Object, or some more flexible class
	protected byte[]  seqbytes;
	protected Object  seqdoc;
	protected int level= 0;

	public int formatID() { return formatId; }
	public void setFormatID(int id) { formatId= id; } //? Readseq sets id?

	public static boolean dochecksum= true; // make a protected nonstatic
	public boolean getChecksum() { return dochecksum; }
	public void setChecksum(boolean turnon) { dochecksum= turnon; }
	
	public void setOutput( Writer outs)
	{
		if (outs instanceof BufferedWriter) douts=(BufferedWriter)outs ;//DataOutputStream
		else douts= new BufferedWriter(outs);//DataOutputStream
		PrintWriter pr= new PrintWriter(douts);
		this.pr= pr;
	}
	
	public void close() throws IOException { 
		douts.close();  
		}

	public int getError() { return err; }
		

		//
		// per file methods
		//
		
	public int seqLen() { return seqlen; }
	public int getNseq() { return nseq; }

	public void setNseq(int nsequences) { this.nseq= nsequences;  }

	public void writeHeader() throws IOException
	{
		if (douts==null) throw new FileNotFoundException(); //err= Readseq.eFileNotFound;
		//checksumTotal= 0; 	
		nseq= 0;	
		level= 0;
		pr.print("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); writeln();
		// later, when we have a dtd
		//pr.print("<!DOCTYPE biosequence SYSTEM \"biosequence.dtd\">"); writeln();
		writeln();
		
		writeStartElement( getFieldName(kBioseqSet));
	}
	
	public void writeTrailer() {
		writeEndElement( getFieldName(kBioseqSet));
		try { douts.flush(); } catch (IOException ex) {}
	}


			/** per sequence */

	public boolean setSeq( SeqFileInfo si) {
		if (si.ismask) return false;
		//? pull checksum from si if there? or from seq.?
		return setSeq( si.seq, si.offset, si.seqlen, si.seqid, si.seqdoc, si.atseq, Bioseq.baseOnly);
		}

	public boolean setMask( SeqFileInfo si, String masktag) {
		int  bpart= Bioseq.baseOnly;
		if (si.ismask)	
			bpart=  Bioseq.baseOnly;
		else if (si.hasmask)  
			bpart= Bioseq.maskOnlyAsText;
		else return false;
		masktag= si.seqid.toString() + masktag;
		return setSeq( si.seq, si.offset, si.seqlen, masktag, si.seqdoc, si.atseq, bpart);
		}	
		
	public boolean setSeq( Object seqob, int offset, int length, String seqname,
						 Object seqdoc, int atseq, int basepart) 
	{
		this.seqlen= length;
		this.checksum= 0;  //?
		if (length>0 && seqob!=null) {
			if (seqob instanceof Bioseq) {
				this.bioseq= (Bioseq) seqob;
				}
			else if (seqob instanceof byte[]) {
				this.seqbytes= (byte[]) seqob;
				}
			this.atseq= atseq; 
			this.offset= offset;
			setSeqName(seqname);
			setSeqPart(basepart);
			this.seqdoc= seqdoc;
			return true;
			}		
		return false;
	}

	public void setSeqName( String name) { 
		int i;
		seqid= name;
		seqid= seqid.trim();
		if ( seqid.indexOf("checksum") >0 ) {
	  	i= seqid.indexOf("bases");
	    if (i>0) {
	    	for ( ; i > 0 && seqid.charAt(i) != ','; i--) ;
	      if (i>0) seqid= seqid.substring(0, i);
	      }
	    }
		i= seqid.indexOf(' ');
		if (i<=0) i= seqid.length();
		if (i>30) i= 30;
		idword= seqid.substring(0,i).toString();
		}

	public void setSeqPart(int basepart) { 
		fBasePart= basepart;
		}

	
	public void writeSeqRecord() throws IOException  // -- does all below methods, given seqSeq()
	{
		writeRecordStart();  
		writeDoc();  
		writeSeq();   
		writeRecordEnd();
	}
			
		/**  write sequence data, when all seq is known from setSeq()  */
	public void writeSeq() 
	{
		String seqtag= getFieldName(kSeqdata);
		writeStartElement( seqtag, false);
		int indent= 2*level + seqtag.length()+2;
		if (bioseq.isBytes()) {
			byte[] ba= bioseq.toBytes();
			for (int i=0, len= kSeqwidth - indent; i<seqlen; i += kSeqwidth, len= kSeqwidth) {
				if (len+i>seqlen) len= seqlen-i;
				//? tab(level*2);
				writeCharacters( ba, offset+i, len);
				//if (i+len<seqlen) 
				if (seqlen>=kSeqwidth) writeln();  
				len= kSeqwidth;
				}
			}
		else {
			for (int i= 0; i < seqlen; i ++ ) {
		   	//if (newline) tab(2*level); 
		   	char bc= bioseq.base(offset+i,fBasePart);
				printEncoded( bc); newline= false;
				if (i % kSeqwidth == kSeqwidth-1) writeln();
				}
			}
		writeEndElement( seqtag, false);
	}  
	
	
		/**  end of seq before newline or end of record  */
	public void writeSeqEnd() {
		}  

	
		/** start of sequence record, initialize per seq, subclasses customize as needed */
	public void writeRecordStart() {
		//atseq++;  - setseq sets this?
		nseq++; // which do we use?
		linesout = 0; //? per seq
		checksum = 0; //? reader may have checksum...

		writeStartElement( getFieldName(kBioseq));
		level++;
		if (dochecksum && checksum==0) checksum= calculateChecksum();
		}  
		
		/**  end of seq record  */
	public void writeRecordEnd() {  
		level--;
		writeEndElement( getFieldName(kBioseq));
		writeln();	
		}  


		// for BioseqWriter -- may as well do all here...
	protected void writeID() {
		writeTag( getFieldName(kName), idword, level);
		}

	protected void writeStats() {
					// these where in writeID() -- do always?
		//SeqKind sk= new SeqKind( seqlen, false, false);
		//if (bioseq.isBytes()) sk.add( bioseq.toBytes(), 0, seqlen);
		//else sk.add( bioseq.bases(), 0, seqlen);

		writeTag( getFieldName(kSeqlen), String.valueOf(seqlen), level);
		int sqtype= bioseq.getSeqtype();
		String skind= SeqKind.getKindLabel( sqtype);
		writeTag( getFieldName(kSeqkind), skind, level);
		String cks= checksumString();
		if (cks.length()>0) writeTag( getFieldName(kChecksum), cks, level); 
		}
				
		/**  write documentation for record, form where all doc is known from setSeq() */
	public void writeDoc()
	{
		// this is an unneeded wrapper tag
		//String doctag=  getFieldName(kBioseqDoc);
		//writeStartElement(doctag); level++;
		
		if (seqdoc instanceof BioseqDoc) {
			//XmlDoc doc= new XmlDoc((BioseqDoc)seqdoc); //? new or use self?
			this.setSourceDoc((BioseqDoc)seqdoc);
			if (this.getID()==null) writeID();
			//linesout += 
			this.writeTo(douts, true);
			while (!endstack.empty()) {
				String endlab= (String) endstack.pop();
				writeEndElement( endlab);
				}
			}
		else {
			writeID();
			writeTag( getFieldName(kDescription), seqid, level);
			}
			
		writeStats(); // always??

		//level--; writeEndElement(doctag);
 	}
		
	
	
	protected java.util.zip.Checksum summer;
	
	protected long calculateChecksum() {
		if (BioseqWriter.gJavaChecksum && summer==null) summer= new java.util.zip.Adler32();
		return BioseqWriter.calculateChecksum( bioseq, offset, seqlen, summer);
		}
	
	protected String checksumString() {
		if (checksum==0) return ""; else 
		return  Long.toHexString(checksum).toUpperCase(); //Fmt.fmt( checksum, 0, Fmt.HX)
		}





		//
		// BioseqDoc writer
		//

	int lastlev= -1;
	FastStack endstack= new FastStack();

	final boolean bNewTags= true; // revised feature tag format
	
	
	final void popend(int lev1) {
		if (((lastlev == kSubfield && lev1 != kSubfield) 
				|| (lastlev == kField && lev1 != kSubfield)
				|| (lastlev == kFeatCont && lev1 != kFeatCont )
				|| (lastlev == kFeatField && lev1 != kFeatCont )
				) && !endstack.empty() )  
					writeEndElement( (String) endstack.pop(), needindent);
					
		if ( (lastlev == kField && lev1 == kSubfield)
			// || (lastlev == kFeatField && lev1 == kFeatCont ) // not for bNewTags
			 ) { writeln(); } //level++; 
		if (lev1 == kSubfield) level++; // hack fix
	}
		
	protected void writeText( PrintWriter pr, Object ob, int doclev, boolean writeAll) 
	{
		int oldlev= level;
		level= doclev;

		if (ob instanceof DocItem) {
			DocItem nv= (DocItem) ob;
			String name= nv.getName();
			String val= nv.getValue(); //? allow non-string vals, like SeqRange ?
			int kind= nv.getKind();  
			int lev1= nv.getLevel(); 
			
			popend(lev1); lastlev= lev1;

			if (kind == kSeqdata) return; // doing elsewhere
		
			String tag= getFieldLabel( lev1, kind, name, (val==null ? 0 : val.length()));

			if (kind == kFeatureTable && writeAll) {
				if (features().size()>0) {
					//level++; 
					writeStartElement( tag);
					writeTextVector( pr, features(), level+1, writeAll); 
					popend(lev1); lastlev= lev1;
					writeEndElement( tag); 
					//level--;
					}
				writingAll= false; // only once !
				featWrit= true;
				level= oldlev;
				return;
				}
				
			if (val!=null) val= val.trim(); // got some blank vals?

if (bNewTags) {

			if (kind == kFeatureItem) {
				String fitag= getFieldName( kFeatureItem);
				writeTagStart( fitag, name, level); // ! name is value here
				writeln();
				//endstack.push(fitag);
					
				if (ob instanceof FeatureItem) { // should always be true here??
					FeatureItem fi= (FeatureItem) ob;
					writeTag( getFieldName( kFeatureLocation), fi.getLocationString(), level+1);
					if (fi.notes != null) writeText( pr, fi.notes, level, false);
					}

				else if (val!=null && val.length()>0) {
					// are there any chars now in feat item - just other elements
					writeTag( getFieldName( kFeatureValue), val, level+1);
					}
			
				writeEndElement( fitag); //, needindent
				}
				
	 		else if (kind == kFeatureNote) {
				String fntag= getFieldName( kFeatureNote);
				writeTagStart( fntag, name, level); // ! name is value here
				if (val!=null && val.length()>0) 	{
					int vlev= 0;
					String fvtag= getFieldName( kFeatureValue);
					int lwidth= val.length() + fvtag.length() + 2 + writecol;
					if (lwidth > kLinewidth) { writeln(); vlev= level+1; }
					noendeol= (lwidth +fvtag.length() + 2 < kLinewidth);
					writeTag( fvtag, val, vlev);
					needindent= !noendeol;
					noendeol= false;
					}
				writeEndElement( fntag, needindent); 
 				}
 				
 			else {
				if (tag!=null) { 
					//val= getFieldValue( val, lev1, kind, name);
					writeTagStart( tag, val, level);
					if ( lev1 == kField ) endstack.push(tag); else 
					writeEndElement( tag, needindent);
					}
				}
					
} else {
				
			FeatureItem fi= null;
			if (ob instanceof FeatureItem) {
				fi= (FeatureItem) ob;
				val= fi.getLocationString();
				}

			if (tag!=null && val!=null && val.length()>=0) { 
				//val= getFieldValue( val, lev1, kind, name);
				
				writeTagStart( tag, val, level);

				if ( lev1 == kField || lev1 == kFeatField ) endstack.push(tag); else 
				writeEndElement( tag, needindent);
				}
				
			else if (tag!=null) {
				// but if contains elements...
				writeEmptyElement(tag);
				}
				
			if (fi!=null) {
				if (fi.notes != null) writeText( pr, fi.notes, level+1, false);
				}
}
			}
			
		else if (ob instanceof FastVector) { //i > 0 && 
			writeTextVector( pr, (FastVector) ob, level+1, writeAll); //false 
			}
		level= oldlev;
	}

	protected String cleanXmlTag(String tag) {
		//if (tag.startsWith("/")) tag= tag.substring(1); // for feature tables
		//^^ don't drop '/' otherwise can dup other tags - change to _
		if (Character.isDigit(tag.charAt(0))) tag= "N" + tag;
		char[] buf= tag.toCharArray();
		for (int i= 0; i<buf.length; i++) {
			char c= buf[i];
			if (! (Character.isLetterOrDigit(c) 
					|| c == '_' || c == '-' || c == '.' || c == ':'
					)) buf[i]= '_';
			}
		return new String(buf);
	}

	protected String uncleanXmlTag(String tag) {
		if (tag.startsWith("_")) tag= "/" + tag.substring(1);
		else if (tag.startsWith("N") && Character.isDigit(tag.charAt(1)))
			tag= tag.substring(1);
		if (tag.equals("5_UTR")) tag= "5'UTR";
		else if (tag.equals("3_UTR")) tag= "3'UTR";
		return tag;
	}
	
	
	protected String getFieldLabel(int level, int kind, String name, int valkind) 
	{
		//if (name.startsWith("/")) name= name.substring(1);
		switch (level) {
			case kContinue  :
			case kSubfield  : 
			case kField     :  
				if (fFromForeignFormat) name= getFieldName(kind); // preserve orig name if null?
				if ( name==null || name.length()==0 ) return null; //? 
				//if  (!doWriteId && kind == kName ) return null;
				break;
				
			//case kContinue  : name= "";  myindent= indent= fFieldIndent; break;
			//case kFeatField : name= "     " + name; myindent= indent= fFeatIndent; break;
			/*case kFeatCont  : 
				if (valkind!=0) name += "=";
				t = Fmt.fmt( " ", fFeatIndent, Fmt.LJ);  
				break;*/
			/*case kFeatWrap  : 
				name= " ";
				break;*/
			}
		name= cleanXmlTag( name);
		return name;
	}



		//
		// BioseqReaderIface
		//
		
	private boolean fEof= false;
		// input buffer
	private Reader fIns;

	//private byte[]  seqbytes; // see above; local storage 
	private XmlDoc  xmlseqdoc;
	private FastVector seqvec;
	protected int seqoffset, seqlencount, maxseqlen, choice;
	
	protected final static int kUseTester= 1, kAnyChar= 2, kAlphaChar= 3;
	//protected TestBiobase	testbase= new TestBiobase();
	protected int testbaseKind= kAlphaChar;
		
	private final int testbase(int c) {
		switch (testbaseKind) {
  		default:
  		case kAlphaChar	: if (c<=' ' || (c >= '0' && c <= '9')) return 0; else return c;
  		case kAnyChar		: if (c<' ') return 0; else return c;
  		//case kUseTester	: return testbase.isSeqChar(c); 
  		}
		}

	
	public void setChoice(int seqchoice) { choice= seqchoice; }

	public void setInput(Reader ins) {  
		this.fIns= ins; 
		fEof= false; 
		setReaderBuf(fIns);
		}

		// read one sequence, choice == seq index
	public void doRead() throws IOException { 
		if (fIns==null) throw new FileNotFoundException(); //err= Readseq.eFileNotFound;
		
		if ( seqvec == null || seqvec.isEmpty() ) {
			// call sax parser here, store all seqs in seqVec
			doSaxRead();
			}
		else {
			// skip on; caller will fetch data from copyto() call
			}
		}


		// from Readseq.readTo() -- more efficient to do here
	public void readTo( BioseqWriterIface writer, int skipHeaderLines)  throws IOException 
	{
		BioseqFormat wrformat= BioseqFormats.bioseqFormat( writer.formatID()); 
		skipdocs= ! wrformat.hasdoc();
		setSaxWriteTo( writer);
		
		//writer.writeHeader(); // or do via sax.startDocument() ?

		doSaxRead();
		
		/*
		boolean more= true;
		int atseqNum;
		for (atseqNum= 0; more; atseqNum++) {  
			SeqFileInfo si= this.readOne(atseqNum);
			if (si == null) more= false;
			else {
				if (writer.setSeq( si)) writer.writeSeqRecord();
				//?? if (fWriteMask && writer.setMask(si,si.gMaskName)) writer.writeSeqRecord();
				}
			} 
		*/
			
		//writer.writeTrailer(); // or do via sax.endDocument() ?
		setSaxWriteTo( null);
	}
				 
	public SeqFileInfo readOne(  int whichEntry) throws IOException
	{
		this.resetSeq();
    if ( this.endOfFile() ) return null; 
		this.setChoice( whichEntry); 
		this.doRead(); 
		
		SeqFileInfo si= new SeqFileInfo();
		this.copyto( si);
		si.nseq= this.getNseq(); // or is this atseq?
		//? checkSeqID();
		if (Debug.isOn) Debug.println( getClass().getName() + ", id=" + si.seqid + ", seqlen=" + si.seqlen);
   	return si;	
	}

	public boolean endOfFile() { 
		if (seqvec!=null) {
			return (choice > seqvec.size());
			}
		return fEof; 
		}

	private void setReaderBuf(Reader ins) {
		// need to reset SAX reader !?
  	//? saxhandler.setCharacterStream (fIns);
  	if (seqvec != null) seqvec.removeAllElements();
		}			
		
	public void reset() 
	{
		seqlen= seqlencount= err= atseq= 0;
		//ungetline= allDone= false;
		fEof= false; 
		if (fIns!=null) try {
			fIns.reset();
			fEof= !fIns.ready();
			setReaderBuf(fIns); //bufins.reset(); //?
			}
		catch (IOException ex) { 
			Debug.println( getClass().getName() + ".reset() err=" + ex.getMessage());
			}
	}

	public void skipPastHeader(int skiplines) 
	{
		// not for xml parser
	}

	public void copyto( SeqFileInfo si) 
	{
		if (si==null) return;
		try {
			SeqFileInfo sat= (SeqFileInfo) seqvec.elementAt(choice-1);
			sat.copyto(si);
			//? remove element/storage after copyto() ??
			} 
		catch (Exception e) { si.err= -2; } //?
	}

	protected void storeSeq() throws IOException
	{
		// for SAX parser, save all seqs as parsed
		if (seqlen>0) {  
			atseq++; nseq++; //?
			if (Debug.isOn) Debug.println( getClass().getName() + " : "+atseq+":"+seqid.trim());
			Bioseq bseq= new Bioseq( seqbytes, 0, seqlen, true);
			SeqFileInfo si= new SeqFileInfo( bseq, 0, seqlen );
			si.atseq= atseq; //??<< counted to current sequence in file
			si.nseq= nseq;
			si.seqid= seqid;
			si.err= err;
			si.seqdoc= xmlseqdoc;
			
			if (seqvec==null) seqvec= new FastVector();
			if (bioseqwriter!=null)  {
				if (bioseqwriter.setSeq( si)) bioseqwriter.writeSeqRecord();
				//? add dummy si to seqvec for counting?
				SeqFileInfo sidum= new SeqFileInfo();
				sidum.seqid= si.seqid;
				sidum.atseq= si.atseq;
				seqvec.addElement( sidum);
				}
			else {
				seqvec.addElement( si);
				}
			}
	}

	protected int inElVal, inFeatures;
	protected Integer inEl;
	protected String inTagName;
	protected boolean inElAppend;
	protected FastStack inElStack= new FastStack();
	protected String inFeatureKey, inFeatureVal; //, inFeatureLoc;
	protected int featlevel;

	//public static String saxParserClass = "com.ibm.xml.parsers.SAXParser";  
	boolean continueOnError= true;

	protected void doSaxRead() throws IOException 
	{
		try {
		//String className = XmlSeqFormat.saxParserClass; 
			//System.getProperty ("org.xml.sax.parser", saxParserClass);
	 	Parser parser;
	 	try { parser= ParserFactory.makeParser(XmlSeqFormat.saxParserClass); }
	 	catch (Exception ep) { parser= ParserFactory.makeParser(); }
	 	if (parser==null) {
	 		throw new IOException("Can't instantiate an XML parser"); 
	 		}
    parser.setDocumentHandler(this);
    parser.setDTDHandler(this);
    parser.setErrorHandler(this);
		//if (parser instanceof XMLParser) 
		//	((XMLParser)parser).setContinueAfterFatalError(continueOnError);
   	InputSource inputSource= new InputSource( fIns);
    parser.parse( inputSource );
    }
    catch (Exception e) { 
    	e.printStackTrace();
    	throw new IOException(e.getMessage()); 
    	}
	}

	protected BioseqWriterIface bioseqwriter;
	
	protected void setSaxWriteTo(BioseqWriterIface writer)
	{
		this.bioseqwriter= writer;
	}
		
	protected void initSaxDoc() {
		atseq= nseq= 0;
		inFeatures= kBeforeFeatures;
		inElVal= -1;
		inEl= null;
		inTagName= null;
		inElAppend= false;
		inElStack.removeAllElements();
		inFeatureKey= inFeatureVal= null; //, inFeatureLoc;

		resetSaxSeq();
		}
		
	protected void resetSaxSeq() {
		resetSeq();
		xmlseqdoc= new XmlDoc(); // new one of me
		xmlseqdoc.setSkipDocs( skipdocs);
		}
		
	public void resetSeq() {
		seqlen= seqlencount= 0; 
		//allDone= false;
		idword= SeqFileInfo.gBlankSeqid;
		seqid= SeqFileInfo.gBlankSeqid;
		//maxseqlen= 0; seq= null; //? leave storage for next and copy prior?
		}

	protected void addseq( char[] b, int offset, int nb) 
	{
	  //if (!addit) return;
	  nb += offset;
	  for (int i=offset; i<nb; i++) { 
	  	int c= testbase( b[i]);
	    if (c > 0) {
	      if (seqlen >= maxseqlen) if (!expand()) return;
		   	seqbytes[seqlen++]= (byte) c;  
	      }
	    }
	}
	
	protected boolean expand() 
	{
  	maxseqlen += readChunkSize;
		if (seqbytes==null) seqbytes= new byte[maxseqlen];
		else {
			byte[] tb= new byte[maxseqlen];
			System.arraycopy( seqbytes, 0, tb, 0, seqlen);
			seqbytes= tb;
			}
  	return (seqbytes!=null);
	}



	  //
	  // SAX HandlerBase reader interface
	  //
	  

	public void error (SAXParseException e) throws SAXException
  { errorOut("error: ", e);  }

  public void fatalError (SAXParseException e) throws SAXException
  { errorOut("fatalError: ",e); }
  
  public void warning (SAXParseException e) throws SAXException
  { errorOut("warning: ",e); }

	protected void errorOut (String kind, SAXParseException e) {
		//String id= e.getPublicId(); // which ?
		err++;
		if (showErrors) {
			String id= e.getSystemId();
			if (id!=null) {
				int at= id.lastIndexOf('/');
				if (at>0) id= id.substring(at+1);
				}
			System.err.print( id + ":" + e.getLineNumber() + ":"+ e.getColumnNumber() + " ");
			System.err.println( kind + e.getMessage());
			}
  }


	public void startDocument() throws SAXException {
		initSaxDoc();
		try {
		if (bioseqwriter!=null) bioseqwriter.writeHeader();
		} catch (Exception e) { throw new SAXException(e); }
    }  

  public void endDocument()  throws SAXException {
		fEof= true;
		try {
		if (bioseqwriter!=null) bioseqwriter.writeTrailer();
		} catch (Exception e) { throw new SAXException(e); }
  	}

	
  public void startElement(String name, AttributeList atts)   throws SAXException 
  {
  	try {
  	int lastel= inElVal;
  	inTagName= name;
  	inElAppend= false;
  	if (inEl!=null) inElStack.push( inEl);
  	
		inEl= getBiodocKind(name); 
		if (inEl!=null) inElVal= inEl.intValue();
		else inElVal= -1;

		/*if (inFeatures == kAtFeatureHeader) { 
				// && inElVal <= 0 -- ignore inElVal - not set for features
			inFeatures= kInFeatures;
			//featlevel= kFeatField; 
			//! inElVal= kFeatureItem;  
			//! inEl= new Integer(inElVal); //? for later push/pop?
			}
		else if (inFeatures == kInFeatures) { 
			//! if (featlevel >= kFeatField) inElVal= kFeatureNote;  
			//! else inElVal= kFeatureItem;  
			//! inEl= new Integer(inElVal); //? for later push/pop?
			//featlevel++; // will pop this back at endEl() //kFeatField //kFeatCont; //
			}*/
			
		if (inElVal == kFeatureTable) {
//		kBeforeFeatures = 0,  kAtFeatureHeader= 1, kInFeatures = 2, kAfterFeatures= 3,
			inFeatures= kInFeatures; //kAtFeatureHeader;
			// has no chars, only xml elements
			inFeatureVal= inFeatureKey= null; 
			}
		else if (inElVal == kFeatureItem) {
			/*if (inFeatureKey!=null) { //??
				xmlseqdoc.startFeature( kFeatureItem, inFeatureKey, inFeatureVal);
				}*/
			//? inFeatureVal= inFeatureKey= null; 
			}
		else if (inElVal == kFeatureNote) {
					//  will get notes before closing kFeatureItem - are we sure it is kFeatureItem?
			if (inFeatureKey!=null && lastel == kFeatureItem) {
				xmlseqdoc.startFeature( kFeatureItem, inFeatureKey, inFeatureVal);
				inFeatureVal= inFeatureKey= null; 
				}
			}
			
		/*else if (inElVal == kFeatureKey) {
			if (inFeatureKey!=null) ; //? error?
			inFeatureKey= null;
			}*/
		else if (inElVal == kFeatureValue) {
			if (inFeatureVal!=null) ; //? error?
			inFeatureVal= null;
			}
		else if (inElVal == kFeatureLocation) {
			if (inFeatureVal!=null) ; //? error?
			inFeatureVal= null;
			}
			
    /*
    int len = atts.getLength();
    for (int i = 0; i < len; i++) {
        wr.write(' ');
        wr.write(atts.getName(i));
        wr.write("=\"");
        wr.write(atts.getValue(i));     
        wr.write('"');
        }
    */
    } catch (Exception e) { throw new SAXException(e); }
	} 

	/*public void startElementOld(String name, AttributeList atts)   throws SAXException 
  {
  	inElVal= -1;
  	inTagName= name;
  	inElAppend= false;
  	if (inEl!=null) inElStack.push( inEl);
		inEl= getBiodocKind(name); 
		if (inEl!=null) inElVal= inEl.intValue();

		if (inFeatures == kAtFeatureHeader) { 
				// && inElVal <= 0 -- ignore inElVal - not set for features
			inFeatures= kInFeatures;
			featlevel= kFeatField; 
			inElVal= kFeatureItem;  
			inEl= new Integer(inElVal); //? for later push/pop?
			}
		else if (inFeatures == kInFeatures) { 
			if (featlevel >= kFeatField) inElVal= kFeatureNote;  
			else inElVal= kFeatureItem;  
			featlevel++; // will pop this back at endEl() //kFeatField //kFeatCont; //
			inEl= new Integer(inElVal); //? for later push/pop?
			}
			
		else if (inElVal == kFeatureTable) {
//		kBeforeFeatures = 0,  kAtFeatureHeader= 1, kInFeatures = 2, kAfterFeatures= 3,
			inFeatures= kAtFeatureHeader;
			}
	} */


 public void endElement(String name) throws SAXException {
		try {
		// handle any finishing for this named tag
		// at kBioseq end need to store current seqFileInfo and reset for more...
		
		if (inElVal == kBioseq) {
			storeSeq(); resetSaxSeq(); 
			}
			
		else if (inElVal == kFeatureTable) {
			inFeatures= kAfterFeatures;
			}
		else if (inElVal == kFeatureItem) {
			if (inFeatureKey!=null) {
				xmlseqdoc.endFeature( kFeatureItem, inFeatureKey, inFeatureVal);
				inFeatureVal= inFeatureKey= null; 
				}
			//featlevel--; //? or do after popping old inElVal ?
			}
		else if (inElVal == kFeatureNote) {
			if (inFeatureKey!=null) {
				xmlseqdoc.endFeature( kFeatureNote, inFeatureKey, inFeatureVal); 
				inFeatureVal= inFeatureKey= null; 
				}
			//featlevel--; 
			}
			
		// else if (inElVal == kFeatureKey) { } 
		else if (inElVal == kFeatureValue) {

			}
		else if (inElVal == kFeatureLocation) {

			}
			
  	if (!inElStack.empty()) {
  		inEl= (Integer) inElStack.pop();
			if (inEl!=null) inElVal= inEl.intValue();
  		inTagName= getXMLFieldName( inEl); // need for chars
  		inElAppend= true;
			}
			
 		} catch (Exception e) { throw new SAXException(e); }
	} 
	

  /* public void endElementOld(String name) throws SAXException {

		// handle any finishing for this named tag
		// at kBioseq end need to store current seqFileInfo and reset for more...
		//? if (name.equals( getXMLFieldName( kBioseq)))
		if (inElVal == kBioseq) {
			try {
			storeSeq();
			resetSaxSeq();
			} 
			catch (Exception e) { throw new SAXException(e); }
			}
		else if (inElVal == kFeatureTable) {
			inFeatures= kAfterFeatures;
			}
		else if (inElVal == kFeatureItem) {
			featlevel--; //? or do after popping old inElVal ?
			}
		else if (inElVal == kFeatureNote) {
			featlevel--; 
			}
  	if (!inElStack.empty()) {
  		inEl= (Integer) inElStack.pop();
			if (inEl!=null) inElVal= inEl.intValue();
  		inTagName= getXMLFieldName( inEl); // need for chars
  		inElAppend= true;
			}
 	} */

	protected String charsToString(char[] val, int offset, int length) {

		// ! need also to drop whitespace not ignored by parser but should be
		// scan at least for \r \n and trim following them
		// -- shouldn't need this - other xml parsers won't do
		/*
		for (int i=0; i<length; i++) {
			int k= offset+i;
			if (val[k] == '\r' || val[k] == '\n') {
				int offlen= length+offset;
				val[k]= ' '; k++;//leave 1 space
				int j= k;
				while (j<offlen && val[j] <= ' ') j++;
				int droplen= j - k;
				if (droplen>0) for ( ; j<offlen; k++, j++) { val[k]= val[j]; }
				length -= droplen;
				}
			}*/
			
		String sval= new String(val, offset, length);
		sval= sval.trim(); // getting whitespace - drop?  
		return sval;
		}

	protected String charsToString(String oldval, char[] val, int offset, int length) {
		if (oldval!=null) {
			StringBuffer sb= new StringBuffer(oldval);
			sb.append(' '); //?
			sb.append( val, offset, length);
			return sb.toString().trim(); //? trim
			}
		else return charsToString( val, offset, length);
		}
		
					
	
		/** this is called for kFeatureItem at appearance of 1st note? */
	protected void startFeature( int kind, String field, String value)
	{
		//if (!keepField(kind)) return; //?
		if (kind == kFeatureItem) {
			FeatureItem fi= new FeatureItem( field, value, kFeatField);
			feat.addElement(  fi);
			curFieldItem= fi;
			}
	}
	
	protected void endFeature( int kind, String field, String value)
	{
		Debug.println("endFeature("+kind+", "+field+", " +value);
		//if (!keepField(kind)) return; //?
		if (kind == kFeatureItem) {
			if (curFieldItem==null) {
				FeatureItem fi= new FeatureItem( field, value, kFeatField);
				feat.addElement(  fi);
				}
			//? else append value?
			else { //if (append && curFieldItem != null)
				curFieldItem.appendValue(value);
				}
			curFieldItem= null; //fi;
			}
			
		else if (kind == kFeatureNote) {
			
			if (curFieldItem==null) {
				System.err.println("Error: null feature item for note '"+field+"', val="+value);
				return;
				}
				
			if (value!=null && value.length()>0) {
				int spc= value.indexOf(' ');
				if (spc > 0 || !Character.isDigit(value.charAt(0))) 
					value= "\"" + value + "\"";
				}
		
			if (field!=null && field.charAt(0) == '/') {
				curFieldItem.putNote( new DocItem(field, value, kFeatureNote, kFeatCont)); 
				}
			
			else {
				 // continuation?, append to last note value?
				curFieldItem.appendNote( value); 
				}
			 
			}
	}
	
			// override
	public void addFeature( String field, String value, int level, boolean append) 
	{ 
				//  this syntax common to genbank & embl:  "/featfld=value"
				// !!! but XML changes it !!!

		field= uncleanXmlTag( field);
		
		if (level == kFeatField) {
				// need an append here for xml...
			if (append && curFieldItem != null) {
				curFieldItem.appendValue(value);
				}
			else {
				FeatureItem fi= new FeatureItem(field, value, level);
				feat.addElement(  fi);
				curFieldItem= fi;
				}
			}
			
		else if (curFieldItem!=null) {
		
			if (value!=null && value.length()>0) {
				int spc= value.indexOf(' ');
				if (spc > 0 || !Character.isDigit(value.charAt(0))) 
					value= "\"" + value + "\"";
				}
		
			if (field.charAt(0) == '/') {
				curFieldItem.putNote( new DocItem(field, value, kFeatureNote, level)); 
				}
			
			else {
				 // continuation?, append to last note value?
				curFieldItem.appendNote( value); 
				}
			}
	}
	

	
  public void characters( char ch[], int start, int length)  throws SAXException
  {
			// for reader iface, see also writeCharacters
		try {
		if (!keepField(inElVal)) return; //?
		switch (inElVal) {
	
			case kSeqdata: 
				addseq( ch, start, length); 
				break;
			
			case kName:    
				{
				String sval= charsToString(ch, start, length); //new String(val, start, length).trim();
				if (sval.length()>0) {
					setSeqName(sval); //seqid= sval;
					xmlseqdoc.addDocField( inTagName, sval, kField, inElAppend); 
					inElAppend= true;  
					}
				break;
				}

					// add these new ft tags for xml
			/*case kFeatureKey: // ft tag -- move into chars of kFeatureItem,kFeatureNote
				inFeatureKey=  charsToString(inFeatureKey,ch, start, length);  
				break;*/
				
			case kFeatureValue:	// value
			case kFeatureLocation: // can use inFeatureVal?
				inFeatureVal= charsToString( inFeatureVal, ch, start, length);   
				break;

			/*case kFeatureElement: //!? kFeatureElement == kFeatureNote
				break;*/
								
			case kFeatureItem:  
				//if (inTagName.equals("FI")) return; // where does this come from - blanks between subfeatures?
				//fldlevel= kFeatField; //featlevel;  
				inFeatureKey=  charsToString( inFeatureKey, ch, start, length);  
				//xmlseqdoc.addFeature( inTagName, charsToString(ch, start, length), kFeatField, inElAppend);
				//inElAppend= true; //? need this esp - "&lt;" are sent sep from rest
				break;
				
			case kFeatureNote:	 
				//fldlevel= kFeatCont; //featlevel;  
				inFeatureKey=  charsToString( inFeatureKey, ch, start, length);  
				//xmlseqdoc.addFeature( inTagName, charsToString(ch, start, length), kFeatCont, inElAppend);
				//inElAppend= true; 
				break;
				
			case kUnknown:
			case kBlank:
			case kBioseqSet: 
			case kBioseq: 
			case kBioseqDoc: 
				break; // these should have no char data

			default: //? is this safe?
				//int fldlevel= kField; // ? kContinue -- if append? - what of kSubfield
				xmlseqdoc.addDocField( inTagName, charsToString(ch, start, length), 
								kField, inElAppend);  
				inElAppend= true;  
				break;

			}
    } catch (Exception e) { throw new SAXException(e); }
	}  
	
	/*
  public void charactersOld( char ch[], int start, int length)  throws SAXException
  {
			// for reader iface, see also writeCharacters
		int fldlevel= 0;
		switch (inElVal) {
			case kSeqdata: addseq( ch, start, length); break;
			
			case kName:    
				{
				fldlevel= kField;  
				String sval= charsToString(ch, start, length); //new String(val, start, length).trim();
				if (sval.length()>0) {
					setSeqName(sval); //seqid= sval;
					xmlseqdoc.addDocField( inTagName, sval, fldlevel, inElAppend); 
					}
				inElAppend= true;  
				break;
				}

			default: //? is this safe?
				fldlevel= kField; // ? kContinue -- if append? - what of kSubfield
				xmlseqdoc.addDocField( inTagName, charsToString(ch, start, length), 
								fldlevel, inElAppend);  
				inElAppend= true;  
				break;
								
			case kFeatureItem:  
				if (inTagName.equals("FI")) return; // where does this come from - blanks between subfeatures?
				fldlevel= kFeatField; //featlevel;  
				xmlseqdoc.addFeature( inTagName, charsToString(ch, start, length), fldlevel, inElAppend);
				inElAppend= true; //? need this esp - "&lt;" are sent sep from rest
				break;
				
			case kFeatureNote:	 
				fldlevel= kFeatCont; //featlevel;  
				xmlseqdoc.addFeature( inTagName, charsToString(ch, start, length), fldlevel, inElAppend);
				inElAppend= true; 
				break;
	
			case kUnknown:
			case kBlank:
			case kBioseqSet: 
			case kBioseq: 
			case kBioseqDoc: 
				break; // these should have no char data
			}
	}  
	*/

  public void ignorableWhitespace(char ch[], int start, int length) throws SAXException 
 		{ }  //? characters(ch, start, length);


			// unused HandlerBase parts

	public void processingInstruction(String target, String data)  throws SAXException 
  { } 
 	public InputSource resolveEntity (String publicId, String systemId)  throws SAXException
  { return null; }
  public void notationDecl (String name, String publicId, String systemId)
  { }
  public void unparsedEntityDecl (String name, String publicId, String systemId, String notationName)
  { }
  public void setDocumentLocator (Locator locator)
  { }




			//
			// XML writer
			//
			
	final void tab( int val) { writecol+= val; for ( ; val>0; val--) pr.print(' '); }

	protected void writeln() {
		pr.println(); linesout++;  writecol= 0;
		newline= true;  needindent= true;
		}
		
	protected final void writeTag(String tag, String value, int tlevel)
	{
		writeTagStart( tag, value, tlevel);
		writeEndElement( tag, needindent);
	}

	protected void writeTagStart(String tag, String value, int tlevel)
	{
		if (value==null || (value.length() + writecol + tag.length()+2 < kLinewidth)) {
			writeStartElement( tag, false, tlevel);
			writeValue( value);
			//needindent= false;
			}
		else {
			writeStartElement( tag, false, tlevel);
			int indent= 2*tlevel + tag.length()+2;
			while (value!=null) { value= writeWrapText( pr, value, indent, kLinewidth); indent= 0; }
			//needindent= true;
			}
	}
	
	protected void writeValue( String val)
	{
		if (val==null) return;
		val= val.trim();
		int len= val.length();
		if (len>1) {
			char c= val.charAt(0);
			char e= val.charAt(len-1);
			if (c == e && (c == '"' || c == '\'')) {
				val= val.substring(1,len-1);
				len -= 2;
				}
			}
		writeCharacters( val, 0, val.length());
	}
	
			// override
	protected String writeWrapText( PrintWriter pr, String val, int indent, int width)
	{
		val= val.trim();
		int len= val.length();
		if (len>1) {
			char c= val.charAt(0);
			char e= val.charAt(len-1);
			if (c == e && (c == '"' || c == '\'')) {
				val= val.substring(1,len-1);
				len -= 2;
				}
			}
		String rval= null;
		int maxw= width - indent;
		if (len > maxw) {
			int at= val.lastIndexOf(' ', maxw+3);
			if (at > 10) {
				rval= val.substring( at).trim();
				val= val.substring( 0, at);
				}
			}
		//tab(indent);
		writeCharacters( val, 0, val.length());
		if (rval!=null) writeln(); // don't newline if endtag waiting
		return rval;
	}


		// some parts from SAXhandler
  public void writeEmptyElement(String name)   
  {
		tab( 2*level);
    pr.print('<');
    pr.print(name);
    	// write atts ?
    pr.print("/>");  
  	writeln(); 
	} 
	
  public final void writeStartElement(String name) { writeStartElement(name,true,level); }
  public final void writeStartElement(String name, boolean eol) { writeStartElement(name,eol,level); }
  public void writeStartElement(String name, boolean eol, int tlevel)   
  {
		tab( 2 * tlevel);
    pr.print('<');
    pr.print(name);
   /* if (atts!=null) {
	    int len = atts.getLength();
	    for (int i = 0; i < len; i++) {
        pr.write(' ');
        pr.write(atts.getName(i));
        pr.write("=\"");
        pr.write(atts.getValue(i));     
        pr.write('"');
        }
    	}*/
    pr.print('>');
    writecol += 2 + name.length();
    if (eol)  writeln(); 
	} 

	public final void writeEndElement(String name) { writeEndElement(name,true); }
	
	public void writeEndElement(String name, boolean doindent)  
	{
		if (doindent) tab( 2*level);
  	pr.print("</");  pr.print(name); pr.print('>');  
  	if (!noendeol) writeln(); //linesout++; needindent= true;
	} 
	
  public void writeCharacters(char ch[], int start, int length)   
  {
  	for (int i = start; i < start + length; i++) printEncoded(ch[i]);
	}  
	
  public void writeCharacters(byte ch[], int start, int length)   
  {
  	for (int i = start; i < start + length; i++) printEncoded( (char)ch[i]);
	}  
	
  public void writeCharacters(String s, int start, int length)  
  {
  	for (int i = start; i < start + length; i++) printEncoded(s.charAt(i));
	}  
	
	boolean compatable= false;
	private char lastc;
	
	protected void printEncoded(char ch) 
  {
  	needindent= newline= false; writecol++;
    switch (ch) {
      case '&': pr.write("&amp;"); break;
      case '<': pr.write("&lt;"); break;
      case '>': pr.write("&gt;"); break;
      case '"': pr.write("&quot;"); break;
      case '\t': {
          if (compatable) pr.write("&#9;");
          else pr.write(ch);
          break;
          }
      case '\n': {
          if (compatable) pr.write("&#10;");
          else if (lastc!='\r') writeln(); //pr.write(ch);  
          break;
          }
      case '\r': {
          if (compatable) pr.write("&#12;");
          else if (lastc!='\n') writeln(); //pr.write(ch); 
          break;
          }
      default: pr.write(ch);  
      } 
    lastc= ch;
	}
	
};
