// seqreader.java
// d.g.gilbert, 1990-1999

// byte stream version - simpler than char stream - faster?

	
package iubio.readseqB;

import java.io.*;

import flybase.Debug;
import flybase.OpenString;

	// interfaces
import iubio.readseq.BioseqReaderIface;
import iubio.readseq.BioseqWriterIface;
//import iubio.readseq.BaseData;
//import iubio.readseq.DocumentData;
import iubio.readseq.BioseqDoc;

import iubio.readseq.Biobase;
import iubio.readseq.BaseKind;
import iubio.readseq.SeqKind;
import iubio.readseq.SeqFileInfo;
import iubio.readseq.Bioseq;
import iubio.readseq.BioseqFormats;
import iubio.readseq.GenbankDoc;


	


 
public abstract class BioseqReader
	implements BioseqReaderIface
	// implements Cloneable
	//??? extends Reader
{
	public static int readChunkSize= 2048; //8192;
	public static int readFreeSize = readChunkSize * 100;
	public static String tempFile = "bioseqtemp.";
	//public static String gBlankSeqid = "nameless";
	
	
	public BioseqReader() {
		margin	=  0;
		addfirst= false;
	  addend  = true; 
	  ungetend= false;
		}
		
	public BioseqReader(InputStream ins) { //Reader
		this();
		setInput(ins);
		}


	// uncertain methods from Iface
	/*
					// ? these should be in Readseq wrapper, 
				// with methods here to use BaseHandler / DocumentHandler
	public void addBaseHandler(BaseHandler l);  
		{ baseHandler = AWTEventMulticaster.add(baseHandler, l);  }  
	public void removeBaseHandler(BaseHandler l); 
		{ baseHandler = AWTEventMulticaster.remove(baseHandler, l);  }  
	public void addDocHandler(DocumentHandler l); 
		{ docHandler = AWTEventMulticaster.add(docHandler, l);  }  
	public void removeDocHandler(DocumentHandler l); 
		{ docHandler = AWTEventMulticaster.remove(docHandler, l);  }  
	*/

	//public void processDocument( DocumentData e) {}
	//public void processBases( BaseData e) {}


	// public accessors =============================
	
	//public int error() { return err; } // drop this for Exceptions
	//public int seqLen() { return seqlen; } //? drop seqlen, use seq.length() ?
	//public String seqId() { return seqid; } //? drop for SeqFileInfo.id
	
	public void setChoice(int seqchoice) { choice= seqchoice; }

	public int formatID() { return formatId; }
	public void setFormatID(int id) { formatId= id; } //? Readseq sets id?
	//public String formatName() { return formatLabel; } //? drop var for method?
	//public String formatSuffix() { return fileSuffix; }//? drop var for method?
	//public String contentType() { return mimeType; }//? drop var for method?

	public InputStream getInput() { return this.fIns; } //? or bufins ?

	public void setInput( Reader ins) { 
		throw new Error("Reader not supported");
		}
		
	public void setInput(InputStream ins) { 
		this.fIns= ins; 
		fEof= false; 
		setReaderBuf(fIns);
		}

	public void doRead() throws IOException { 
		if (fIns==null) throw new FileNotFoundException(); //err= Readseq.eFileNotFound;
		read();
		if (seqdoc==null) seqdoc= new GenbankDoc(seqid.toString()); //? so all can stuff features?
		}


	public int getNseq() { return nseq; }
	protected void setNseq(int nsequences) { this.nseq= nsequences; }

	public void resetSeq() {
		seqlen= seqlencount= 0; 
		allDone= false;
		idword= SeqFileInfo.gBlankSeqid;
		seqid= SeqFileInfo.gBlankSeqid;
		//maxseqlen= 0; seq= null; //? leave storage for next and copy prior?
		}

	public void copyto(SeqFileInfo si) {
		if (si==null) return;
		if (si.err==0) si.err= err;
		si.seqlen= seqlen;
		if (si.err==0 && seqlen>0) { // && seq!=null
			si.atseq= atseq; //<< counted to current sequence in file
			if (atseq>si.nseq) si.nseq= atseq;
			si.seqid= seqid;
			si.seqdoc= seqdoc;
// if (USEARRAY)
			si.seq= new Bioseq( bases, 0, seqlen);
// else 
		/*
			Biobase[] bb= Bioseq.expand(seq.bases(), seqlen);
			si.seq= new Bioseq( bb);
 		*/
			}		
		}
	
	/*
	public Object clone() {
		try {
			BioseqReader c= (BioseqReader) super.clone();
			c.readbuf= null;
			c.nbuf= 0;
			c.seq= null;
			c.seqdoc= null; //??
			c.clearSeq();
			//c.ins= null;//??
	    return c;
			}
		catch(CloneNotSupportedException ex) { throw new Error(ex.toString()); }
		}*/
		
	
	public boolean endOfSequence() { return false; }

		
		

	
	// protected =============================	
	
	protected int formatId= -1;
	protected int			seqlen, offset, seqlencount, maxseqlen, memstep, 
										choice, nseq, margin = 0, err= 0, atseq= 0;
	protected boolean addit = true, addfirst = false, addend = true, 
										needString = false,
										allDone= false, ungetline= false, ungetend = false;
	protected String 	idword= SeqFileInfo.gBlankSeqid, seqid= SeqFileInfo.gBlankSeqid;

	private Bioseq	seq; // change to Object, or some more flexible class
	private byte[]  bases; // local storage - faster than Bioseq
	protected Object  seqdoc;
	protected TestBiobase	testbase= new TestBiobase();

		
		
	// add data =============================	
	
	protected final void addseq( OpenString s, int offset) {
		addseq( s, offset, s.length()); 
		}
		
	protected void addseq( OpenString s, int offset, int nb)
	{
		nb += offset;
	  if (addit) for (int i=offset; i<nb; i++) { 
	    int c= testbase.isSeqChar( s.charAt(i)); 
	    if (c > 0) {
	      if (seqlen >= maxseqlen) if (!expand()) return;
// if (USEARRAY)
		   	bases[seqlen++]= (byte) c;  
// else
	     	//seq.setbase(seqlen++, new Biobase((char)c));
	      }
	    }
	}

	protected void addseq(byte[] b, int offset, int nb) 
	{
	  nb += offset;
	  if (addit) for (int i=offset; i<nb; i++) { 
		 	int c;
	    if ((c= testbase.isSeqChar( b[i])) != 0) {
	      if (seqlen >= maxseqlen) if (!expand()) return;
// if (USEARRAY)
		   	bases[seqlen++]= (byte) c;  
// else
	     	// seq.setbase(seqlen++, new Biobase((char)c));
	      }
	    }
	}

	protected final void countseq(OpenString s, int offset) {
		countseq( s, offset, s.length()); 
		}
		
	protected void countseq(OpenString s, int offset, int nb)
	{
	  nb += offset;
		for (int i=offset; i<nb; i++) { 
	    if ((testbase.isSeqChar( s.charAt(i))) != 0) seqlencount++;
	    }
	}
	
	 /** must count all valid seqq chars, for some formats (paup-sequential) 
	 		even if we are skipping seqq... */
	protected void countseq(byte[] b, int offset, int nb)
	{
		nb += offset;
		for (int i=offset; i<nb; i++) { 
	    if ((testbase.isSeqChar( b[i])) != 0) seqlencount++;
	    }
	}

	protected void addinfo( String ids)
	{
	  boolean saveadd = addit;
		addit = true;
	  TestBiobase oldtest= testbase;
	 	testbase = new TestAnychar();
	  ids= ids.trim();  
		String si= " " + String.valueOf(atseq) + ")  " + ids;
	  addseq( si.getBytes(), 0, si.length()); 
	  	//^^???? why are we adding info to seq storage?
	  	// for use with list() method of listing seq record headers only -- revise this
		addit = saveadd;
	 	testbase = oldtest;  
	}
	

	protected boolean expand() 
	{
			/* revise this to 
			(a) store all of long seqq on disk file (tmpnam()),
			  -- offload to disk instead of realloc until done reading
			(b) increase aStartLength if seqq is getting large -- larger chunksize
			(c) check ftell(V->f) to get max seqq size, reduce if see it is 
				 multiseq file?
			*/
  	maxseqlen += readChunkSize;
   	memstep++;
   	/*#
		//protected	Runtime	javart= Runtime.getRuntime();
		if (memstep % 10 == 0 && javart.freeMemory() < readFreeSize) {
			// reduce memory fragmenting... write to disk, free, then malloc. 
			File tempname= new File(tempFile + new Random.nextInt());
			RandomAccessFile tempf= new RandomAccessFile(tempname, "rw");
			tempf.write( seq.bytes(), 0, seqlen);
			tempf.seek(0); // rewind
			
			seq= null;
			javart.gc(); // throw out garbage
			
			seq= new Bioseq(maxseqlen);
			if (seq != null) tempf.read( seq.bytes(), 0, seqlen);
			tempf.close();
			tempname.delete();
			}
		else 
		*/ 
		
//if (USEARRAY) 
		if (bases==null) bases= new byte[maxseqlen];
		else {
			byte[] tb= new byte[maxseqlen];
			System.arraycopy( bases, 0, tb, 0, seqlen);
			bases= tb;
			}
  	return (bases!=null);
//else
/*  
		if (seq==null) seq= new Bioseq(maxseqlen);
		else seq.expand(maxseqlen);
    if (seq==null || seq.bases()==null) {
    	throw new NullPointerException(); //err= Readseq.eMemFull;
      //return false;
      }
    else 
    	return true;
*/
    	 
	}

	
	// input data =============================	

		// input line
	protected int			nWaiting= 0;
	protected OpenString	sWaiting= new OpenString("");
	
		// input buffer
	private InputStream fIns; //Reader
	private	InputStream bufins;
	private int lastc= -1;
	private final int kMaxbuf= 8192; //>> slower?? 20480; //10240;
	private int nbuf= 0;
	private byte[] readbuf= new byte[kMaxbuf]; // char[]
	private boolean fEof= false;

	protected final byte getreadbuf(int i) { return readbuf[i]; }
	protected final void setreadbuf(int i,byte c) { readbuf[i]= c; }
	protected final void setreadbuf(int i,char c) { readbuf[i]= (byte)c; }
	protected final byte[] getreadchars() { return readbuf; }
	protected final int getreadcharofs() { return 0; }

	public boolean endOfFile() { return fEof; }
	public void ungetline()  { ungetline= true; }

	private void setReaderBuf(InputStream ins) {
		if (ins.markSupported()) bufins= ins;
		else bufins= new BufferedInputStream(ins);
		}			

	public void reset() {
		nbuf= seqlen= seqlencount= err= atseq= 0;
		ungetline= allDone= false;
		fEof= false; 
		if (fIns!=null) try {
			fIns.reset(); // may not be reset-able
			fEof= (fIns.available()<=0); //!fIns.ready();
			setReaderBuf(fIns); //bufins.reset(); //?
			}
		catch (IOException ex) {}
		}
		
	protected final void bufToString() {
		sWaiting= bufToOs( 0, nbuf);
		nWaiting= nbuf;
		}

	public OpenString getline()   throws IOException 
	{
		if (ungetline) {
			ungetline= false;
			bufToString();
			}
		else  
			readLine();
		return sWaiting;
	}

	public void getlineBuf()  throws IOException  
	{
		if (ungetline) {
			ungetline= false;
			nWaiting= nbuf;
			}
		else  
			readLineBuf();
	}

	protected final void readLine() throws IOException
	{
		readLineBuf();
		bufToString();
	}

	private final OpenString bufToOs(int offs, int nbuf) {
		//? do we need to make dup of readbuf to prevent overwrite? - negates use of OpenString
		//return new OpenString( readbuf, offs, nbuf);
		byte[] osbuf= new byte[nbuf];
		System.arraycopy( readbuf, offs, osbuf, 0, nbuf);
		return new OpenString( osbuf, 0); // 0 = hibyte
		}
					
	protected void readLineBuf() throws IOException  
	{
		nbuf= 0;
		boolean more= true;  
		while (more) {
			int c= bufins.read();	 // make sure is buffered input here, else very slow !
			if (c==-1) { fEof= true; more= false; }
			else if (c == '\n') {
				if (lastc != '\r') { 
					more= false;
					readbuf[nbuf++]= (byte)'\n';
					}
				}
			else if (c == '\r') {
				more= false;
				readbuf[nbuf++]= (byte)'\n';
				}
			else 
				readbuf[nbuf++]= (byte) c;
			lastc= c;
			if (nbuf >= kMaxbuf) more= false;
			}
		nWaiting= nbuf;
	}	


	protected int indexOfBuf(char c) {
		for (int i=0; i<nbuf; i++) if (readbuf[i] == (byte)c) return i;
		return -1;
		}
		
	protected int indexOfBuf( String s) {
		byte b= (byte) s.charAt(0);
		int len= s.length();
		for (int i=0; i<nbuf; i++) 
			if (readbuf[i] == b) {
				if (len==1) return i;
				if (readbuf[i+1] == (byte) s.charAt(1)) {
					if (len==2) return i;
					OpenString ts= new OpenString( readbuf, i, nbuf-i);
					return i + ts.indexOf(s);
					}
				}
		return -1;
		}

	protected final OpenString bufSubstring( int offset, int endoff) {
		return bufToOs(offset, endoff-offset); 
		//return new OpenString( readbuf, offset, endoff-offset);
		}
	protected final OpenString bufSubstring( int endoff) {
		return bufToOs(0, endoff); // new OpenString( readbuf, 0, endoff);
		}
	
	////////////////


		/** this method is for subclassing */
	protected void read() throws IOException { 
		readLoop(); 
		}	

	protected void readLoop()  throws IOException  
	{
		atseq++;
		if (Debug.isOn) Debug.println( getClass().getName() + " : "+atseq+":"+seqid.trim());
	  if (choice == kListSequences) addit = false;
	  else addit = (atseq == choice);
	  if (addit) seqlen = seqlencount= 0;

	  if (addfirst) addseq( readbuf, 0, nWaiting);
		boolean done;
	  do {
	    getlineBuf();
	    if (needString) bufToString();
	   	done = endOfFile() || endOfSequence();
	    if (addit && (addend || !done) && (nWaiting > margin)) {
	      addseq( readbuf, margin, nWaiting-margin);
	    }
	  } while (!done);

	  if (choice == kListSequences) addinfo(seqid);
	  else {
	   	allDone = (atseq >= choice);
	    if (allDone && ungetend) ungetline();
	    }
	}


};







public class TestBiobase
{
		// do any needed base translation, including user base changes, here
	public int isSeqChar(int c) { 
		//return BaseKind.isSeqChar(c);  //<< BAD!?
		if (Character.isSpace((char)c) || Character.isDigit((char)c)) return 0;
		else return c;
		}

			// output translation
	public int outSeqChar(int c) { return c; }
	
}

public class TestAnychar extends TestBiobase
{
	public int isSeqChar(int c) {
		return BaseKind.isAnyChar(c); 
		}
}


