// BioseqHandler.java
// d.g.gilbert


package iubio.readseq;

public interface BioseqHandler {
}

public interface BaseData {
// some chunk of bioseq data - single byte to array to String ...
}

public interface DocumentData {
// some chunk of document data - byte/char array to String ...
}

public interface BaseHandler extends BioseqHandler
{
	public void addBase( byte base);
	//public void addBase(char base);
	public void addBases( byte[] bases, int offset, int length);
}

public abstract class BaseProcessor implements BaseHandler {
    public void addBase( byte base) {}
    public void addBases( byte[] bases, int offset, int length) { 
    	for (int i=0; i<length; i++) addBase( bases[offset+i]);
    	}
}

public interface DocumentHandler extends BioseqHandler
{
	public void addDoc( char[] line, int offset, int length);
	public void addDoc( byte[] line, int offset, int length);
	public void addDoc(String line);
	//public void addDoc(OpenString line);
}

public abstract class DocumentProcessor implements DocumentHandler {
	public void addDoc( byte[] line, int offset, int length) { }
	public void addDoc( char[] line, int offset, int length) { }
	public void addDoc(String line) {}
	//public void addDoc(OpenString line) {}
}


public class BioseqHandlerMulticaster  
    implements DocumentHandler, BaseHandler
{
	// from java.awt.AWTEventMulticaster
	
	protected final BioseqHandler a, b;

	protected BioseqHandlerMulticaster(BioseqHandler a, BioseqHandler b) {
		this.a = a; this.b = b;
    }
    
    // get rid of these for addBases( BaseData e), addDoc( DocumentData e)
	public void addBase( byte base) {}
	public void addBases( byte[] bases, int offset, int length) {}
	public void addDoc( byte[] line, int offset, int length) { }
	public void addDoc( char[] line, int offset, int length) { }
	public void addDoc(String line) {}

	public void baseAdded( BaseData e) {
    //((BaseHandler)a).addBase(e);
    //((BaseHandler)b).addBase(e);
		}
	public void documentAdded( DocumentData e) {
    //((DocumentHandler)a).addDoc(e);
    //((DocumentHandler)b).addDoc(e);
		}

	public static BaseHandler add(BaseHandler a, BaseHandler b) {
   	return (BaseHandler)addInternal(a, b);
    }
	public static DocumentHandler add(DocumentHandler a, DocumentHandler b) {
   	return (DocumentHandler)addInternal(a, b);
    }
	public static BaseHandler remove(BaseHandler l, BaseHandler oldl) {
		return (BaseHandler) removeInternal(l, oldl);
    }
	public static DocumentHandler remove(DocumentHandler l, DocumentHandler oldl) {
		return (DocumentHandler) removeInternal(l, oldl);
    }

	protected BioseqHandler remove(BioseqHandler oldl) {
		if (oldl == a)  return b;
		if (oldl == b)  return a;
		BioseqHandler a2 = removeInternal(a, oldl);
		BioseqHandler b2 = removeInternal(b, oldl);
		if (a2 == a && b2 == b)  return this;	// it's not here
		return addInternal(a2, b2);
    }

	protected static BioseqHandler addInternal(BioseqHandler a, BioseqHandler b) {
		if (a == null)  return b;
		if (b == null)  return a;
		return new BioseqHandlerMulticaster(a, b);
    }

	protected static BioseqHandler removeInternal(BioseqHandler l, BioseqHandler oldl) {
		if (l == oldl || l == null) {
		    return null;
		} else if (l instanceof BioseqHandlerMulticaster) {
		    return ((BioseqHandlerMulticaster)l).remove(oldl);
		} else {
		    return l;		// it's not here
		}
    }

	//? Serialization support.  
	// protected void saveInternal(ObjectOutputStream s, String k) throws IOException 
	//  protected static void save(ObjectOutputStream s, String k, EventListener l) throws IOException 
     

}
