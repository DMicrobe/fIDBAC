// readseq.java
// d.g.gilbert, 1990-1999



package iubio.readseqB;


import java.io.*;
import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;
import java.net.URL;

import flybase.Debug;
import flybase.OpenString;
import flybase.FastProperties;

import dclap.Native;

	// interfaces
import iubio.readseq.BioseqReaderIface;
import iubio.readseq.BioseqWriterIface;
//import iubio.readseq.BaseData;
//import iubio.readseq.DocumentData;
import iubio.readseq.BioseqDoc;
import iubio.readseq.ReadseqIntf;

import iubio.readseq.BaseKind;
import iubio.readseq.SeqKind;
import iubio.readseq.SeqFileInfo;
import iubio.readseq.Bioseq;
import iubio.readseq.BioseqFormat;
import iubio.readseq.BioseqFormats;
import iubio.readseq.Writeseq;



/**
 * Readseq is public wrapper for
 * classes of BioseqReader & BioseqWriter ancestry	
 *
 * @author  Don Gilbert
 * @version 	Jul 1999
 */
public class Readseq 
	implements Enumeration, ReadseqIntf //?
{
	public static String version = "Readseq [Byte input stream] version j0.9 (july 1999)";


	public Readseq() { 
		this( BioseqFormats.kNoformat);
		}
		
	public Readseq(int format) { 
		setFormat(format);
		}
			
	//public Reader getInput()  {  return fIns; //? or reader.getInput() }
	public InputStream getInput()  { 
		return fIns; //? or reader.getInput() 
		}

	public void setInput( File f) throws IOException { close(); fIns= new RsInputFile( f); 	}
	//public void setInput( Reader in)  throws IOException { close(); fIns= new RsInputReader( in); }
	public void setInput( InputStream in)  throws IOException { close(); fIns= new RsInputStream( in); }
	public void setInput( byte[] b) throws IOException  { close(); fIns= new RsInputBytes( b); } 
	//public void setInput( char[] c)  throws IOException { close(); fIns= new RsInputChars( c); } 
	public void setInput( String s)  throws IOException { close(); fIns= new RsInputString( s); }
	public void setInput( OpenString s)  throws IOException { close(); fIns= new RsInputOpenString( s); }
	public void setInput( URL url) throws IOException { close(); fIns= new RsInputUrl( url); 	}
	
	public void close() throws IOException { if (fIns!=null) fIns.close(); fIns= null; }
	
	public void setFormatTestor(Testseq testor) { formatTestor= testor; }

  public final boolean isMydata() { return isKnownFormat(); }

	public boolean isKnownFormat() 
	{
		//si= new SeqFileInfo();
		if (formatTestor==null) formatTestor= new Testseq(); //this
		int fmt= formatTestor.testFormat( fIns, si); //seqFileFormat( fIns, si);
		Debug.println("isKnownFormat format=" + fmt +":"+ BioseqFormats.formatName(fmt));
		
		if (fmt <= BioseqFormats.kUnknown) return false;
		else {
			setFormat( fmt);  
			//if (reader!=null && fmt != reader.formatID()) reader= null; //.format
			//format= fmt; 
			return true;
			}
	}

			//? not same as isKnownFormat()
	public boolean canread() {
		if (reader!=null) return true; //reader.canread();
		else if (format>0) return BioseqFormats.canread(format);
		else return false;
		}
		
	public final SeqFileInfo getInfo() { return si; }

	public final int getFormat() { return format; }

	public void setFormat(int format) {
		this.format= format;  
		former= BioseqFormats.bioseqFormat(format);  //BioseqFormats.bioseqFormat(format)
		if (reader!=null && reader.formatID() != format) reader= null;
		}

  public String getFormatName() { 
		if (reader!=null) return BioseqFormats.formatName( reader.formatID() ); // isn't reader format always == foramt?
		else if (format>0) return BioseqFormats.formatName( getFormat());
		else return "";
		}
	
	public BioseqReaderIface getReader() { return reader; }
	public BioseqFormat  getBioseqFormat() { return former; }
	
	public boolean eof() {
		try { 
			return ( si.err!=0 || fIns.available()==0 ); 
		} //  //!fIns.ready()
		catch (IOException ex) { return true; }
		}


		//
		// Data accessors -- want all these?
		//
		
	public final SeqFileInfo nextSeq() { 
		if (moreresults()) return (SeqFileInfo) seqfilevec.elementAt(fAt++); 
		else return null; 
		}
	public final Object result() { if (moreresults()) return seqfilevec.elementAt(fAt++); else return null; }
	public final boolean moreresults() 	{ return (fAt < seqfilevec.size()); }
	public final int atresult() 				{ return fAt;  }
	public final int nresults() 				{ return seqfilevec.size();  }
	public final Vector allresults() 		{ return seqfilevec;  }
	public final void restartresults() 	{ fAt= 0; }
	public final void removeresults()   { fAt= 0; seqfilevec.removeAllElements(); }
	 
	 	//
		// Enumeration iface
		//
		
	public boolean hasMoreElements() { 
		if (moreresults()) return true;
		else return canReadMore(); 
		}
		
	public Object nextElement() { 
		if (moreresults()) return this.result(); 
		try { if (readNext()) return this.result();  }
		catch (IOException e) {}
		return null;
		}


		//
		// reading methods
		//
		
	protected static String untitled= "Untitled";
	
	public final boolean readInit()  { return readInit(untitled); }
		
	public boolean readInit( String defname) //? open(name)
	{
		if (reader==null) reader= BioseqFormats.newReader(format);  
		if (reader==null) return false; //? throw IOException ?
		if (former.interleaved()) fIns.makeRewindable();
		reader.setInput(fIns); 
		reader.reset(); //rewind();
		seqDefname= SeqFileInfo.cleanSeqID(defname);
		saveskip= si.skiplines;
		whichEntry= 0;
		//if (!canread()) return false; else 
		return true;
	}
	
	public void readAt(int atEntry) {
		try { readSeq( atEntry); }  // si.ins
		catch (IOException ex) {}
		}

	public boolean canReadMore() {
		//if (si.err!=0) return false; else 
		if (former.interleaved()) return (whichEntry < si.nseq);  else 
		return !eof();   
		}
	
	public boolean readNext() throws IOException
	{
		if (former.interleaved()) {
			reader.reset(); //rewind();
			si.skiplines= saveskip;
			}
			//? trap EOFException here? otherwise we keep reading till end
		readSeq( ++whichEntry); //readAt( ++whichEntry); 
		si.skiplines= 0; 
		if (!si.hasseq()) return false;
   	if (!si.hasid()) si.seqid= seqDefname;
   	return true;	
	}


	
  	// these are Readseq methods, not Writeseq
 	protected boolean fWriteMask= SeqFileInfo.gWriteMask;
	public void setWriteMask(boolean turnon) { fWriteMask= turnon; }
 			
	public boolean readTo( BioseqWriterIface writer)  throws IOException {
		writer.writeHeader();
		while (this.readNext()) {  
			SeqFileInfo si= this.nextSeq();
			if (writer.setSeq( si)) writer.writeSeqRecord();
			if (fWriteMask && writer.setMask(si, si.gMaskName)) writer.writeSeqRecord();
			//if (writer.error()!=0) return false;
			removeresults(); //? free seq?
			}
		writer.writeTrailer();
		return true;
		}
		
	public void list( Writer out) {
		String  lineEnd= System.getProperty("line.separator"); // ? is this accurate now?
		try {
			for (boolean more= false; more; ) {
				readSeq( BioseqReader.kListSequences); //? catch (EOFException eox) {}
				more= (si.seq!=null && si.seqlen>0);
				if (more) { out.write( ((Bioseq)si.seq).toChars()); out.write( lineEnd); }
				} 
			}
		catch (IOException ex) {}
		}


	
		//
		// implementation =============================	
		//
		
	protected Testseq formatTestor;
	protected Vector seqfilevec= new Vector();
	protected int fAt;

  protected BioseqReaderIface reader;
	protected BioseqFormat former;  
	protected RsInput fIns;
	protected SeqFileInfo si= new SeqFileInfo();
	protected int format;
	protected int saveskip, whichEntry= 1;
	protected String seqDefname;
	
	
	protected void readSeq( int atEntry) throws IOException
	{
		//if (reader==null) reader= BioseqFormats.newReader(format);  // should be set here!
		if (reader==null) {
			si.err= -1;  //eFileNotFound
			throw new IOException("Null BioseqReader"); //return; 
			}
		//reader.setInput(fIns); // should be done
		reader.resetSeq();
		si= (SeqFileInfo) si.clone(); // new object for this sequence
		si.seqlen= 0;
		
  	int i;
    OpenString s;
    for (i= si.skiplines; i > 0; i--) reader.getline();
    do {
      s= reader.getline();
      if (s!=null) 
        for (i= s.length()-1; i>0 && s.charAt(i) <= ' '; i--) ;
    } while (s!=null && i == 0 && !reader.endOfFile());

    if ( reader.endOfFile() ) { //  eof() ||
			si.err= -1;  //eNoData
			//throw new EOFException("Premature end of file"); // causing problems at max entry
			return; 
    	}

    whichEntry= atEntry;
		reader.setChoice(whichEntry); //?? set sequence item in stream?
		
		reader.doRead(); //!? have to catch EOFException and store current data !?
		
		reader.copyto(si);
		si.nseq= reader.getNseq();
		if (si.err==0 && si.seqlen>0) {
			seqfilevec.addElement( si);
			if (Debug.isOn) Debug.println("Readseq.read id=" + si.seqid + " seqlen=" + si.seqlen);
			}
	}


};


		// these should be moved into each format subclass
/*
public final static int 
	kNoformat= -1, // format not tested 
	kUnknown= 0,	 // format not determinable  
	kMaxFormat = 20; // initial size
	kIG = 1, 
	kGenBank = 2, 
	kNBRF = 3, 
	kEMBL = 4, 
	kGCG = 5, 
	kStrider = 6, 
	kFitch = 7, 
	kPearson = 8, 
	kZuker = 9, 
	kOlsen = 10, 
	kPhylip2 = 11, 
	kPhylip4 = 12, kPhylip3 = kPhylip4, kPhylip = kPhylip4, 
	kPlain = 13, 
	kPIR = 14, 
	kMSF = 15, 
	kASN1 = 16, 
	kPAUP = 17, 
	kPretty = 18, 
	kMaxFormat= kPretty, 
	kMinFormat= 1, 
			//subsidiary types 
	kASNseqentry=  51,
	kASNseqset	=  52,
	kPhylipUndetermined = 60,
	kPhylipInterleave = 61,
	kPhylipSequential = 62
	;
*/
	





/**
 * Rewindable wrapper classes for input data <p>
 * Make input stream rewind/reset-able when needed
 */
abstract class RsInput extends FilterInputStream // FilterReader
{
	RsInput()  throws IOException { super(null); }
	public void makeRewindable() {}
}


/**
 * Rewindable wrapper for File input
 */
class RsInputFile extends RsInput
{
	protected static final int kBufsize = 2048;
	//protected BufferedReader fInbuf;
	protected File fInfile;
	//protected FileReader fInfs;
	protected FileInputStream fInfs;

	RsInputFile( File f)  throws IOException {
		fInfile= f; 
		openFile();
		}
		
	RsInputFile()  throws IOException {
		}
	
	public void reset()  throws IOException { 
		//try { fInbuf.reset();  }
		//catch (IOException ex) {
			try { fInfs.close(); } catch (IOException ex2) {}
			openFile();
			//}
		}

	protected void openFile() throws IOException { 
		fInfs = new FileInputStream(fInfile); //FileReader( fInfile);  
		in= fInfs; 
		//lock= in;
		}
}


/**
 * Rewindable wrapper for InputStream input
 */
class RsInputStream extends RsInputFile
{
	protected InputStream fInsOrig;
	//protected InputStreamReader fInrd;
	
	RsInputStream( InputStream ins) throws IOException {
		this.fInsOrig= ins;
		openStream();
		}
	RsInputStream() throws IOException { }
		
	public void reset()  throws IOException { 
		//try { fInbuf.reset();  }
		//catch (IOException ex) {
			if (fInfile!=null) {
				try { fInfs.close(); } catch (IOException ex2) {}
				openFile();
				}
			//}
		}

	public void makeRewindable() 
	{
			// called only when format requires rewinding -- e.g., interleaved
		if (fInfile==null) {
			fInfile= new File( Native.tempFolder(), 
					"rs"+ Integer.toString( new Random().nextInt()) + ".temp");
			//try { fInbuf.reset(); } catch (IOException ex) {}
			try {
				//FileWriter fout= new FileWriter(fInfile);
				//char[] buf= new char[1024];
				FileOutputStream fout= new FileOutputStream(fInfile);
				byte[] buf= new byte[1024];
				int n;
				do {
					n= in.read(buf);
					if (n>0) fout.write(buf, 0, n);
				} while (n>=0);
				fout.close();
				openFile();
				}
			catch (IOException ex) { ex.printStackTrace(); }
			}
	}
	
	public void finalize() throws Throwable {
		if (fInfile!=null) {
			fInfile.delete();
			fInfile= null;
			}
		}
	
	protected void openStream()  throws IOException { 
		in= fInsOrig;
		//fInbuf= new BufferedInputStream( fInsOrig, kBufsize);
		//fInrd= new InputStreamReader( fInsOrig);
		//in= fInrd;
		//lock= in;
		}
}


/**
 * Rewindable wrapper for URL input
 */
class RsInputUrl extends RsInputStream
{	
	URL url;
	RsInputUrl( URL url) throws IOException {
		super();
		this.url= url;
		this.fInsOrig= url.openStream();
		openStream();
		}
}


/**
 * Rewindable wrapper for Reader input
 */
/*class RsInputReader extends RsInputFile
{
	protected Reader fInsOrig;
	
	RsInputReader( Reader ins)  throws IOException {
		this.fInsOrig= ins;
		openStream();
		}
		
	public void reset()  throws IOException { 
		//try { fInbuf.reset();  }
		//catch (IOException ex) {
			if (fInfile!=null) {
				try { fInfs.close(); } catch (IOException ex2) {}
				openFile();
				}
			//}
		}

	public void makeRewindable() 
	{
			// called only when format requires rewinding -- e.g., interleaved
		if (fInfile==null) {
			fInfile= new File( Native.tempFolder(), 
					"rs"+ Integer.toString( new Random().nextInt()) + ".temp");
			//try { fInbuf.reset(); } catch (IOException ex) {}
			try {
				FileWriter fout= new FileWriter(fInfile);
				char[] buf= new char[1024];
				int n;
				do {
					n= in.read(buf);
					if (n>0) fout.write(buf, 0, n);
				} while (n>=0);
				fout.close();
				openFile();
				}
			catch (IOException ex) { ex.printStackTrace(); }
			}
	}
	
	public void finalize() throws Throwable {
		if (fInfile!=null) {
			fInfile.delete();
			fInfile= null;
			}
		}
	
	protected void openStream() throws IOException { 
		in= fInsOrig;
		//fInbuf= new BufferedReader( fInsOrig, kBufsize);
		//fInbuf.mark(kBufsize);
		//in= fInbuf; 
		lock= in;
		}
}
****/


/**
 * Rewindable wrapper for byte[] input
 */
class RsInputBytes extends RsInput
{
	ByteArrayInputStream ba;
	
	RsInputBytes( byte[] inbytes)  throws IOException {
		ba= new ByteArrayInputStream(inbytes);
		in= ba; //in= new InputStreamReader( ba);  
		//lock= in;
		}
	public void reset()  throws IOException { ba.reset(); }
}


/**
 * Rewindable wrapper for char[] input
 */
/*class RsInputChars extends RsInput
{
	RsInputChars( char[] inchars)  throws IOException {
		in= new CharArrayReader(inchars);  
		//lock= in;
		}
}*/

/**
 * Rewindable wrapper for String input
 */
class RsInputString extends RsInput
{
	RsInputString( String s)  throws IOException {
		in= new StringBufferInputStream(s);
		//in= new StringReader( s); lock= in;
		}
}

/**
 * Rewindable wrapper for OpenString input
 */
class RsInputOpenString extends RsInput
{
	//RsInputOpenString( OpenString s)  throws IOException {
		//in= new CharArrayReader( s.getValue());  lock= in;
	//	}
	ByteArrayInputStream ba;
	
	RsInputOpenString( OpenString s)  throws IOException {
		ba= new ByteArrayInputStream(s.getBytes());
		in= ba; 
		}
	public void reset()  throws IOException { ba.reset(); }
}



