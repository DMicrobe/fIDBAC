// seqread1.java
// low level readers & writers : sequential formats
// d.g.gilbert, 1990-1999

package iubio.readseqB;

import java.io.*;
import java.util.Date;

import flybase.OpenString;

import Acme.Fmt;
		 
//import iubio.readseq.*;
	// interfaces
import iubio.readseq.BioseqReaderIface;
import iubio.readseq.BioseqWriterIface;
//import iubio.readseq.BaseData;
//import iubio.readseq.DocumentData;
import iubio.readseq.BioseqDoc;

	// can we do w/o these?
import iubio.readseq.BaseKind;
import iubio.readseq.SeqKind;
import iubio.readseq.SeqFileInfo;
import iubio.readseq.Biobase;
import iubio.readseq.Bioseq;
import iubio.readseq.GenbankDoc;
import iubio.readseq.EmblDoc;
	
import iubio.readseq.BioseqFormat;
import iubio.readseq.BioseqWriter;
	
	
//========= sequential BioseqReader subclasses ==========




public class PearsonSeqFormat extends BioseqFormat
{
	public String formatName() { return "Pearson|Fasta"; }  
	public String formatSuffix() { return ".fasta"; } 
	public String contentType() { return "biosequence/fasta"; } 
	public BioseqReaderIface newReader() { return new PearsonSeqReader(); }
	public BioseqWriterIface newWriter() { return new PearsonSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.charAt(0) == '>') {
      formatLikelihood = 55;
      if (recordStartline==0) recordStartline= atline;
      return false; //!
      }
    else
    	return false;
	}

}

public class PearsonSeqReader  extends BioseqReader
{
	public PearsonSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 8;
		}

	public boolean endOfSequence() {
	  return (nWaiting > 0 && getreadbuf(0) == '>');
		}

	protected void read() throws IOException
	{
	  while (!allDone) {
	    if (nWaiting > 0) seqid= sWaiting.substring(1).toString();
	    readLoop();
	    if (!allDone) {
	    	while (!(endOfFile() || (nWaiting > 0 && getreadbuf(0) == '>') ))
	        getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}
};


public class PearsonSeqWriter  extends BioseqWriter
{
	final static int seqwidth= 60; // up from default 50, jul'99
	
	public void writeRecordStart() {
		super.writeRecordStart();
   	opts.seqwidth = seqwidth; 
		}

	public void writeRecordEnd() { } // no extra newline!

	public void writeSeq() {  
		// writeLoop();
		//  ^^ ? replace w/ simpler one for this format? just dump seqq, 60/line
		int i;
		boolean newline= true;
		for (i= 0; i < seqlen; i++) {
	   	//char bc= (char) testbase.outSeqChar( bioseq.base(offset+i,fBasePart));
	   	char bc= bioseq.base(offset+i,fBasePart);
			writeByte( bc); newline= false;
			if (i % seqwidth == seqwidth-1) { 
				writeln(); newline= true; 
				}
			}
		if (!newline) writeln();
	}
		
		
	public void writeDoc() {
   	writeString(">");
   	writeString(seqid);
   	writeString("  ");
   	writeString( String.valueOf(seqlen));
   	writeString(" bp ");
   	// add some other doc here if available - EMBL/GB def line
   	writeln(checksumString());
		//linesout += 1;
		}
};



public class GenbankSeqFormat extends BioseqFormat
{
	public String formatName() { return "GenBank|GB"; }  
	public String formatSuffix() { return ".gb"; } 
	public String contentType() { return "biosequence/genbank"; } 
	public BioseqReaderIface newReader() { return new GenbankSeqReader(); }
	public BioseqWriterIface newWriter() { return new GenbankSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }

	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.startsWith(GenbankSeqReader.kLocus)) {
      formatLikelihood= 80;
      if (recordStartline==0) recordStartline= atline;
    	return false;
      }
    else if (line.startsWith(GenbankSeqReader.kOrigin)) {
      formatLikelihood += 70;
      return false;
      }
    else if (line.startsWith("//")) {
      formatLikelihood += 20;
      return false;
      }
    else
    	return false;
	}
}

public class GenbankSeqReader  extends BioseqReader
{
	final static String kLocus  = "LOCUS ";
	final static String kOrigin = "ORIGIN";
	GenbankDoc doc;
	
	public GenbankSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 2;
		}

	//public BioseqDoc getInfo() { return doc; }

	public boolean endOfSequence() {
		ungetend= (indexOfBuf(kLocus) == 0);
	  return (ungetend || indexOfBuf("//") >= 0);
		}

	
	protected void read() throws IOException
	{  
		doc= new GenbankDoc();
		seqdoc= doc;
	  while (!allDone) {
	  	doc.addDocLine( sWaiting.toString());
	    if (nWaiting > 12) seqid= sWaiting.substring(12).toString();
	    while (!(endOfFile() || sWaiting.startsWith(kOrigin))) {
	  		doc.addDocLine( getline());
	   		}
	    readLoop();
			if (!allDone) {
	    	while (!(endOfFile() || (nWaiting > 0 && indexOfBuf(kLocus) == 0)))
	        getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}

};

public class GenbankSeqWriter  extends BioseqWriter
{

	public void writeRecordStart()
	{
		super.writeRecordStart();
    opts.spacer = 11;
    opts.numleft = true;
    opts.numwidth = 8;  // dgg. 1Feb93, patch for GDE fail to read short numwidth 
	}
	
	public void writeRecordEnd() { writeln("//"); }
		
	public void writeDoc()
	{
	//	writeln( "LOCUS       " + idword + "       " + seqlen + " bp");
		writeString("LOCUS       ");
		writeString(idword);
		writeString("       ");
   	writeString( String.valueOf(seqlen));
		writeln(" bp");
    //linesout += 1;

		if (seqdoc!=null && seqdoc instanceof BioseqDoc) {
			linesout += new GenbankDoc((BioseqDoc)seqdoc).writeTo(douts);
			}
		else {
			//writeln( "DEFINITION  "+ seqid + "  " + seqlen + " bases  " + checksumString());
			writeString("DEFINITION  ");
			writeString( seqid);
   		writeString( String.valueOf(seqlen));
			writeString(" bases  ");
   		writeln(checksumString());
	    //linesout += 1;
			}
		writeln( "ORIGIN      ");
    //linesout += 1;
 	}
 	
};



public class PirSeqFormat extends BioseqFormat
{
	public String formatName() { return "PIR|CODATA"; }  
	public String formatSuffix() { return ".pir"; } 
	public String contentType() { return "biosequence/codata"; } 
	public BioseqReaderIface newReader() { return new PirSeqReader(); }
	public BioseqWriterIface newWriter() { return new PirSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }
	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.startsWith(PirSeqReader.kEntry)) {
      formatLikelihood += 80;
      if (recordStartline==0) recordStartline= atline;
      return false;
      }
    else if (line.startsWith(PirSeqReader.kSequence)) {
      formatLikelihood += 70;
      return false;
      }
    else if (line.startsWith("///")) {
      formatLikelihood += 20;
      return false;
      }
    else
    	return false;
	}
}

public class PirSeqReader  extends BioseqReader
{
	final static String kEntry = "ENTRY ";
	final static String kSequence = "SEQUENCE";
	
	public PirSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 14;
		}


	public boolean endOfSequence() {
		ungetend= (indexOfBuf(kEntry) == 0);
	  return (ungetend || indexOfBuf("///") >= 0);
		}

	protected void read() throws IOException
	{  
	  while (!allDone) {
	    while (!(endOfFile() || sWaiting.startsWith(kSequence) 
	    	|| sWaiting.startsWith(kEntry)
	    	)) getline();
	    if (nWaiting > 16) seqid= sWaiting.substring(16).toString();
	    while (!(endOfFile() || sWaiting.startsWith(kSequence)))
	    	getline();
	    readLoop();
			if (!allDone) {
	    	while (!(endOfFile() || (nWaiting > 0 && indexOfBuf(kEntry) == 0)))
	        getline();
	      }
	    if (endOfFile()) allDone = true;
	  }
	}

	
};


public class PirSeqWriter  extends BioseqWriter
{

	public void writeRecordStart()
	{
		super.writeRecordStart();
    opts.numwidth = 7;
    opts.seqwidth= 30;
    opts.spacer = kSpaceAll;
    opts.numleft = true;
	}
			
	public void writeHeader()  throws IOException { 
		super.writeHeader();
		writeln( "\\\\\\"); 
		}

	public void writeRecordEnd() { writeln("///"); }
	
	public void writeDoc()
	{
   	// somewhat like genbank...  
		writeString("ENTRY           ");
		writeString(idword);
		writeln(" ");

		writeString("TITLE           ");
		writeString(seqid);
		writeString(" ");
   	writeString( String.valueOf(seqlen));
		writeString(" bases  ");
  	writeln(checksumString());
		
		writeln( "SEQUENCE        ");
    //run a top number line for PIR 
    int j;
    for (j=0; j<opts.numwidth; j++) writeByte(' ');
    for (j=5; j<=opts.seqwidth; j += 5) writeString( Fmt.fmt( j, 10));
    writeln();  
    //linesout += 5;
	}
	
	
};



public class EmblSeqFormat extends BioseqFormat
{
	public String formatName() { return "EMBL"; }  
	public String formatSuffix() { return ".embl"; } 
	public String contentType() { return "biosequence/embl"; } 
	public BioseqReaderIface newReader() { return new EmblSeqReader(); }
	public BioseqWriterIface newWriter() { return new EmblSeqWriter(); }
	public boolean canread() { return true; }
	public boolean canwrite() { return true; }
	
	public boolean formatTestLine(OpenString line, int atline, int skiplines) 
	{
		if (line.startsWith(EmblSeqReader.kID)) {
      formatLikelihood += 80;
      if (recordStartline==0) recordStartline= atline;
      return false; //!?
      }
    else if (line.startsWith(EmblSeqReader.kAcc)) {
      formatLikelihood += 10;
      return false; //!
      }
    else if (line.startsWith(EmblSeqReader.kDesc)) {
      formatLikelihood += 10;
      return false; //!
      }
    else if (line.startsWith(EmblSeqReader.kSequence)) {
      formatLikelihood += 70;
      return false; //!?
      }
    else
    	return false;
	}

}

public class EmblSeqReader  extends BioseqReader
{
	final static String kID = "ID   ";
	final static String kSequence = "SQ   ";
	// other tags in this format
	final static String kAcc = "AC   ";
	final static String kDate = "DT   ";
	final static String kDesc = "DE   ";
	final static String kOrganism = "OS   ";
	EmblDoc doc;

	public EmblSeqReader() {
		margin	=  0;
		addfirst= false;
		addend 	= false;  
		ungetend= true;
		//formatId= 4;
		}
		
	//public BioseqDoc getInfo() { return doc; }

	public boolean endOfSequence() {
		ungetend= ( indexOfBuf(kID) == 0);
	  return (ungetend || indexOfBuf("//") >= 0);
		}

	protected void read() throws IOException
	{
		doc= new EmblDoc();
		seqdoc= doc;
  	while (!allDone) {
	  	doc.addDocLine( sWaiting);
	    if (nWaiting > 5) seqid= sWaiting.substring(5).toString();
	    do {
	  		doc.addDocLine( getline());
	    } while (!(endOfFile() || (sWaiting.startsWith(kSequence))));

	    readLoop();
	    
	    if (!allDone) {
	      while (!(endOfFile() || (nWaiting>0 && indexOfBuf(kID) == 0)))
	      	getline();
	    	}
	    if (endOfFile()) allDone = true;
	  }
	}

};


public class EmblSeqWriter  extends BioseqWriter
{
	final static int seqwidth= 60, ktab= 6, kspacer= 10, knumwidth= 8, knumflags= 0;  

	public void writeRecordStart()
	{
		super.writeRecordStart();
   	opts.tab = ktab;    
    opts.spacer = kspacer+1;  
   	opts.seqwidth = seqwidth;
    opts.numright = true; //  added aug'97
    opts.numwidth = knumwidth;  
	}
		
	public void writeRecordEnd() {  writeln("//"); }

	public void writeSeq() // per sequence
	{
		// writeLoop();
		int i, j;
		boolean newline= true;
		for (i= 0; i < seqlen; i++) {
			if (newline) {
				for (j=0; j<ktab; j++) writeByte(' '); 
				newline= false;
				}

	   	char bc= bioseq.base(offset+i,fBasePart);
			writeByte( bc);
			
			if (i % seqwidth == seqwidth-1) { 
	    	writeString( "  " + Fmt.fmt( i+1, knumwidth, knumflags));
				writeln(); newline= true; 
				}
			else if (i % kspacer == kspacer-1) 
				writeByte(' ');
			}
		if (!newline) writeln();
  }
  

	public void writeDoc()
	{
		//ID   DMEST6A    standard; DNA; INV; 1754 BP.
		writeString("ID   ");
		writeln(idword);

    //linesout += 1;
		if (seqdoc!=null && seqdoc instanceof BioseqDoc) {
			linesout += new EmblDoc((BioseqDoc)seqdoc).writeTo(douts);
			}
		else {
			writeString( "DE   ");
			writeString(seqid);
			writeString("  ");
   		writeString( String.valueOf(seqlen));
			writeString(" bases ");
  		writeln(checksumString());
    	//linesout += 1;
			}
		writeString( "SQ   Sequence ");
  	writeString( String.valueOf(seqlen));
		writeln(" BP");
    //linesout += 1;
	}
   
};



 